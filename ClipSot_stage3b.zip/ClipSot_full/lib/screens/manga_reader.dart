import 'dart:async';

import 'package:flutter/material.dart';

import '../haptics.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/haptic_scroll.dart';
import 'sheets.dart';

/// Reads a saved manga / comic chapter.
///
/// Two ways to read: one long scroll (webtoon style) or page by page. Pages are
/// loaded straight from the site the person saved; nothing is copied to the
/// device. Every page turn is felt through a soft click.
class MangaScreen extends StatefulWidget {
  final int id;
  const MangaScreen({super.key, required this.id});

  @override
  State<MangaScreen> createState() => _MangaScreenState();
}

class _MangaScreenState extends State<MangaScreen> {
  late final Store _store;
  final _scroll = ScrollController();
  PageController? _pager;
  final _page = ValueNotifier<int>(0);

  /// Current page, readable during build (the notifier only feeds the counter).
  int _cur = 0;
  final Map<int, BuildContext> _built = {};
  Timer? _saveTimer;
  bool _chrome = true;
  bool _loading = false;
  bool _failed = false;
  bool _restored = false;

  @override
  void initState() {
    super.initState();
    _store = StoreScope.read(context);
    _scroll.addListener(_onScroll);
    final it = _store.byId(widget.id);
    if (it != null && (it.pages == null || it.pages!.isEmpty)) _load();
    WidgetsBinding.instance.addPostFrameCallback((_) => _firstRun());
  }

  Future<void> _firstRun() async {
    if (!mounted || _store.mangaNoticeSeen) return;
    await confirm(
      context,
      'Read what’s yours to read',
      'ClipSot loads these pages straight from the site you saved and keeps nothing. '
      'Only open chapters you have the right to read.',
      'Got it',
      danger: false,
    );
    _store.setMangaView(noticeSeen: true);
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final ok = await _store.enrich(widget.id);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _failed = !ok;
    });
  }

  int get _count => _store.byId(widget.id)?.pages?.length ?? 0;

  void _setPage(int p) {
    if (p == _cur) return;
    _cur = p;
    _page.value = p;
    Haptics.pageTurn();
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 700), _save);
  }

  void _save() {
    final it = _store.byId(widget.id);
    final n = _count;
    if (it == null || n == 0) return;
    _store.saveProgress(it, (_cur + 1) / n);
  }

  void _onScroll() {
    if (_built.isEmpty || !_scroll.hasClients) return;
    final mid = MediaQuery.sizeOf(context).height * .4;
    int? best;
    var bestTop = -double.infinity;
    _built.forEach((i, ctx) {
      final ro = ctx.findRenderObject();
      if (ro is! RenderBox || !ro.attached || !ro.hasSize) return;
      final top = ro.localToGlobal(Offset.zero).dy;
      if (top <= mid && top > bestTop) {
        bestTop = top;
        best = i;
      }
    });
    if (best != null) _setPage(best!);
  }

  /// Jumps to [page] in the long scroll. Heights are only estimates until the
  /// images load, so it corrects itself over a few frames.
  void _jumpTo(int page, {int tries = 0}) {
    if (!_scroll.hasClients) return;
    final ctx = _built[page];
    if (ctx != null && ctx.mounted) {
      Scrollable.ensureVisible(ctx, alignment: 0);
      return;
    }
    if (tries > 8) return;
    final w = MediaQuery.sizeOf(context).width;
    _scroll.jumpTo((page * w * 1.35).clamp(0.0, _scroll.position.maxScrollExtent).toDouble());
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpTo(page, tries: tries + 1));
  }

  void _restoreOnce(int n) {
    if (_restored || n == 0) return;
    _restored = true;
    final it = _store.byId(widget.id);
    if (it == null) return;
    final start = it.progress > .03 && it.progress < .95 ? ((it.progress * n).ceil() - 1).clamp(0, n - 1).toInt() : 0;
    _cur = start;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _page.value = start;
      if (start > 0 && !_store.mangaPaged) _jumpTo(start);
    });
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    final it = _store.byId(widget.id);
    final n = _count;
    final v = n == 0 ? 0.0 : (_cur + 1) / n;
    if (it != null && n > 0) scheduleMicrotask(() => _store.saveProgress(it, v));
    _scroll.dispose();
    _pager?.dispose();
    _page.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final it = store.byId(widget.id);
    if (it == null) return Scaffold(backgroundColor: Colors.black);
    final pages = it.pages ?? const <String>[];
    _restoreOnce(pages.length);
    final headers = <String, String>{'Referer': it.url, 'User-Agent': 'Mozilla/5.0 (Android) ClipSot/0.6'};

    Widget body;
    if (pages.isEmpty) {
      body = _Empty(
        loading: _loading,
        failed: _failed,
        onRetry: _load,
        onOpen: () => openExternal(context, it.url),
      );
    } else if (store.mangaPaged) {
      body = _paged(store, pages, headers);
    } else {
      body = _long(pages, headers);
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0B0B0B),
      body: Stack(children: [
        Positioned.fill(
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: () => setState(() => _chrome = !_chrome),
            child: body,
          ),
        ),
        // Top bar
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: _Fade(
            show: _chrome,
            offset: const Offset(0, -.4),
            child: Container(
              padding: EdgeInsets.only(top: MediaQuery.paddingOf(context).top + 6, left: 8, right: 8, bottom: 10),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xE6000000), Color(0x00000000)],
                ),
              ),
              child: Row(children: [
                _Btn(Icons.arrow_back_ios_new, 'Back', () => Navigator.pop(context)),
                Expanded(
                  child: Text(it.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: ts(15, w: FontWeight.w500, color: Colors.white)),
                ),
                _Btn(store.mangaPaged ? Icons.view_day_outlined : Icons.view_carousel_outlined,
                    store.mangaPaged ? 'Switch to long scroll' : 'Switch to page by page', () {
                  final cur = _cur;
                  store.setMangaView(paged: !store.mangaPaged);
                  _pager?.dispose();
                  _pager = null;
                  _built.clear();
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (!store.mangaPaged) _jumpTo(cur);
                  });
                }),
                if (store.mangaPaged)
                  _Btn(Icons.swap_horiz, store.mangaRtl ? 'Reading right to left' : 'Reading left to right', () {
                    store.setMangaView(rtl: !store.mangaRtl);
                    _pager?.dispose();
                    _pager = null;
                  }),
                _Btn(Icons.more_vert, 'More', () => showItemActions(context, it.id,
                    onDeleted: () => Navigator.of(context).maybePop())),
              ]),
            ),
          ),
        ),
        // Bottom: page counter + progress
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: _Fade(
            show: _chrome && pages.isNotEmpty,
            offset: const Offset(0, .4),
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 24, 20, MediaQuery.paddingOf(context).bottom + 14),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Color(0xE6000000), Color(0x00000000)],
                ),
              ),
              child: ValueListenableBuilder<int>(
                valueListenable: _page,
                builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, children: [
                  Text('${v + 1} / ${pages.length}', style: ts(13, color: Colors.white70, ls: .4)),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(2),
                    child: LinearProgressIndicator(
                      value: pages.isEmpty ? 0 : (v + 1) / pages.length,
                      minHeight: 3,
                      backgroundColor: const Color(0x33FFFFFF),
                      color: p.ac,
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  // ---- long scroll -----------------------------------------------------------
  Widget _long(List<String> pages, Map<String, String> headers) {
    final w = MediaQuery.sizeOf(context).width;
    return HapticScroll(
      step: 140,
      child: ListView.builder(
        controller: _scroll,
        padding: EdgeInsets.zero,
        cacheExtent: 1600,
        itemCount: pages.length + 1,
        itemBuilder: (_, i) {
          if (i == pages.length) return _End(onBack: () => Navigator.pop(context));
          return _PageTile(
            key: ValueKey('mp$i${pages[i]}'),
            index: i,
            url: pages[i],
            headers: headers,
            width: w,
            onMount: (i, c) => _built[i] = c,
            onUnmount: (i) => _built.remove(i),
          );
        },
      ),
    );
  }

  // ---- page by page ----------------------------------------------------------
  Widget _paged(Store store, List<String> pages, Map<String, String> headers) {
    _pager ??= PageController(initialPage: _cur.clamp(0, pages.length - 1).toInt());
    return PageView.builder(
      controller: _pager,
      reverse: store.mangaRtl,
      itemCount: pages.length,
      onPageChanged: (i) {
        _setPage(i);
        // warm up the next page so the turn feels instant
        if (i + 1 < pages.length) {
          precacheImage(NetworkImage(pages[i + 1], headers: headers), context, onError: (_, __) {});
        }
      },
      itemBuilder: (_, i) => InteractiveViewer(
        minScale: 1,
        maxScale: 4,
        child: Center(
          child: Image.network(
            pages[i],
            headers: headers,
            fit: BoxFit.contain,
            width: double.infinity,
            height: double.infinity,
            loadingBuilder: (c, child, prog) => prog == null ? child : const _Spinner(),
            errorBuilder: (c, e, s) => const _BrokenPage(),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class _PageTile extends StatefulWidget {
  final int index;
  final String url;
  final Map<String, String> headers;
  final double width;
  final void Function(int, BuildContext) onMount;
  final void Function(int) onUnmount;
  const _PageTile({
    super.key,
    required this.index,
    required this.url,
    required this.headers,
    required this.width,
    required this.onMount,
    required this.onUnmount,
  });

  @override
  State<_PageTile> createState() => _PageTileState();
}

class _PageTileState extends State<_PageTile> {
  int _try = 0;

  @override
  void initState() {
    super.initState();
    widget.onMount(widget.index, context);
  }

  @override
  void dispose() {
    widget.onUnmount(widget.index);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dpr = MediaQuery.devicePixelRatioOf(context);
    return Image.network(
      widget.url,
      key: ValueKey('img$_try'),
      headers: widget.headers,
      width: widget.width,
      fit: BoxFit.fitWidth,
      cacheWidth: (widget.width * dpr).round().clamp(300, 1400).toInt(),
      gaplessPlayback: true,
      frameBuilder: (c, child, frame, sync) => sync
          ? child
          : AnimatedOpacity(
              opacity: frame == null ? 0 : 1,
              duration: const Duration(milliseconds: 220),
              child: child,
            ),
      loadingBuilder: (c, child, prog) => prog == null
          ? child
          : SizedBox(
              height: widget.width * 1.35,
              child: _Spinner(value: prog.expectedTotalBytes == null
                  ? null
                  : prog.cumulativeBytesLoaded / prog.expectedTotalBytes!),
            ),
      errorBuilder: (c, e, s) => GestureDetector(
        onTap: () => setState(() => _try++),
        child: SizedBox(height: widget.width * .8, child: const _BrokenPage()),
      ),
    );
  }
}

class _Spinner extends StatelessWidget {
  final double? value;
  const _Spinner({this.value});

  @override
  Widget build(BuildContext context) => Center(
        child: SizedBox(
          width: 26,
          height: 26,
          child: CircularProgressIndicator(strokeWidth: 2, value: value, color: P.of(context).ac),
        ),
      );
}

class _BrokenPage extends StatelessWidget {
  const _BrokenPage();

  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.refresh, color: Colors.white54, size: 28),
          const SizedBox(height: 8),
          Text('Couldn’t load this page. Tap to retry.', style: ts(13, color: Colors.white54)),
        ]),
      );
}

class _End extends StatelessWidget {
  final VoidCallback onBack;
  const _End({required this.onBack});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 48, 24, 120),
      child: Column(children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(color: p.ac, shape: BoxShape.circle),
          child: const Icon(Icons.check, color: Color(0xFF171717), size: 30),
        ),
        const SizedBox(height: 14),
        Text('End of chapter', style: ts(18, w: FontWeight.w500, color: Colors.white)),
        const SizedBox(height: 18),
        Tap(
          onTap: onBack,
          label: 'Back to library',
          child: Container(
            height: 46,
            padding: const EdgeInsets.symmetric(horizontal: 26),
            alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0x22FFFFFF), borderRadius: BorderRadius.circular(24)),
            child: Text('Back to library', style: ts(15, color: Colors.white)),
          ),
        ),
      ]),
    );
  }
}

class _Empty extends StatelessWidget {
  final bool loading, failed;
  final VoidCallback onRetry, onOpen;
  const _Empty({required this.loading, required this.failed, required this.onRetry, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: loading
            ? Column(mainAxisSize: MainAxisSize.min, children: [
                const _Spinner(),
                const SizedBox(height: 16),
                Text('Finding the pages…', style: ts(14, color: Colors.white60)),
              ])
            : Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.menu_book_outlined, color: Colors.white54, size: 44),
                const SizedBox(height: 14),
                Text(failed ? 'No pages found on this link' : 'Pages not loaded yet',
                    style: ts(20, w: FontWeight.w500, color: Colors.white)),
                const SizedBox(height: 8),
                Text(
                  'Some sites load their pages with scripts, or need you to sign in. You can open the original site instead.',
                  textAlign: TextAlign.center,
                  style: ts(14, color: Colors.white60, h: 1.4),
                ),
                const SizedBox(height: 22),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  Tap(
                    onTap: onRetry,
                    label: 'Try again',
                    child: Container(
                      height: 46,
                      padding: const EdgeInsets.symmetric(horizontal: 22),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: p.ac, borderRadius: BorderRadius.circular(24)),
                      child: Text('Try again', style: ts(15, w: FontWeight.w500, color: const Color(0xFF171717))),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Tap(
                    onTap: onOpen,
                    label: 'Open original site',
                    child: Container(
                      height: 46,
                      padding: const EdgeInsets.symmetric(horizontal: 22),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: const Color(0x22FFFFFF), borderRadius: BorderRadius.circular(24)),
                      child: Text('Open site', style: ts(15, color: Colors.white)),
                    ),
                  ),
                ]),
              ]),
      ),
    );
  }
}

class _Fade extends StatelessWidget {
  final bool show;
  final Offset offset;
  final Widget child;
  const _Fade({required this.show, required this.offset, required this.child});

  @override
  Widget build(BuildContext context) => IgnorePointer(
        ignoring: !show,
        child: AnimatedSlide(
          offset: show ? Offset.zero : offset,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          child: AnimatedOpacity(
            opacity: show ? 1 : 0,
            duration: const Duration(milliseconds: 200),
            child: child,
          ),
        ),
      );
}

class _Btn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Btn(this.icon, this.label, this.onTap);

  @override
  Widget build(BuildContext context) => Tap(
        onTap: onTap,
        label: label,
        child: SizedBox(width: 42, height: 42, child: Icon(icon, size: 22, color: Colors.white)),
      );
}
