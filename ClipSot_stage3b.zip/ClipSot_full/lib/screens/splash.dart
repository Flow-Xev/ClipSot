import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/logo.dart';

/// The C draws itself, the "saved" dot pops into its opening, then the wordmark
/// types in under it and the tagline fades up. Honours "remove animations".
class Splash extends StatefulWidget {
  final VoidCallback onDone;
  const Splash({super.key, required this.onDone});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  static const _word = 'clipsot';
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2800));
  late final Animation<double> _halo, _ring, _dot, _wdot, _tag, _breath;
  late final List<Animation<double>> _letters;

  CurvedAnimation _iv(double a, double b, Curve curve) =>
      CurvedAnimation(parent: _c, curve: Interval(a, b, curve: curve));

  @override
  void initState() {
    super.initState();
    _halo = _iv(0.0, 0.55, Curves.easeOutCubic);
    _ring = _iv(0.04, 0.44, Curves.easeInOutCubic);
    _dot = _iv(0.40, 0.60, Curves.easeOutBack);
    _breath = _iv(0.58, 0.78, Curves.easeInOutSine);
    _letters = [
      for (var i = 0; i < _word.length; i++) _iv(0.52 + i * 0.03, 0.52 + i * 0.03 + 0.2, Curves.easeOutCubic),
    ];
    _wdot = _iv(0.76, 0.88, Curves.easeOutBack);
    _tag = _iv(0.82, 0.96, Curves.easeOut);
    _c.forward().whenComplete(() {
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final reduce = MediaQuery.of(context).disableAnimations;
    final style = ts(56, w: FontWeight.w500, ls: -2.2, color: p.tx);

    return Scaffold(
      backgroundColor: p.bg,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 260,
              height: 220,
              child: AnimatedBuilder(
                animation: _c,
                builder: (_, __) {
                  final h = reduce ? 1.0 : _halo.value;
                  final r = reduce ? 1.0 : _ring.value;
                  final d = reduce ? 1.0 : _dot.value;
                  // A small settle after the dot lands: grows a touch, then eases back.
                  final b = reduce ? 0.0 : (0.5 - (_breath.value - 0.5).abs()) * 0.08;
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      Opacity(
                        opacity: h.clamp(0.0, 1.0).toDouble(),
                        child: Transform.scale(
                          scale: 0.55 + 0.45 * h,
                          child: Container(
                            width: 210,
                            height: 210,
                            decoration: BoxDecoration(color: alpha(p.ac, .10), shape: BoxShape.circle),
                          ),
                        ),
                      ),
                      Transform.scale(
                        scale: 1 + b,
                        child: ClipSotMark(size: 128, ringColor: p.ac, dotColor: p.tx, ring: r, dot: d),
                      ),
                    ],
                  );
                },
              ),
            ),
            Semantics(
              label: 'clipsot',
              child: ExcludeSemantics(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (var i = 0; i < _word.length; i++)
                      AnimatedBuilder(
                        animation: _letters[i],
                        builder: (_, __) {
                          final t = reduce ? 1.0 : _letters[i].value;
                          return Opacity(
                            opacity: t.clamp(0.0, 1.0).toDouble(),
                            child: Transform.translate(
                              offset: Offset(0, 22 * (1 - t)),
                              child: Text(_word[i], style: style),
                            ),
                          );
                        },
                      ),
                    AnimatedBuilder(
                      animation: _wdot,
                      builder: (_, __) {
                        final double t = reduce ? 1.0 : _wdot.value.clamp(0.0, 1.4).toDouble();
                        return Opacity(
                          opacity: t.clamp(0.0, 1.0).toDouble(),
                          child: Transform.scale(
                            scale: t,
                            child: Text('.', style: style.copyWith(color: p.ac)),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            FadeTransition(
              opacity: reduce ? const AlwaysStoppedAnimation(1.0) : _tag,
              child: Text('Save now. Find anytime.', style: ts(16, color: p.tx2)),
            ),
          ],
        ),
      ),
    );
  }
}
