# One-time Android setup for ClipSot (Windows). Run from the clipsot\ folder.
$ErrorActionPreference = 'Stop'
if (-not (Test-Path android)) {
  flutter create . --org com.clipsot --project-name clipsot --platforms android
}
Remove-Item -Force -ErrorAction SilentlyContinue test\widget_test.dart
Copy-Item -Recurse -Force android_overlay\app\* android\app\
foreach ($f in 'android\app\build.gradle', 'android\app\build.gradle.kts') {
  if (Test-Path $f) { (Get-Content $f -Raw) -replace 'flutter\.minSdkVersion', '26' | Set-Content $f -NoNewline }
}
flutter pub get
Write-Host 'Done. Run: flutter run'
