import 'dart:math' as math;

import 'package:flutter/widgets.dart';

import '../haptics.dart';

/// Gives any scrollable a detent feel: a soft tick every [step] pixels, sharper
/// when the content moves fast, plus a small bump when you hit the top or
/// bottom. Wrap the list (or scroll view) with it.
class HapticScroll extends StatefulWidget {
  final Widget child;

  /// Distance between ticks, in logical pixels.
  final double step;
  const HapticScroll({super.key, required this.child, this.step = 72});

  @override
  State<HapticScroll> createState() => _HapticScrollState();
}

class _HapticScrollState extends State<HapticScroll> {
  double _acc = 0;
  int _lastTickAt = 0;
  bool _edgeBumped = false;

  bool _onNote(ScrollNotification n) {
    // Only the scrollable this widget wraps, not nested horizontal rows.
    if (n.depth != 0 || n.metrics.axis != Axis.vertical) return false;

    if (n is ScrollStartNotification) {
      _acc = 0;
      _edgeBumped = false;
      _lastTickAt = DateTime.now().millisecondsSinceEpoch;
    } else if (n is ScrollUpdateNotification) {
      _acc += (n.scrollDelta ?? 0).abs();
      if (_acc >= widget.step) {
        final now = DateTime.now().millisecondsSinceEpoch;
        final dt = math.max(1, now - _lastTickAt);
        Haptics.scrollTick(_acc / dt);
        _lastTickAt = now;
        _acc = _acc % widget.step;
      }
      if (!n.metrics.atEdge) _edgeBumped = false;
    } else if (n is OverscrollNotification) {
      if (!_edgeBumped && n.overscroll.abs() > 0) {
        _edgeBumped = true;
        Haptics.edge();
      }
    } else if (n is ScrollEndNotification) {
      _acc = 0;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) => NotificationListener<ScrollNotification>(
        onNotification: _onNote,
        child: widget.child,
      );
}
