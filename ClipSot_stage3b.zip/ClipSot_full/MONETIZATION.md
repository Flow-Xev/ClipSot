# Making money with ClipSot

Two income streams are built in. Both are off until you add your own IDs, so a build without them is
completely ad-free and safe to sideload.

| Stream | What it is | Where it appears |
|---|---|---|
| **AdMob native ads** | Small card-style ads that look like a ClipSot card and are labelled "Ad" | Only on Home: one between rows, and up to 3 inside the long grid. Never in the reader, manga reader, video screen, Trash or Search |
| **Remove ads** (one-time purchase) | Non-consumable in-app product | Settings › Support ClipSot (also Restore purchase) |

Honest expectations: native ads pay a few cents to a couple of dollars per 1,000 views (varies a lot by country).
Real money needs thousands of daily users. The *Remove ads* purchase usually earns more per paying user than ads do,
so keep the ads light (that is why there are so few) and let heavy users pay once.

## Set it up (one time)

1. **AdMob account**: https://admob.google.com. Add an app (Android, "not yet published" is fine). Copy the **App ID**
   (`ca-app-pub-XXXXXXXXXXXXXXXX~NNNNNNNNNN`).
2. In that app create an ad unit, format **Native advanced**. Copy the **Ad unit ID** (`ca-app-pub-XXXX/YYYY`).
3. **GitHub repo secrets** (Settings › Secrets and variables › Actions):
   - `ADMOB_APP_ID` = the App ID
   - `ADMOB_NATIVE_ID` = the native ad unit ID
   The workflow puts them into the build. Building locally instead: edit the `APPLICATION_ID` value in
   `android_overlay/app/src/main/AndroidManifest.xml` and run
   `flutter build appbundle --release --dart-define=ADMOB_NATIVE_ID=ca-app-pub-XXXX/YYYY`.
4. **Consent prompt**: in AdMob › Privacy & messaging, create a GDPR message (EEA/UK) and a US-states message, and
   publish them. The app already shows them and a "Ad privacy choices" row in Settings when the law requires it.
5. **Remove ads product**: Play Console › your app › Monetize › In-app products › create product id
   **`remove_ads`**, one-time, set a price (for example $2.99; Play converts it per country). Activate it.
   Purchases only work from a build uploaded to a Play testing track and installed from Play.
6. **Payments + tax profile** in Play Console and AdMob (this is where payouts go; Google needs bank and tax details).
7. **app-ads.txt**: AdMob › Apps › app-ads.txt gives a line to host at `https://your-site/app-ads.txt` and to put as the
   "Developer website" in the Play listing. It protects your ad revenue; ads still run without it but earn less.
8. Link the AdMob app to its Play listing after the first release (AdMob › App settings).

## Rules that protect your account
- Never tap your own live ads. Debug builds use Google's test ad unit automatically.
- Do not put ads next to buttons or over content. The app keeps them in their own card on Home only.
- Keep the Privacy screen and the Play "Data safety" form in step (see PLAY_STORE_CHECKLIST.md).

## Other ideas, only if you want them later
- A "Plus" tier (more backup, sync) as a subscription, once you have people asking for it.
- A tip jar product (consumable in-app item).
