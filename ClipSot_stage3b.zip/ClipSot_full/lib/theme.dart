import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// ClipSot palette (from the design brief).
class P {
  final Color bg, s1, s2, tx, tx2, ac, card, ct;
  const P({
    required this.bg,
    required this.s1,
    required this.s2,
    required this.tx,
    required this.tx2,
    required this.ac,
    required this.card,
    required this.ct,
  });

  static const dark = P(
    bg: Color(0xFF101010),
    s1: Color(0xFF202020),
    s2: Color(0xFF292929),
    tx: Color(0xFFF4F3F0),
    tx2: Color(0xFF92918E),
    ac: Color(0xFFC9A574),
    card: Color(0xFFE8E7E2),
    ct: Color(0xFF171717),
  );

  static const light = P(
    bg: Color(0xFFF4F3EF),
    s1: Color(0xFFE8E7E2),
    s2: Color(0xFFFFFFFF),
    tx: Color(0xFF171717),
    tx2: Color(0xFF777671),
    ac: Color(0xFFA98250),
    card: Color(0xFFFFFFFF),
    ct: Color(0xFF171717),
  );

  static P of(BuildContext c) =>
      Theme.of(c).brightness == Brightness.dark ? dark : light;
}

/// Colors used by the light bottom sheets (same in both themes, as in the design).
const kSheetBg = Color(0xFFEDECE7);
const kSheetInk = Color(0xFF171717);
const kSheetChip = Color(0xFFDDDCD6);
const kDanger = Color(0xFFB3392F);

/// Colour with opacity, without using deprecated APIs.
Color alpha(Color c, double o) => c.withAlpha((o * 255).round().clamp(0, 255));

TextStyle ts(
  double size, {
  FontWeight w = FontWeight.w400,
  double ls = 0,
  Color? color,
  double? h,
}) =>
    GoogleFonts.interTight(
      fontSize: size,
      fontWeight: w,
      letterSpacing: ls,
      color: color,
      height: h,
    );

/// Screens fade in with a tiny upward drift. Skipped when the phone asks for
/// reduced motion.
class SoftTransitions extends PageTransitionsBuilder {
  const SoftTransitions();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    if (MediaQuery.disableAnimationsOf(context)) return child;
    final a = animation.drive(CurveTween(curve: Curves.easeOutCubic));
    return FadeTransition(
      opacity: a,
      child: SlideTransition(
        position: a.drive(Tween<Offset>(begin: const Offset(0, .03), end: Offset.zero)),
        child: child,
      ),
    );
  }
}

ThemeData buildTheme(Brightness b) {
  final p = b == Brightness.dark ? P.dark : P.light;
  final base = ThemeData(brightness: b, useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: p.bg,
    colorScheme: ColorScheme.fromSeed(seedColor: p.ac, brightness: b)
        .copyWith(surface: p.bg, primary: p.ac),
    textTheme: GoogleFonts.interTightTextTheme(base.textTheme)
        .apply(bodyColor: p.tx, displayColor: p.tx),
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: SoftTransitions(),
      TargetPlatform.iOS: SoftTransitions(),
    }),
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    splashColor: Colors.transparent,
  );
}
