import '../models.dart';

final _urlRe = RegExp(r'''https?://[^\s<>"'\)\]]+''', caseSensitive: false);

/// Finds the first link in [text] (shared text, clipboard, selected text).
/// Accepts bare domains like "example.com/page" when the text is only a link.
String? extractLink(String? text) {
  if (text == null) return null;
  final t = text.trim();
  if (t.isEmpty) return null;
  final m = _urlRe.firstMatch(t);
  if (m != null) return m.group(0)!.replaceAll(RegExp(r'[.,;:!?]+$'), '');
  if (!t.contains(RegExp(r'\s')) && Item.fromUrl(t, '', []) != null) return t;
  return null;
}
