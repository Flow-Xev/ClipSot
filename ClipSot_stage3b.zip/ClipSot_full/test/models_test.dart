import 'package:clipsot/models.dart';
import 'package:clipsot/panel/link_utils.dart';
import 'package:clipsot/remind.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Item.fromUrl', () {
    test('accepts a normal link and derives title + source', () {
      final it = Item.fromUrl('https://www.designnotes.co/a-quieter-way', '', ['Research'])!;
      expect(it.src, 'designnotes.co');
      expect(it.title, 'A quieter way');
      expect(it.type, 'article');
      expect(it.cols, ['Research']);
    });

    test('adds https to bare domains', () {
      expect(Item.fromUrl('example.com/post', '', [])!.url, 'https://example.com/post');
    });

    test('detects video and pdf', () {
      expect(Item.fromUrl('https://youtu.be/abc', '', [])!.type, 'video');
      expect(Item.fromUrl('https://x.org/paper.pdf', '', [])!.type, 'document');
    });

    test('rejects junk', () {
      expect(Item.fromUrl('', '', []), isNull);
      expect(Item.fromUrl('not a link', '', []), isNull);
      expect(Item.fromUrl('localhost', '', []), isNull);
    });
  });

  test('Item JSON round-trip keeps reminder, progress and file path', () {
    final it = Item(
      id: 5, title: 't', src: 's', url: 'https://a.b/c', type: 'article', saved: DateTime(2026, 1, 2),
      remind: DateTime(2026, 2, 3, 9), progress: .4, opened: 123, path: '/x/y.png',
    );
    final back = Item.fromJson(it.toJson());
    expect(back.remind, DateTime(2026, 2, 3, 9));
    expect(back.progress, .4);
    expect(back.opened, 123);
    expect(back.path, '/x/y.png');
  });

  group('extractLink', () {
    test('finds a link inside shared text and trims punctuation', () {
      expect(extractLink('Check this out https://example.com/a?b=1, nice'), 'https://example.com/a?b=1');
    });
    test('accepts a bare domain only when it is the whole text', () {
      expect(extractLink('example.com/x'), 'example.com/x');
      expect(extractLink('see example.com/x please'), isNull);
    });
    test('returns null for nothing', () {
      expect(extractLink(null), isNull);
      expect(extractLink('   '), isNull);
    });
  });

  group('remindOptions', () {
    test('weekday morning offers evening, tomorrow, weekend, next week', () {
      final o = remindOptions(DateTime(2026, 11, 23, 10)); // Monday
      expect(o.map((e) => e.label), ['This evening', 'Tomorrow', 'This weekend', 'Next week']);
      expect(o[0].at, DateTime(2026, 11, 23, 18));
      expect(o[1].at, DateTime(2026, 11, 24, 9));
      expect(o[2].at, DateTime(2026, 11, 28, 10));
      expect(o[3].at, DateTime(2026, 11, 30, 9));
    });

    test('Saturday has no weekend option and late evening has no evening option', () {
      final o = remindOptions(DateTime(2026, 11, 21, 19)); // Saturday 19:00
      expect(o.map((e) => e.label), ['Tomorrow', 'Next week']);
      expect(o[1].at, DateTime(2026, 11, 23, 9));
    });

    test('labels', () {
      final now = DateTime(2026, 11, 23, 10);
      expect(remindLabel(DateTime(2026, 11, 23, 18), now), 'Today, 18:00');
      expect(remindLabel(DateTime(2026, 11, 24, 9), now), 'Tomorrow, 9:00');
      expect(remindLabel(DateTime(2026, 11, 28, 10), now), 'Sat 28/11, 10:00');
    });
  });
}
