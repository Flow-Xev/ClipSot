import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/common.dart';
import 'collections.dart';
import 'home.dart';
import 'search.dart';
import 'settings.dart';
import 'sheets.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;

  void _go(int t) => setState(() => _tab = t);

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final pages = <Widget>[
      HomeScreen(onSearch: () => _go(2), onSettings: () => _go(3)),
      const CollectionsScreen(),
      const SearchScreen(),
      const SettingsScreen(),
    ];

    return PopScope(
      canPop: _tab == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _go(0);
      },
      child: Scaffold(
        backgroundColor: p.bg,
        body: SafeArea(
          child: Stack(
            children: [
              Column(children: [
                Expanded(child: IndexedStack(index: _tab, children: pages)),
                _NavPill(index: _tab, onTap: _go),
              ]),
              if (_tab == 0)
                Positioned(
                  right: 20,
                  bottom: 96,
                  child: Tap(
                    onTap: () => showAddSheet(context),
                    label: 'Save a link',
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: p.ac,
                        shape: BoxShape.circle,
                        boxShadow: const [
                          BoxShadow(color: Color(0x59000000), blurRadius: 20, offset: Offset(0, 6)),
                        ],
                      ),
                      child: const Icon(Icons.add, size: 28, color: Color(0xFF171717)),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavPill extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const _NavPill({required this.index, required this.onTap});

  static const _items = [
    (Icons.home_outlined, Icons.home_filled, 'Home'),
    (Icons.collections_bookmark_outlined, Icons.collections_bookmark, 'Collections'),
    (Icons.search, Icons.search, 'Search'),
    (Icons.person_outline, Icons.person, 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
      decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(26)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          for (var i = 0; i < _items.length; i++)
            Tap(
              onTap: () => onTap(i),
              label: _items[i].$3,
              child: SizedBox(
                width: 72,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(i == index ? _items[i].$2 : _items[i].$1,
                      size: 22, color: i == index ? p.tx : p.tx2),
                  const SizedBox(height: 4),
                  Text(_items[i].$3,
                      style: ts(11,
                          w: i == index ? FontWeight.w600 : FontWeight.w400,
                          color: i == index ? p.tx : p.tx2)),
                ]),
              ),
            ),
        ],
      ),
    );
  }
}
