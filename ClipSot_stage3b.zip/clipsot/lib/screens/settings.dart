import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../native.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'permissions.dart';
import 'sheets.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsState();
}

class _SettingsState extends State<SettingsScreen> with WidgetsBindingObserver {
  bool _pendingNotif = false;
  bool _pendingHandle = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// Permission dialogs and system settings pages leave the app; finish what
  /// the person asked for when they come back.
  @override
  Future<void> didChangeAppLifecycleState(AppLifecycleState state) async {
    if (state != AppLifecycleState.resumed || !mounted) return;
    final s = StoreScope.read(context);
    if (_pendingNotif) {
      _pendingNotif = false;
      if (await Native.notifGranted()) s.setPrefs(n: true);
    }
    if (_pendingHandle) {
      _pendingHandle = false;
      if (await Native.overlayGranted() && await Native.setHandle(true)) s.setHandle(true);
    }
  }

  Future<void> _toggleNotif(Store s, bool v) async {
    if (!v) {
      s.setPrefs(n: false);
      return;
    }
    if (await Native.notifGranted()) {
      s.setPrefs(n: true);
    } else if (s.notifAsked) {
      if (mounted) toast(context, 'Allow notifications for ClipSot in system settings');
      await Native.openNotifSettings();
      _pendingNotif = true;
    } else {
      s.setNotifAsked();
      _pendingNotif = true;
      await Native.requestNotif();
    }
  }

  Future<void> _toggleHandle(Store s, bool v) async {
    if (!v) {
      await Native.setHandle(false);
      s.setHandle(false);
      return;
    }
    if (!await Native.overlayGranted()) {
      if (!mounted) return;
      final go = await confirm(
        context,
        'Allow display over other apps?',
        'The edge handle floats above other apps, so Android asks for this permission. '
        'Turn on ClipSot on the next screen, then come back.',
        'Continue',
        danger: false,
      );
      if (!go) return;
      _pendingHandle = true;
      await Native.openOverlaySettings();
      return;
    }
    if (await Native.setHandle(true)) s.setHandle(true);
  }

  Future<void> _exportFile(Store s) async {
    if (s.items.isEmpty && s.notes.isEmpty) {
      toast(context, 'Nothing to export yet');
      return;
    }
    final json = await s.exportBackup();
    final d = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    final name = 'clipsot-backup-${d.year}${two(d.month)}${two(d.day)}.json';
    final f = File('${(await getTemporaryDirectory()).path}/$name');
    await f.writeAsString(json);
    await Share.shareXFiles([XFile(f.path, mimeType: 'application/json')], subject: 'ClipSot backup');
  }

  Future<void> _restore(Store s) async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
    final path = r?.files.single.path;
    if (path == null || !mounted) return;
    final res = await s.restoreBackup(await File(path).readAsString());
    if (!mounted) return;
    toast(
      context,
      res == null
          ? 'That isn’t a ClipSot backup'
          : (res.items + res.notes == 0 ? 'Nothing new to restore' : 'Restored ${res.items} links and ${res.notes} notes'),
    );
  }

  Future<void> _addTile(String which) async {
    final r = await Native.requestTile(which);
    if (!mounted) return;
    toast(
      context,
      switch (r) {
        'added' => 'Tile added to Quick Settings',
        'already' => 'That tile is already in Quick Settings',
        'dismissed' => 'Tile not added',
        _ => 'Swipe down twice, tap the pencil, and drag the ClipSot tile in',
      },
    );
  }

  String _themeLabel(ThemeMode m) =>
      m == ThemeMode.dark ? 'Dark' : (m == ThemeMode.light ? 'Light' : 'System');

  Widget _smallBtn(P p, String label, VoidCallback onTap) => Tap(
        onTap: onTap,
        label: label,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(20)),
          child: Text(label, style: ts(14, color: p.tx)),
        ),
      );

  String _size(int b) => b < 1024 ? '$b B' : (b < 1048576 ? '${(b / 1024).toStringAsFixed(1)} KB' : '${(b / 1048576).toStringAsFixed(1)} MB');

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final s = StoreScope.of(context);

    Widget row(IconData icon, String label, {String? value, String? sub, Widget? trailing, VoidCallback? onTap, Color? color}) {
      return Tap(
        onTap: onTap,
        label: label,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Row(children: [
            Icon(icon, size: 22, color: color ?? p.tx),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: ts(16, color: color ?? p.tx)),
                if (sub != null) Text(sub, style: ts(12.5, color: p.tx2)),
              ]),
            ),
            if (value != null) Text(value, style: ts(14, color: p.tx2)),
            if (trailing != null) trailing,
            if (trailing == null && onTap != null && color == null)
              Icon(Icons.chevron_right, size: 20, color: p.tx2),
          ]),
        ),
      );
    }

    Widget rule() => Divider(height: 1, color: p.s1);

    Widget heading(String t) => Padding(
          padding: const EdgeInsets.only(top: 22, bottom: 4),
          child: Text(t.toUpperCase(), style: ts(12, color: p.tx2, ls: .6)),
        );

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 140),
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 8),
          child: Text('Settings', style: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx)),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Row(children: [
            Container(
              width: 68,
              height: 68,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: p.ac, shape: BoxShape.circle),
              child: Text('C', style: ts(26, w: FontWeight.w600, color: const Color(0xFF171717))),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Local library', style: ts(22, color: p.tx)),
                Text('No account · ${s.items.length} saved · ${s.notes.length} notes',
                    style: ts(13, color: p.tx2)),
              ]),
            ),
          ]),
        ),
        rule(),
        heading('General'),
        row(Icons.wb_sunny_outlined, 'Appearance', value: _themeLabel(s.themeMode), onTap: () {
          showChoice(
            context,
            title: 'Appearance',
            options: const ['Dark', 'Light', 'System'],
            current: _themeLabel(s.themeMode),
            onPick: (v) => s.setTheme(v == 'Dark' ? ThemeMode.dark : (v == 'Light' ? ThemeMode.light : ThemeMode.system)),
          );
        }),
        rule(),
        row(Icons.folder_outlined, 'Default collection', value: s.defaultCol, onTap: () {
          showChoice(
            context,
            title: 'Default collection',
            options: s.cols,
            current: s.defaultCol,
            onPick: (v) => s.setPrefs(defCol: v),
          );
        }),
        rule(),
        row(Icons.edit_outlined, 'Note field when saving',
            sub: 'Show an optional note in the save sheet',
            trailing: Sw(on: s.askNote, onChanged: (v) => s.setPrefs(ask: v), label: 'Note field when saving')),
        rule(),
        row(Icons.article_outlined, 'Fetch article text',
            sub: 'Get the title and reader text when you save a link',
            trailing: Sw(on: s.fetchText, onChanged: s.setFetchText, label: 'Fetch article text')),
        heading('Reminders'),
        row(Icons.notifications_none, 'Notifications',
            sub: 'Reminders you set, styled like the app',
            trailing: Sw(on: s.notif, onChanged: (v) => _toggleNotif(s, v), label: 'Notifications')),
        rule(),
        row(Icons.auto_awesome_outlined, 'Rediscovery reminders',
            sub: 'A gentle nudge about things you forgot',
            trailing: Sw(
                on: s.rediscovery,
                onChanged: (v) async {
                  if (v && !s.notif) await _toggleNotif(s, true);
                  s.setPrefs(rd: v);
                },
                label: 'Rediscovery reminders')),
        if (s.rediscovery) ...[
          rule(),
          row(Icons.schedule, 'Frequency', value: s.rdFreq, onTap: () {
            showChoice(
              context,
              title: 'Remind me',
              options: const ['Daily', 'Weekly', 'Monthly'],
              current: s.rdFreq,
              onPick: (v) => s.setPrefs(freq: v),
            );
          }),
        ],
        rule(),
        row(Icons.notifications_active_outlined, 'Send a test notification', onTap: () async {
          if (!await Native.notifGranted()) {
            if (context.mounted) toast(context, 'Turn on notifications first');
            return;
          }
          Native.testNotification();
        }),
        heading('Quick access'),
        row(Icons.view_sidebar_outlined, 'Link side panel',
            sub: 'In any app, long-press a link › Share › ClipSot. Or select link text › Save to ClipSot.'),
        rule(),
        row(Icons.bookmark_add_outlined, 'Save link tile',
            sub: 'Quick Settings tile that saves the copied link',
            trailing: _smallBtn(p, 'Add', () => _addTile('save'))),
        rule(),
        row(Icons.auto_awesome_outlined, 'Surprise me tile',
            sub: 'Quick Settings tile that picks something to read',
            trailing: _smallBtn(p, 'Add', () => _addTile('surprise'))),
        rule(),
        row(Icons.keyboard_double_arrow_left, 'Edge handle',
            sub: 'A small tab on the screen edge. Needs Display over other apps.',
            trailing: Sw(on: s.handle, onChanged: (v) => _toggleHandle(s, v), label: 'Edge handle')),
        rule(),
        row(Icons.verified_user_outlined, 'Permissions', onTap: () {
          Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const PermissionsScreen()));
        }),
        heading('Your data'),
        row(Icons.ios_share, 'Back up library', value: 'File', sub: 'Links, notes and saved files', onTap: () => _exportFile(s)),
        rule(),
        row(Icons.settings_backup_restore, 'Restore from backup', sub: 'Adds to your library, never overwrites', onTap: () => _restore(s)),
        rule(),
        row(Icons.download_outlined, 'Import links', onTap: () => showImportSheet(context)),
        rule(),
        row(Icons.storage_outlined, 'Storage', value: _size(s.storageBytes), onTap: () {
          toast(context, 'Stored on this device only');
        }),
        heading('About'),
        row(Icons.shield_outlined, 'Privacy', onTap: () {
          showDialog<void>(
            context: context,
            builder: (_) => AlertDialog(
              backgroundColor: kSheetBg,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              title: Text('Privacy', style: ts(20, w: FontWeight.w500, color: kSheetInk)),
              content: Text(
                'No account. No ads. No analytics. Your library lives on this device and is never uploaded. '
                'ClipSot only contacts a website when you open a link, or when you save one while “Fetch article text” is on. Nothing else leaves the device.',
                style: ts(14, color: const Color(0xFF55544F), h: 1.4),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Close', style: ts(15, color: kSheetInk)),
                ),
              ],
            ),
          );
        }),
        rule(),
        row(Icons.info_outline, 'About ClipSot', value: 'v0.4', onTap: () {
          toast(context, 'ClipSot · Save now. Find anytime.');
        }),
        rule(),
        row(Icons.description_outlined, 'Open-source licenses', onTap: () {
          showLicensePage(context: context, applicationName: 'ClipSot', applicationVersion: '0.4');
        }),
        rule(),
        row(Icons.delete_outline, 'Delete all data', color: kDanger, onTap: () async {
          final m = ScaffoldMessenger.of(context);
          final ok = await confirm(
            context,
            'Delete everything?',
            'All saved items, notes and collections will be removed from this device. This can’t be undone.',
            'Delete all',
          );
          if (!ok) return;
          s.deleteAll();
          toastWith(m, p, 'Library cleared');
        }),
      ],
    );
  }
}
