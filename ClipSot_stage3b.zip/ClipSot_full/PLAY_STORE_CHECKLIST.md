# ClipSot: Google Play checklist

Nobody can guarantee approval; these are the things Play reviews for an app like this.
Items marked **YOU** need you in Play Console or AdMob. The rest is already done in the code.
Money setup is in MONETIZATION.md.

## Already done in the app
- [x] No account, no analytics. The library stays on the device.
- [x] Ads: Google AdMob native ads, only on Home, behind Google's consent prompt (UMP). Max ad rating PG. Off in builds without your IDs.
- [x] "Ad privacy choices" row in Settings (shown where the law needs it), "Remove ads" and "Restore purchase".
- [x] Privacy screen in Settings that matches what the app really does (including ads and the advertising ID).
- [x] Deleting is reversible: Trash for 30 days, Undo after every delete, "Empty Trash" asks first.
- [x] Haptics use only the normal `VIBRATE` permission, respect the system setting, and can be turned off.
- [x] The paper-peel animation is skipped when the phone's "remove animations" setting is on.
- [x] Clipboard is read only when the Add sheet opens, to offer a copied link (never in the background, never sent anywhere).
- [x] No "display over other apps" permission and no foreground service (the old edge handle is gone).
- [x] Optional permissions (notifications, accessibility link grabber) are asked only when the person turns the feature on.
- [x] The workflow builds an **AAB** (for Play) and an APK (for sideloading).

## YOU: needed in Play Console
- [ ] **Privacy policy URL** (required: INTERNET, ads, notifications). Host a page that says what the Privacy screen says, including AdMob and the advertising ID.
- [ ] **Data safety form**: declare *Device or other IDs (advertising ID)* collected and shared for **Advertising**, and *Purchase history* handled by Google Play. Library content, notes and files: not collected.
- [ ] **Advertising ID** declaration (App content): "Yes, uses advertising ID" for Advertising.
- [ ] **Accessibility API declaration**: the optional link grabber uses the AccessibilityService. Explain: it reads the page address on screen only when the person taps the Save link tile, stores and sends nothing, off by default. Attach a short screen recording. If you want the fastest first approval, ship without it (remove the service from the manifest and the Settings row) and add it in an update.
- [ ] Content rating questionnaire: reader / bookmark tool, user-chosen web content, contains ads.
- [ ] Target API level: build with the latest stable Flutter so `targetSdk` meets Play's current requirement (App content shows it).
- [ ] Increase `version:` in pubspec.yaml (the number after `+`) for every upload.
- [ ] Upload the **AAB** from the workflow (`ClipSot-Release-AAB`). Turn on Play App Signing.
- [ ] Store listing: icon (512 px, in `brand/`), feature graphic, at least 2 phone screenshots, short and full description.
- [ ] New personal developer accounts must run a closed test with 12+ testers for 14 days before applying for production. Start it early.

## Manga: the one real policy risk
- Play's Intellectual Property policy: the app must not host or distribute other people's copyrighted work, and must not encourage piracy.
- ClipSot saves a link and reads pages on the person's own device, like a browser reading mode (CBZ files are the person's own files). Keep it that way:
  - Do not ship a built-in list of manga sites, a search, or a catalogue.
  - Do not name or advertise pirate sites in the listing, screenshots or app text.
  - Keep a visible way to report content / contact you in the store listing.
- Because the app now has ads, Google looks harder at this. Do not run ads in the manga reader (the app does not).
