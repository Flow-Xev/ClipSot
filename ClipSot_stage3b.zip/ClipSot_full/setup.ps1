# One-time Android setup for ClipSot (Windows). Run from the clipsot\ folder.
$ErrorActionPreference = 'Stop'
if (-not (Test-Path android)) {
  flutter create . --org com.clipsot --project-name clipsot --platforms android
}
Remove-Item -Force -ErrorAction SilentlyContinue test\widget_test.dart
Copy-Item -Recurse -Force android_overlay\app\* android\app\
foreach ($f in 'android\app\build.gradle', 'android\app\build.gradle.kts') {
  if (Test-Path $f) { (Get-Content $f -Raw) -replace 'flutter\.minSdkVersion', '26' | Set-Content $f -NoNewline }
}
# Release builds: no R8 shrinking (it breaks the WorkManager database and the app crashes on opening).
foreach ($f in 'android\app\build.gradle.kts', 'android\app\build.gradle') {
  if (Test-Path $f) {
    $t = Get-Content $f -Raw
    if ($t -notmatch 'clipsot-no-shrink') {
      $line = if ($f.EndsWith('.kts')) { "isMinifyEnabled = false`n            isShrinkResources = false" } else { "minifyEnabled false`n            shrinkResources false" }
      $t = [regex]::Replace($t, '(buildTypes\s*\{\s*release\s*\{)', "`$1`n            // clipsot-no-shrink`n            $line", 1)
      Set-Content $f $t -NoNewline
    }
    break
  }
}
flutter pub get
Write-Host 'Done. Run: flutter run'
