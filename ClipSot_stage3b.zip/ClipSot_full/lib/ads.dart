import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

import 'store.dart';

/// Google's public TEST native ad unit. Debug builds always use it, so you never
/// click your own live ads (which Google bans accounts for).
const _testNativeUnit = 'ca-app-pub-3940256099942544/2247696110';

/// Your real native ad unit, passed at build time:
///   flutter build apk --release --dart-define=ADMOB_NATIVE_ID=ca-app-pub-XXXX/YYYY
/// (the GitHub workflow does this from the ADMOB_NATIVE_ID secret). Empty = no ads.
const _liveNativeUnit = String.fromEnvironment('ADMOB_NATIVE_ID');

/// Product id of the one-time "Remove ads" purchase. Create it in Play Console
/// (Monetize › In-app products) with exactly this id.
const kRemoveAdsId = 'remove_ads';

/// Ads: consent first (Google's UMP prompt), then the ad SDK. Nothing is requested
/// until the person has been through the prompt where the law needs one.
class Ads extends ChangeNotifier {
  Ads._();
  static final Ads I = Ads._();

  bool _started = false;

  /// True once consent allows ad requests and the SDK is ready.
  bool ready = false;

  /// True when the person must be able to reopen the consent choices (EEA / UK and similar).
  bool privacyOptions = false;

  String get nativeUnit => kDebugMode ? _testNativeUnit : _liveNativeUnit;

  bool get canShow => ready && nativeUnit.isNotEmpty;

  Future<void> start() async {
    if (_started || defaultTargetPlatform != TargetPlatform.android) return;
    _started = true;
    try {
      ConsentInformation.instance.requestConsentInfoUpdate(
        ConsentRequestParameters(),
        () async {
          await ConsentForm.loadAndShowConsentFormIfRequired((FormError? _) => _after());
        },
        (FormError _) => _after(),
      );
    } catch (_) {
      _after();
    }
  }

  Future<void> _after() async {
    try {
      final can = await ConsentInformation.instance.canRequestAds();
      privacyOptions = await ConsentInformation.instance.getPrivacyOptionsRequirementStatus() ==
          PrivacyOptionsRequirementStatus.required;
      if (can && !ready) {
        await MobileAds.instance.updateRequestConfiguration(
          RequestConfiguration(maxAdContentRating: MaxAdContentRating.pg),
        );
        await MobileAds.instance.initialize();
        ready = true;
      }
    } catch (_) {}
    notifyListeners();
  }

  /// Settings › Ad privacy choices.
  Future<void> showPrivacyOptions() async {
    try {
      await ConsentForm.showPrivacyOptionsForm((FormError? _) => _after());
    } catch (_) {}
  }
}

/// The one-time "Remove ads" purchase (Google Play Billing).
class Billing extends ChangeNotifier {
  Billing._();
  static final Billing I = Billing._();

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;
  Store? _store;

  ProductDetails? product;
  bool available = false;
  bool busy = false;

  /// A message for the screen to show once (then cleared).
  String? message;

  Future<void> start(Store store) async {
    if (_sub != null || defaultTargetPlatform != TargetPlatform.android) return;
    _store = store;
    try {
      _sub = _iap.purchaseStream.listen(_onPurchases, onError: (_) {});
      available = await _iap.isAvailable();
      if (available) {
        final r = await _iap.queryProductDetails({kRemoveAdsId});
        if (r.productDetails.isNotEmpty) product = r.productDetails.first;
      }
    } catch (_) {}
    notifyListeners();
  }

  /// Price text from Google Play (already in the person's currency), or null if unavailable.
  String? get price => product?.price;

  Future<void> buy() async {
    final pd = product;
    if (pd == null || busy) return;
    busy = true;
    notifyListeners();
    try {
      await _iap.buyNonConsumable(purchaseParam: PurchaseParam(productDetails: pd));
    } catch (_) {
      busy = false;
      message = 'Couldn’t start the purchase';
      notifyListeners();
    }
  }

  Future<void> restore() async {
    if (busy) return;
    busy = true;
    notifyListeners();
    try {
      await _iap.restorePurchases();
      // The result arrives on the purchase stream. If nothing comes back, stop waiting.
      Future<void>.delayed(const Duration(seconds: 6), () {
        if (busy) {
          busy = false;
          message ??= 'No earlier purchase found on this Google account';
          notifyListeners();
        }
      });
    } catch (_) {
      busy = false;
      message = 'Couldn’t reach Google Play';
      notifyListeners();
    }
  }

  Future<void> _onPurchases(List<PurchaseDetails> list) async {
    for (final d in list) {
      if (d.productID == kRemoveAdsId) {
        switch (d.status) {
          case PurchaseStatus.purchased:
          case PurchaseStatus.restored:
            _store?.setAdsRemoved(true);
            message = 'Thank you! Ads are off.';
            busy = false;
          case PurchaseStatus.error:
            message = 'The purchase didn’t go through';
            busy = false;
          case PurchaseStatus.canceled:
            busy = false;
          case PurchaseStatus.pending:
            message = 'Waiting for Google Play to confirm';
        }
      }
      if (d.pendingCompletePurchase) {
        try {
          await _iap.completePurchase(d);
        } catch (_) {}
      }
    }
    notifyListeners();
  }
}
