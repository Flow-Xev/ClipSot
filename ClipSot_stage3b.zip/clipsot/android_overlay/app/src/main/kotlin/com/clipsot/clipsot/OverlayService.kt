package com.clipsot.clipsot

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * Optional edge handle: a slim tab on the right edge of the screen. Tapping it opens the
 * side panel with the link on the clipboard. Drag it up or down to move it.
 * Needs "Display over other apps"; that permission also lets the panel open from here.
 */
class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var view: View? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        Notifs.channels(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, Notifs.CH_HANDLE)
            .setSmallIcon(R.drawable.ic_stat_clipsot)
            .setColor(Notifs.ACCENT)
            .setContentTitle("Quick-save handle is on")
            .setContentText("Tap the edge tab in any app to save a copied link")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, n)
        if (Settings.canDrawOverlays(this)) addHandle() else stopSelf()
        return START_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addHandle() {
        if (view != null) return
        val manager = getSystemService(WindowManager::class.java).also { wm = it }
        val maxY = resources.displayMetrics.heightPixels - dp(120)
        val lp = WindowManager.LayoutParams(
            dp(28), dp(96),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            y = getSharedPreferences("clipsot_native", MODE_PRIVATE).getInt("handle_y", resources.displayMetrics.heightPixels / 3)
                .coerceIn(0, maxY)
        }
        val pill = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Notifs.ACCENT)
                alpha = 215
                val r = dp(4).toFloat()
                cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            }
        }
        val root = FrameLayout(this).apply {
            addView(pill, FrameLayout.LayoutParams(dp(7), dp(64), Gravity.END or Gravity.CENTER_VERTICAL))
            contentDescription = "ClipSot quick save"
        }
        root.setOnTouchListener(object : View.OnTouchListener {
            var downY = 0f
            var startY = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downY = e.rawY; startY = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = e.rawY - downY
                        if (abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.y = (startY + dy).toInt().coerceIn(0, maxY)
                            manager.updateViewLayout(v, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) getSharedPreferences("clipsot_native", MODE_PRIVATE).edit().putInt("handle_y", lp.y).apply()
                        else {
                            v.performClick()
                            startActivity(
                                Intent(this@OverlayService, PanelActivity::class.java)
                                    .putExtra("mode", "clipboard")
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            )
                        }
                    }
                }
                return true
            }
        })
        manager.addView(root, lp)
        view = root
    }

    override fun onDestroy() {
        view?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        view = null
        super.onDestroy()
    }

    companion object {
        private fun prefs(c: Context) = c.getSharedPreferences("clipsot_native", MODE_PRIVATE)
        fun wanted(c: Context) = prefs(c).getBoolean("handle", false)

        fun start(c: Context) { c.startForegroundService(Intent(c, OverlayService::class.java)) }

        /** Returns the real state: false when the overlay permission is missing. */
        fun set(c: Context, on: Boolean): Boolean {
            if (on && !Settings.canDrawOverlays(c)) return false
            prefs(c).edit().putBoolean("handle", on).apply()
            if (on) start(c) else c.stopService(Intent(c, OverlayService::class.java))
            return on
        }
    }
}
