import 'package:flutter/material.dart';

import '../native.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Shows what Android lets ClipSot do, and why each permission exists.
class PermissionsScreen extends StatefulWidget {
  const PermissionsScreen({super.key});

  @override
  State<PermissionsScreen> createState() => _PermissionsState();
}

class _PermissionsState extends State<PermissionsScreen> with WidgetsBindingObserver {
  bool _notif = false;
  bool _a11y = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    final n = await Native.notifGranted();
    final o = await Native.a11yEnabled();
    if (mounted) {
      setState(() {
        _notif = n;
        _a11y = o;
      });
    }
  }

  Widget _card(P p, {required IconData icon, required String title, required String body, required bool on, required String action, required VoidCallback onTap}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(22)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, size: 22, color: p.tx),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: ts(16.5, w: FontWeight.w500, color: p.tx))),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: on ? p.ac : p.s2, borderRadius: BorderRadius.circular(12)),
            child: Text(on ? 'Allowed' : 'Off', style: ts(12, w: FontWeight.w500, color: on ? const Color(0xFF171717) : p.tx2)),
          ),
        ]),
        const SizedBox(height: 8),
        Text(body, style: ts(13.5, h: 1.4, color: p.tx2)),
        const SizedBox(height: 12),
        Tap(
          onTap: onTap,
          label: action,
          child: Container(
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: on ? p.s2 : p.ac, borderRadius: BorderRadius.circular(22)),
            child: Text(action, style: ts(15, w: FontWeight.w500, color: on ? p.tx : const Color(0xFF171717))),
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final s = StoreScope.of(context);
    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
          children: [
            Row(children: [
              RoundIcon(Icons.arrow_back, label: 'Back', onTap: () => Navigator.pop(context)),
            ]),
            Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 18),
              child: Text('Permissions', style: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx)),
            ),
            _card(
              p,
              icon: Icons.notifications_none,
              title: 'Notifications',
              body: 'Used for the reminders you set and optional rediscovery nudges. ClipSot never sends anything else.',
              on: _notif,
              action: _notif ? 'Manage in system settings' : 'Allow notifications',
              onTap: () async {
                if (_notif || s.notifAsked) {
                  await Native.openNotifSettings();
                } else {
                  s.setNotifAsked();
                  await Native.requestNotif();
                }
              },
            ),
            _card(
              p,
              icon: Icons.link,
              title: 'Link grabber (Accessibility)',
              body: 'Optional. Lets the Save link tile read the address of the page on screen, so you do not copy and paste. '
                  'It looks only at the address bar and visible links, only when you tap the tile. Nothing is recorded or uploaded.',
              on: _a11y,
              action: _a11y ? 'Manage in system settings' : 'Open Accessibility settings',
              onTap: Native.openA11ySettings,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                'Without the link grabber, the Save link tile falls back to the clipboard. Android only lets an app read it while it is on screen, '
                'so it is read at the moment you open the sheet, and nothing is uploaded.',
                style: ts(13, h: 1.45, color: p.tx2),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
