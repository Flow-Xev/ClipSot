import 'dart:io';

import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:video_player/video_player.dart';

import '../models.dart';
import '../sources.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/cover.dart';
import 'sheets.dart';

/// Saved videos and audio.
///
/// - Files on this device, and direct links to a video or audio file, play right here.
/// - Links to sites (YouTube, Vimeo and so on) show their picture and open in the
///   site's own app, because those services only allow playback there.
class VideoScreen extends StatefulWidget {
  final int id;
  const VideoScreen({super.key, required this.id});

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  final _note = TextEditingController();
  bool _init = false;

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  bool _playable(Item it) {
    if (it.isFile) return true;
    final e = extOf(Uri.tryParse(it.url)?.path ?? '');
    return kVideoExt.contains(e) || kAudioExt.contains(e);
  }

  void _open(Item it) {
    if (it.isFile) {
      OpenFilex.open(it.path!).then((r) {
        if (r.type != ResultType.done && mounted) toast(context, 'No app found to open this file');
      });
    } else {
      openExternal(context, it.url);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final it = store.byId(widget.id);
    if (it == null) return Scaffold(backgroundColor: p.bg);
    if (!_init) {
      _note.text = it.note;
      _init = true;
    }
    final noun = it.isAudio ? 'AUDIO' : 'VIDEO';
    final cover = coverProvider(it, width: 900);

    return Scaffold(
      backgroundColor: p.bg,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.pop(context)),
                  RoundIcon(Icons.more_vert, label: 'More',
                      onTap: () => showItemActions(context, it.id,
                          onDeleted: () => Navigator.of(context).maybePop())),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(color: kSheetBg, borderRadius: BorderRadius.circular(28)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (_playable(it))
                        _Player(item: it, onFallback: () => _open(it))
                      else
                        Tap(
                          onTap: () => _open(it),
                          label: 'Play in the original app',
                          child: AspectRatio(
                            aspectRatio: 16 / 9,
                            child: Container(
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [Color(0xFFC9A574), Color(0xFF6E5A3C)],
                                ),
                                image: cover == null
                                    ? null
                                    : DecorationImage(image: cover, fit: BoxFit.cover, onError: (_, __) {}),
                              ),
                              child: Container(
                                width: 60,
                                height: 60,
                                decoration: const BoxDecoration(color: Color(0xE6171717), shape: BoxShape.circle),
                                child: Icon(it.isAudio ? Icons.headphones : Icons.play_arrow,
                                    size: 32, color: const Color(0xFFF4F3F0)),
                              ),
                            ),
                          ),
                        ),
                      const SizedBox(height: 20),
                      Text(
                        '$noun${it.mins > 0 ? ' · ${it.mins} MIN' : ''} · ${it.savedLabel.toUpperCase()}',
                        style: ts(12, color: alpha(kSheetInk, .6), ls: .3),
                      ),
                      const SizedBox(height: 10),
                      Text(it.title, style: ts(30, w: FontWeight.w500, ls: -1.1, h: 1.07, color: kSheetInk)),
                      const SizedBox(height: 8),
                      Text(it.src, style: ts(14, color: const Color(0xFF777671))),
                      const SizedBox(height: 18),
                      SheetField(_note, 'Add a note'),
                      const SizedBox(height: 12),
                      if (!_playable(it))
                        SheetButton(it.isAudio ? 'Listen in the original app' : 'Watch in the original app',
                            onTap: () => _open(it))
                      else
                        SheetButton(it.isFile ? 'Open in another app' : 'Open original link',
                            primary: false, onTap: () => _open(it)),
                      const SizedBox(height: 10),
                      SheetButton(it.read ? 'Mark unwatched' : 'Mark watched',
                          primary: false, onTap: () => store.toggleRead(it)),
                      const SizedBox(height: 10),
                      SheetButton('Save note', primary: false, onTap: () {
                        store.setNote(it, _note.text.trim());
                        FocusScope.of(context).unfocus();
                        toast(context, 'Note saved');
                      }),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Small in-app player: tap the picture to play or pause, drag the bar to seek.
class _Player extends StatefulWidget {
  final Item item;
  final VoidCallback onFallback;
  const _Player({required this.item, required this.onFallback});

  @override
  State<_Player> createState() => _PlayerState();
}

class _PlayerState extends State<_Player> {
  late final VideoPlayerController _c;
  bool _ready = false, _failed = false;

  @override
  void initState() {
    super.initState();
    final it = widget.item;
    _c = it.isFile
        ? VideoPlayerController.file(File(it.path!))
        : VideoPlayerController.networkUrl(Uri.parse(it.url));
    _c.addListener(_tick);
    _c.initialize().then((_) {
      if (!mounted) return;
      StoreScope.read(context).setMins(it, (_c.value.duration.inSeconds / 60).ceil());
      setState(() => _ready = true);
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _c.removeListener(_tick);
    _c.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes, s = d.inSeconds % 60;
    final h = m ~/ 60;
    final two = s.toString().padLeft(2, '0');
    return h > 0 ? '$h:${(m % 60).toString().padLeft(2, '0')}:$two' : '$m:$two';
  }

  @override
  Widget build(BuildContext context) {
    const ink = Color(0xFF171717);
    final it = widget.item;
    if (_failed) {
      return Container(
        height: 150,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: const Color(0xFFCFCEC8), borderRadius: BorderRadius.circular(20)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('This can’t play inside ClipSot', style: ts(14, color: ink)),
          const SizedBox(height: 10),
          Tap(
            onTap: widget.onFallback,
            label: 'Open in another app',
            child: Text('Open in another app', style: ts(14, w: FontWeight.w600, color: ink)),
          ),
        ]),
      );
    }
    final v = _c.value;
    final total = v.duration.inMilliseconds;
    final pos = v.position.inMilliseconds.clamp(0, total <= 0 ? 1 : total).toDouble();
    return Column(children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: AspectRatio(
          aspectRatio: it.isAudio || !_ready ? 16 / 9 : (v.aspectRatio <= 0 ? 16 / 9 : v.aspectRatio),
          child: GestureDetector(
            onTap: !_ready ? null : () => v.isPlaying ? _c.pause() : _c.play(),
            child: Container(
              color: Colors.black,
              child: Stack(alignment: Alignment.center, children: [
                if (_ready && !it.isAudio) VideoPlayer(_c),
                if (it.isAudio) const Icon(Icons.headphones, size: 56, color: Color(0x99FFFFFF)),
                if (!_ready)
                  const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                if (_ready && !v.isPlaying)
                  Container(
                    width: 60,
                    height: 60,
                    decoration: const BoxDecoration(color: Color(0xE6F4F3F0), shape: BoxShape.circle),
                    child: const Icon(Icons.play_arrow, size: 34, color: ink),
                  ),
              ]),
            ),
          ),
        ),
      ),
      Row(children: [
        Tap(
          onTap: !_ready ? null : () => v.isPlaying ? _c.pause() : _c.play(),
          label: v.isPlaying ? 'Pause' : 'Play',
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Icon(v.isPlaying ? Icons.pause : Icons.play_arrow, size: 26, color: ink),
          ),
        ),
        Text(_fmt(v.position), style: ts(12, color: const Color(0xFF555450))),
        Expanded(
          child: SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: ink,
              inactiveTrackColor: const Color(0xFFCFCEC8),
              thumbColor: ink,
              trackHeight: 3,
              overlayShape: SliderComponentShape.noOverlay,
            ),
            child: Slider(
              value: pos,
              max: total <= 0 ? 1 : total.toDouble(),
              onChanged: !_ready ? null : (x) => _c.seekTo(Duration(milliseconds: x.round())),
            ),
          ),
        ),
        Text(_fmt(v.duration), style: ts(12, color: const Color(0xFF555450))),
      ]),
    ]);
  }
}
