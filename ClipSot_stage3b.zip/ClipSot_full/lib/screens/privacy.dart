import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/common.dart';

/// Plain-language privacy page. Keep this in step with the Play Store
/// "Data safety" form and the manifest permissions.
class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);

    Widget h(String t) => Padding(
          padding: const EdgeInsets.only(top: 26, bottom: 6),
          child: Text(t.toUpperCase(), style: ts(12, color: p.tx2, ls: .6)),
        );

    Widget body(String t) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Text(t, style: ts(15, h: 1.45, color: p.tx)),
        );

    Widget perm(IconData icon, String name, String why) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 9),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, size: 20, color: p.tx2),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: ts(15, w: FontWeight.w500, color: p.tx)),
                const SizedBox(height: 2),
                Text(why, style: ts(13.5, h: 1.4, color: p.tx2)),
              ]),
            ),
          ]),
        );

    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
            child: Row(children: [
              RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.pop(context)),
            ]),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 60),
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 12),
                  child: Text('Privacy', style: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx)),
                ),
                body('ClipSot has no account and no analytics. Your library is stored on this phone only and is never uploaded. '
                    'The free version shows a few ads from Google AdMob on Home. You can remove them for good in Settings.'),
                h('Ads'),
                body('Ads come from Google AdMob. Where the law asks (for example the EU and UK) you are asked for consent first and can change it any time in Settings. '
                    'AdMob may use your device’s advertising ID and basic device data to show and measure ads. Ads never appear while you read, and your saved '
                    'links, notes and files are never shared with advertisers. Buying “Remove ads” turns them off.'),
                h('What leaves your phone'),
                body('Only a request to a website you chose: when you open a link, or when you save one while “Fetch article text” is on '
                    '(or save a manga link, so its pages can be found). The site sees the request like any browser visit. Nothing else is sent anywhere.'),
                h('Your data'),
                body('Back up and Restore create a file that you control. Deleted items wait in Trash for 30 days, then are removed for good. '
                    '“Delete all data” in Settings wipes the library, notes and Trash at once.'),
                h('Permissions, and why'),
                perm(Icons.language, 'Internet', 'To open links and fetch article text or manga pages.'),
                perm(Icons.ads_click, 'Advertising ID', 'Used by Google AdMob for the ads in the free version. Android lets you reset or delete it in system settings.'),
                perm(Icons.shopping_bag_outlined, 'Google Play billing', 'Only for the one-time Remove ads purchase.'),
                perm(Icons.vibration, 'Vibration', 'For the haptic feedback. Turn it off in Settings › Haptics.'),
                perm(Icons.notifications_none, 'Notifications (optional)', 'Only for reminders you set and optional rediscovery nudges. Asked only when you turn them on.'),
                perm(Icons.link, 'Accessibility: link grabber (optional)',
                    'Only so the Save link tile can read the address of the page on screen when you tap it. Off by default.'),
                perm(Icons.restart_alt, 'Run at startup', 'To bring your reminders back after the phone restarts.'),
                h('Manga and copyright'),
                body('ClipSot only reads pages you save yourself, on your own device, like a reading list. It does not host, copy or share anyone’s content. '
                    'Please save and read only what you have the right to read.'),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
