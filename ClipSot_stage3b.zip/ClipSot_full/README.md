# ClipSot (Flutter)

Save now. Find anytime. A private, offline-first personal library.

## v0.9 / Stage 3: ads, Remove ads, Play Store prep

- **AdMob native ads** on Home only (one between rows, up to three in the long grid), styled like a card and labelled
  "Ad". Never in readers, video, Search or Trash. Google's consent prompt (UMP) runs first; *Settings > Ad privacy choices*
  appears where the law needs it. Max ad rating PG.
- **Remove ads**: one-time Google Play purchase (`remove_ads`), plus *Restore purchase*, under *Settings > Support ClipSot*.
- **Safe by default.** Release builds show no ads until you provide your AdMob IDs (see MONETIZATION.md); debug builds
  always use Google's test ads.
- Workflow now also builds the **AAB** Play needs, and applies `ADMOB_APP_ID` / `ADMOB_NATIVE_ID` secrets.
- Privacy screen, Play checklist and a money-setup guide updated.

## v0.8 / Stage 2: a much bigger Add flow, better video, a better Home

- **Add anything.** The Add sheet (and a chip strip on Home) takes: one link or a whole pasted list, photos, camera,
  videos, audio, any file, HTML pages, comic files (CBZ/ZIP), pasted text and notes. It recognises 130+ websites by
  name and 80+ file types, picks the right kind (video, audio, manga, article, document) and shows what it found before
  you save. A link on the clipboard is offered at the top with one tap.
- **Direct file links** (mp4, mp3, jpg, pdf...) can be saved as a copy on the device (up to 250 MB).
- **HTML files** become readable articles. **Pasted text** becomes an article. **CBZ/ZIP comics** are unpacked into
  pages and read in the manga reader, offline.
- **Better video.** Real titles, channel names and thumbnails (YouTube through its public oEmbed, other sites through
  their page data), video length, and an in-app player for files on the device and direct video/audio links.
  Site videos open in their own app, because those services only allow playback there. Audio is its own kind.
- **Home.** An "All" row, then a row each for Videos, Manga, Articles, Audio, Images and Documents, with cover pictures
  (video thumbnails, first manga page, photos). *Grid view* gives the old mosaic. Featured card shows the cover.
- Pictures are only looked up from their own site; nothing is uploaded anywhere.

## v0.7 / Stage 1: fixes and foundations

- **Manga and webtoons load.** Pages are fetched with a real browser identity and the site's Referer (the main reason
  Webtoons showed "No pages found"). Lazy-loaded images, srcset and page lists hidden in script JSON are all read.
  If a plain download still finds nothing, the **in-app browser** opens, scrolls the chapter so every page loads and
  grabs them; you can sign in or accept a prompt there first, then tap *Grab pages*.
- **Trash peel animation plays everywhere.** The featured card, Continue reading and Rediscover rows were missing from
  the peel system, so a lone saved item never animated.
- **Floating side panel and edge handle removed.** Item options and Share/selected-text saving now open as a normal
  bottom sheet (drag the grip down or tap outside to close). The "Display over other apps" permission is gone.
- **Save link tile reads the page for you.** Turn on *Settings > Quick access > Link grabber*. Tap the tile in any
  browser and the address is read from the page, no copy or paste. Without it the tile falls back to the clipboard.
  Apps that show no address (most video apps) still work through Share > ClipSot.
- **Reader top bar hides while you scroll down and returns when you scroll up** (articles and manga).
- **Pill navigation bar** with a sliding highlighted tab.

## v0.5: look and feel

- **Splash:** the C draws itself, the saved dot pops into its opening, then the wordmark follows.
- **Home:** a new headline every visit (time of day and library aware; tap it for another), a featured card that rotates
  between *pick up where you left off*, *from your archive* and *fresh*, quick stat tiles, a mixed card layout whose rhythm and
  colours change each visit, and a swipeable Rediscover row.
- The logo mark now appears on Home, Settings and the Splash.

## Status: Stage 3 complete (v0.4)

Stage 3b (this build) finishes everything that was marked "Not finished":

- **Article text + titles** are fetched when you save a link (Settings › Fetch article text, on by default), so the reader works.
  Use *Refresh article text* in the link panel to retry.
- **Images and PDFs** can be saved from the Save sheet, or shared from any app (Share › ClipSot). The Images and Documents chips are populated.
  Images open in a zoomable viewer; PDFs/documents open in your phone's viewer.
- **Continue reading**: reading position is remembered and a row appears on Home.
- **Backup and restore as a file** (Settings › Back up library / Restore from backup). Backups include saved files up to 8 MB each.
- Notifications and reminders are delivered (Stage 3a). Unit tests are in `test/`.

Still plain text only: Notes. Rich formatting is not built.

Stage 3a added:

- **Quick-save sheet.** (Stage 3a built this as a right-edge panel; since v0.7 it is a bottom sheet.)
  - In any app: long-press a link, tap *Share*, choose **ClipSot**.
  - Or select link text and choose **Save to ClipSot**.
  - It lets you pick collections, add a note, set a reminder, and copy, share or open the link.
  - Long-press any saved item inside ClipSot to open the same panel with its options.
- **Quick tiles.** *Save link* (reads the copied link) and *Surprise me* (picks something unread).
  Add them from Settings › Quick access, or from the Quick Settings editor. Long-press the app icon for the same two shortcuts.
- **Edge handle.** An optional slim tab on the screen edge that opens the panel. This is what the
  *Display over other apps* permission is used for.
- **Permissions screen** (Settings › Permissions): Notifications and Display over other apps, with status.
- **Real notifications** that look like the app (dark card, accent colour, `clipsot.` wordmark,
  Read now / Tomorrow / Done actions). Used for item reminders and optional rediscovery nudges.

## Run it

```bash
cd clipsot
./setup.sh          # Windows: powershell -ExecutionPolicy Bypass -File setup.ps1
flutter run
```

`setup.sh` generates the Android project once (`flutter create`), copies `android_overlay/` into it
(manifest, Kotlin, layouts, tiles) and sets minSdk to 26. Requires Flutter 3.22 or newer.
The application id is `com.clipsot.clipsot`; do not change `--org` or `--project-name`, the
Kotlin files use that package.

## Notes

- Sample articles are seeded only in **debug** builds. Release builds start empty.
- Pages that can't be read (paywalls, scripts-only sites) show an "Open original site" fallback in the reader.
- The font is Inter Tight via `google_fonts` (downloaded on first run, then cached).
  Bundle the font files as assets if you need guaranteed first-run offline typography.

## Brand

Logo files are in `brand/` (SVG + PNG): app icon, mark, wordmark, horizontal lockup, light and dark.
The launcher icon is an adaptive icon (with Android 13 themed-icon support) in
`android_overlay/.../res/mipmap-anydpi-v26/`, applied automatically by `setup.sh`.
Colours: background `#101010`, accent `#C9A574` (light theme `#A98250`), text `#F4F3F0`. Font: Inter Tight Medium.
