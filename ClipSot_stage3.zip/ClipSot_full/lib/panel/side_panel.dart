import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../actions.dart' show trashItemAnimated;
import '../files.dart' show fileType;
import '../haptics.dart';
import '../models.dart';
import '../native.dart';
import '../remind.dart';
import '../screens/home.dart' show openItem;
import '../screens/sheets.dart' show SheetButton, SheetField;
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'link_utils.dart';

/// Handed to panel content so it can close the panel and show short messages
/// (snack bars would appear underneath the panel).
class PanelCtl {
  final Future<void> Function() close;
  final void Function(String) flash;
  const PanelCtl(this.close, this.flash);
}

/// Opens the right-docked panel on top of the current screen.
Future<void> showSidePanel(BuildContext context, Widget Function(PanelCtl) build) =>
    showGeneralDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierLabel: 'Close panel',
      barrierColor: Colors.transparent,
      transitionDuration: Duration.zero,
      pageBuilder: (ctx, _, __) => SidePanelFrame(
        onClosed: () => Navigator.of(ctx).pop(),
        builder: build,
      ),
    );

/// Item options as a side panel (long-press on any saved link, or the more button).
Future<void> showItemPanel(BuildContext context, int id, {VoidCallback? onDeleted}) =>
    showSidePanel(
      context,
      (ctl) => ItemPanel(
        id: id,
        ctl: ctl,
        onDeleted: onDeleted,
        onOpen: (it) async {
          await ctl.close();
          if (context.mounted) openItem(context, it);
        },
      ),
    );

/// Slide-in panel docked to the right edge with a dimmed scrim.
class SidePanelFrame extends StatefulWidget {
  final VoidCallback onClosed;
  final Widget Function(PanelCtl) builder;
  const SidePanelFrame({super.key, required this.onClosed, required this.builder});

  @override
  State<SidePanelFrame> createState() => _SidePanelFrameState();
}

class _SidePanelFrameState extends State<SidePanelFrame> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 280));
  String? _msg;
  Timer? _msgTimer;
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    _c.forward();
  }

  @override
  void dispose() {
    _msgTimer?.cancel();
    _c.dispose();
    super.dispose();
  }

  Future<void> _close() async {
    if (_closing) return;
    _closing = true;
    await _c.animateBack(0, duration: const Duration(milliseconds: 200), curve: Curves.easeInCubic);
    widget.onClosed();
  }

  void _flash(String m) {
    _msgTimer?.cancel();
    setState(() => _msg = m);
    _msgTimer = Timer(const Duration(milliseconds: 1700), () {
      if (mounted) setState(() => _msg = null);
    });
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final pw = (w * 0.88).clamp(280.0, 380.0);
    final curve = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _close();
      },
      child: Stack(children: [
        Positioned.fill(
          child: FadeTransition(
            opacity: _c,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _close,
              child: const ColoredBox(color: Color(0x8C000000)),
            ),
          ),
        ),
        Align(
          alignment: Alignment.centerRight,
          child: AnimatedBuilder(
            animation: curve,
            builder: (_, child) => Transform.translate(offset: Offset((1 - curve.value) * pw, 0), child: child),
            child: GestureDetector(
              onHorizontalDragUpdate: (d) => _c.value -= (d.primaryDelta ?? 0) / pw,
              onHorizontalDragEnd: (d) {
                if (d.velocity.pixelsPerSecond.dx > 700 || _c.value < 0.6) {
                  _close();
                } else {
                  _c.forward();
                }
              },
              child: Semantics(
                label: 'Link options panel',
                child: Material(
                  color: kSheetBg,
                  clipBehavior: Clip.antiAlias,
                  elevation: 12,
                  shadowColor: Colors.black,
                  borderRadius: const BorderRadius.horizontal(left: Radius.circular(28)),
                  child: SizedBox(
                    width: pw,
                    height: double.infinity,
                    child: SafeArea(
                      left: false,
                      child: Stack(children: [
                        Positioned.fill(child: widget.builder(PanelCtl(_close, _flash))),
                        Positioned(
                          left: 20,
                          right: 20,
                          bottom: 18,
                          child: IgnorePointer(
                            child: AnimatedOpacity(
                              opacity: _msg == null ? 0 : 1,
                              duration: const Duration(milliseconds: 180),
                              child: Container(
                                height: 44,
                                alignment: Alignment.center,
                                decoration: const BoxDecoration(color: kSheetInk, borderRadius: BorderRadius.all(Radius.circular(22))),
                                child: Text(_msg ?? '', style: ts(14, color: const Color(0xFFF4F3F0))),
                              ),
                            ),
                          ),
                        ),
                      ]),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}

// ---------------------------------------------------------------------------
// shared building blocks

const _muted = Color(0xFF777671);

class _Top extends StatelessWidget {
  final String title;
  final PanelCtl ctl;
  final VoidCallback? beforeClose;
  const _Top(this.title, this.ctl, {this.beforeClose});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 14),
        child: Row(children: [
          Container(
            width: 8,
            height: 8,
            margin: const EdgeInsets.only(right: 10),
            decoration: BoxDecoration(color: P.of(context).ac, shape: BoxShape.circle),
          ),
          Expanded(child: Text(title, style: ts(13, w: FontWeight.w500, ls: .6, color: _muted))),
          Tap(
            label: 'Close panel',
            onTap: () {
              beforeClose?.call();
              ctl.close();
            },
            child: const SizedBox(width: 40, height: 40, child: Icon(Icons.close, size: 22, color: kSheetInk)),
          ),
        ]),
      );
}

class _Label extends StatelessWidget {
  final String t;
  const _Label(this.t);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(t.toUpperCase(), style: ts(11.5, ls: .8, color: _muted)),
      );
}

class _QA extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _QA(this.icon, this.label, this.onTap);

  @override
  Widget build(BuildContext context) => Expanded(
        child: Tap(
          label: label,
          onTap: onTap,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(color: kSheetChip, borderRadius: BorderRadius.circular(18)),
              child: Icon(icon, size: 24, color: kSheetInk),
            ),
            const SizedBox(height: 6),
            Text(label, style: ts(12, color: kSheetInk), maxLines: 1, overflow: TextOverflow.ellipsis),
          ]),
        ),
      );
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color color;
  const _Row(this.icon, this.label, this.onTap, {this.color = kSheetInk});

  @override
  Widget build(BuildContext context) => Tap(
        label: label,
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(children: [
            Icon(icon, size: 22, color: color),
            const SizedBox(width: 14),
            Expanded(child: Text(label, style: ts(15.5, color: color))),
          ]),
        ),
      );
}

class _LinkHeader extends StatelessWidget {
  final String title, src, url;
  const _LinkHeader({required this.title, required this.src, required this.url});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final ch = (src.isEmpty ? '?' : src[0]).toUpperCase();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(
          width: 46,
          height: 46,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: p.ac, borderRadius: BorderRadius.circular(15)),
          child: Text(ch, style: ts(19, w: FontWeight.w600, color: const Color(0xFF171717))),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(17, w: FontWeight.w500, h: 1.2, color: kSheetInk)),
            const SizedBox(height: 2),
            Text(src, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, color: _muted)),
          ]),
        ),
      ]),
      const SizedBox(height: 10),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
        child: Text(url, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, color: _muted)),
      ),
    ]);
  }
}

Widget _remindChips(Item? it, DateTime? picked, void Function(DateTime?) onPick) {
  final cur = it != null && it.hasReminder ? it.remind : picked;
  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Wrap(spacing: 8, runSpacing: 8, children: [
      for (final o in remindOptions())
        Pill(o.label, sheet: true, on: cur != null && cur == o.at, onTap: () => onPick(o.at)),
      if (cur != null) Pill('No reminder', sheet: true, on: false, onTap: () => onPick(null)),
    ]),
    if (cur != null)
      Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Text('Reminder: ${remindLabel(cur)}', style: ts(12.5, color: _muted)),
      ),
  ]);
}

/// Makes sure notifications can be shown before a reminder is created.
Future<void> _ensureNotif(Store s, PanelCtl ctl) async {
  if (await Native.notifGranted()) return;
  if (s.notifAsked) {
    ctl.flash('Turn on notifications in Settings › Permissions');
    return;
  }
  s.setNotifAsked();
  await Native.requestNotif();
}

// ---------------------------------------------------------------------------
// Options for a saved item

class ItemPanel extends StatefulWidget {
  final int id;
  final PanelCtl ctl;
  final Future<void> Function(Item) onOpen;
  final VoidCallback? onDeleted;
  final VoidCallback? onShuffle;
  final String? banner;
  const ItemPanel({
    super.key,
    required this.id,
    required this.ctl,
    required this.onOpen,
    this.onDeleted,
    this.onShuffle,
    this.banner,
  });

  @override
  State<ItemPanel> createState() => _ItemPanelState();
}

class _ItemPanelState extends State<ItemPanel> {
  final _note = TextEditingController();
  bool _noteInit = false;

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  void _saveNote(Store s, Item it) {
    if (_note.text.trim() != it.note.trim()) s.setNote(it, _note.text.trim());
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final it = s.byId(widget.id);
    final ctl = widget.ctl;
    if (it == null) {
      return Column(children: [_Top('LINK OPTIONS', ctl), const Spacer(), Text('This item is gone.', style: ts(15, color: _muted)), const Spacer()]);
    }
    if (!_noteInit) {
      _note.text = it.note;
      _noteInit = true;
    }
    final vid = it.isVideo;

    return ListView(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 90 + MediaQuery.of(context).viewInsets.bottom),
      children: [
        _Top(widget.onShuffle != null ? 'SURPRISE ME' : 'LINK OPTIONS', ctl, beforeClose: () => _saveNote(s, it)),
        if (widget.banner != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(children: [
              const Icon(Icons.check_circle, size: 18, color: kSheetInk),
              const SizedBox(width: 8),
              Text(widget.banner!, style: ts(13.5, color: kSheetInk)),
            ]),
          ),
        _LinkHeader(title: it.title, src: it.src, url: it.isFile ? 'Saved on this device' : it.url),
        const SizedBox(height: 18),
        Row(children: [
          _QA(vid ? Icons.play_arrow : (it.isFile ? Icons.folder_open : Icons.chrome_reader_mode_outlined),
              vid ? 'Watch' : (it.isFile ? 'Open' : 'Read'), () {
            _saveNote(s, it);
            widget.onOpen(it);
          }),
          if (it.isFile)
            _QA(Icons.ios_share, 'Share', () => Share.shareXFiles([XFile(it.path!)]))
          else ...[
            _QA(Icons.open_in_new, 'Browser', () => openExternal(context, it.url)),
            _QA(Icons.ios_share, 'Share', () => Share.share(it.url)),
            _QA(Icons.link, 'Copy', () {
              Clipboard.setData(ClipboardData(text: it.url));
              ctl.flash('Link copied');
            }),
          ],
        ]),
        if (widget.onShuffle != null) ...[
          const SizedBox(height: 14),
          SheetButton('Another one', primary: false, onTap: widget.onShuffle!),
        ],
        const _Label('Remind me'),
        _remindChips(it, null, (d) async {
          if (d != null) await _ensureNotif(s, ctl);
          s.setRemind(it, d);
          ctl.flash(d == null ? 'Reminder removed' : 'Reminder set');
        }),
        const _Label('Collections'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final c in s.cols) Pill(c, sheet: true, on: it.cols.contains(c), onTap: () => s.toggleCol(it, c)),
        ]),
        const _Label('Note'),
        Focus(
          onFocusChange: (f) {
            if (!f) _saveNote(s, it);
          },
          child: SheetField(_note, 'Add a note', maxLines: 4),
        ),
        const _Label('More'),
        _Row(Icons.check_circle_outline, vid ? (it.read ? 'Mark unwatched' : 'Mark watched') : (it.read ? 'Mark unread' : 'Mark read'),
            () => s.toggleRead(it)),
        if (!it.isFile && !vid)
          _Row(Icons.refresh, 'Refresh article text', () async {
            ctl.flash('Fetching…');
            final ok = await s.enrich(it.id, force: true);
            ctl.flash(ok ? 'Updated' : 'Couldn’t read that page');
          }),
        _Row(Icons.delete_outline, 'Move to Trash', () async {
          // No "are you sure?": it goes to the Trash and Undo is one tap away.
          final m = ScaffoldMessenger.of(context);
          final pal = P.of(context);
          final onDeleted = widget.onDeleted;
          final id = it.id;
          await ctl.close();
          if (onDeleted != null) {
            // Leave the reader first so the row on the list can peel away.
            onDeleted();
            await Future<void>.delayed(const Duration(milliseconds: 340));
          }
          await trashItemAnimated(s, m, pal, id);
        }, color: kDanger),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Save a link that arrived from another app (share, selected text, clipboard)

class SavePanel extends StatefulWidget {
  final String? text;
  final String? subject;
  final PanelCtl ctl;
  final bool fromOutside;
  const SavePanel({super.key, this.text, this.subject, required this.ctl, this.fromOutside = false});

  @override
  State<SavePanel> createState() => _SavePanelState();
}

class _SavePanelState extends State<SavePanel> {
  late final TextEditingController _u = TextEditingController(text: extractLink(widget.text) ?? '');
  final _n = TextEditingController();
  Set<String> _sel = {};
  bool _init = false;
  DateTime? _remind;
  Item? _saved;
  bool _showExisting = false;
  bool? _manga; // null = guess from the link
  Timer? _auto;

  @override
  void initState() {
    super.initState();
    _u.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _auto?.cancel();
    _u.dispose();
    _n.dispose();
    super.dispose();
  }

  Item? get _preview => Item.fromUrl(_u.text, '', [], manga: _manga);

  Item? _existing(Store s) {
    final p = _preview;
    if (p == null) return null;
    for (final i in s.items) {
      if (i.url == p.url) return i;
    }
    return null;
  }

  Future<void> _save(Store s) async {
    final it = Item.fromUrl(_u.text, _n.text, s.cols.where(_sel.contains).toList(), manga: _manga);
    if (it == null) return;
    final sub = widget.subject?.trim();
    if (sub != null && sub.isNotEmpty && sub.length < 160 && sub != it.url) it.title = sub;
    if (!s.addItem(it)) {
      widget.ctl.flash('Already saved');
      return;
    }
    if (_remind != null) {
      await _ensureNotif(s, widget.ctl);
      s.setRemind(it, _remind);
    }
    Haptics.success();
    setState(() => _saved = it);
    if (widget.fromOutside) {
      _auto = Timer(const Duration(milliseconds: 4500), () {
        if (mounted) widget.ctl.close();
      });
    }
  }

  Future<void> _open(Item it) async {
    if (widget.fromOutside) {
      await Native.openMain(itemId: it.id);
    } else {
      await widget.ctl.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final ctl = widget.ctl;
    if (!_init) {
      _sel = {if (s.cols.contains(s.defaultCol)) s.defaultCol};
      _init = true;
    }

    final saved = _saved;
    if (saved != null) {
      return Listener(
        onPointerDown: (_) => _auto?.cancel(),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 90),
          children: [
            _Top('SAVED', ctl),
            const SizedBox(height: 8),
            Center(
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: .6, end: 1),
                duration: const Duration(milliseconds: 380),
                curve: Curves.easeOutBack,
                builder: (_, v, c) => Transform.scale(scale: v, child: c),
                child: Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(color: P.of(context).ac, shape: BoxShape.circle),
                  child: const Icon(Icons.check, size: 34, color: Color(0xFF171717)),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Center(child: Text('Saved to ClipSot', style: ts(19, w: FontWeight.w500, color: kSheetInk))),
            const SizedBox(height: 4),
            Center(
              child: Text(saved.cols.isEmpty ? 'No collection' : saved.cols.join(' · '),
                  textAlign: TextAlign.center, style: ts(13.5, color: _muted)),
            ),
            const SizedBox(height: 20),
            _LinkHeader(title: saved.title, src: saved.src, url: saved.url),
            const SizedBox(height: 18),
            Row(children: [
              _QA(Icons.chrome_reader_mode_outlined, 'Open', () => _open(saved)),
              _QA(Icons.ios_share, 'Share', () => Share.share(saved.url)),
              _QA(Icons.undo, 'Undo', () {
                s.removeItem(saved.id);
                ctl.close();
              }),
            ]),
          ],
        ),
      );
    }

    final dup = _existing(s);
    if (_showExisting && dup != null) {
      return ItemPanel(
        id: dup.id,
        ctl: ctl,
        banner: 'Already in your library',
        onOpen: (it) => _open(it),
      );
    }

    final prev = _preview;
    final hasText = _u.text.trim().isNotEmpty;
    return ListView(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 90 + MediaQuery.of(context).viewInsets.bottom),
      children: [
        _Top('SAVE TO CLIPSOT', ctl),
        SheetField(_u, 'Paste a link', type: TextInputType.url),
        if (!hasText)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Tap(
              label: 'Paste from clipboard',
              onTap: () async {
                final d = await Clipboard.getData('text/plain');
                final l = extractLink(d?.text);
                if (l == null) {
                  ctl.flash('No link on the clipboard');
                } else {
                  _u.text = l;
                  Haptics.select();
                }
              },
              child: Row(children: [
                const Icon(Icons.content_paste, size: 18, color: kSheetInk),
                const SizedBox(width: 8),
                Text('Paste from clipboard', style: ts(14, color: kSheetInk)),
              ]),
            ),
          ),
        if (hasText && prev == null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text('That doesn’t look like a valid link.', style: ts(13, color: kDanger)),
          ),
        if (prev != null) ...[
          const SizedBox(height: 14),
          _LinkHeader(title: widget.subject?.trim().isNotEmpty == true ? widget.subject!.trim() : prev.title, src: prev.src, url: prev.url),
        ],
        if (dup != null) ...[
          const SizedBox(height: 14),
          Tap(
            label: 'Already saved',
            onTap: () => setState(() => _showExisting = true),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: kSheetChip, borderRadius: BorderRadius.circular(14)),
              child: Row(children: [
                const Icon(Icons.bookmark_added_outlined, size: 20, color: kSheetInk),
                const SizedBox(width: 10),
                Expanded(child: Text('Already in your library. Tap for options.', style: ts(13.5, color: kSheetInk))),
              ]),
            ),
          ),
        ],
        if (prev != null && (prev.type == 'article' || prev.type == 'manga')) ...[
          const SizedBox(height: 14),
          ReadAsSwitch(
            manga: prev.isManga,
            onChanged: (v) => setState(() => _manga = v),
          ),
        ],
        if (dup == null) ...[
          const _Label('Collections'),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final c in s.cols)
              Pill(c, sheet: true, on: _sel.contains(c), onTap: () => setState(() => _sel.contains(c) ? _sel.remove(c) : _sel.add(c))),
          ]),
          if (s.askNote) ...[
            const _Label('Note'),
            SheetField(_n, 'Add a note (optional)'),
          ],
          const _Label('Remind me'),
          _remindChips(null, _remind, (d) => setState(() => _remind = d)),
          const SizedBox(height: 22),
          Opacity(opacity: prev == null ? .45 : 1, child: SheetButton('Save', onTap: () => prev == null ? null : _save(s))),
        ],
      ],
    );
  }
}

/// Save an image or PDF that was shared to ClipSot from another app.
class FilePanel extends StatefulWidget {
  final String path;
  final String name;
  final PanelCtl ctl;
  const FilePanel({super.key, required this.path, required this.name, required this.ctl});

  @override
  State<FilePanel> createState() => _FilePanelState();
}

class _FilePanelState extends State<FilePanel> {
  Set<String> _sel = {};
  bool _init = false;
  bool _busy = false;

  Future<void> _save(Store s) async {
    setState(() => _busy = true);
    final it = await s.addFile(widget.path, name: widget.name, cols: s.cols.where(_sel.contains).toList());
    if (it == null) {
      if (mounted) setState(() => _busy = false);
      widget.ctl.flash('Couldn’t save that file');
      return;
    }
    Haptics.success();
    widget.ctl.flash('Saved to ClipSot');
    await Future<void>.delayed(const Duration(milliseconds: 900));
    widget.ctl.close();
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    if (!_init) {
      _sel = {if (s.cols.contains(s.defaultCol)) s.defaultCol};
      _init = true;
    }
    final isImg = fileType(widget.name) == 'image';
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 90),
      children: [
        _Top('SAVE TO CLIPSOT', widget.ctl),
        _LinkHeader(title: widget.name, src: isImg ? 'Image' : 'Document', url: 'From another app'),
        const _Label('Collections'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final c in s.cols)
            Pill(c, sheet: true, on: _sel.contains(c), onTap: () => setState(() => _sel.contains(c) ? _sel.remove(c) : _sel.add(c))),
        ]),
        const SizedBox(height: 22),
        Opacity(opacity: _busy ? .5 : 1, child: SheetButton('Save', onTap: () => _busy ? null : _save(s))),
      ],
    );
  }
}

/// Shown when there is nothing to display (empty library for Surprise me).
class EmptyPanel extends StatelessWidget {
  final String title, body;
  final PanelCtl ctl;
  const EmptyPanel({super.key, required this.title, required this.body, required this.ctl});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        children: [
          _Top('CLIPSOT', ctl),
          const SizedBox(height: 40),
          Text(title, style: ts(20, w: FontWeight.w500, color: kSheetInk)),
          const SizedBox(height: 6),
          Text(body, style: ts(14.5, h: 1.4, color: _muted)),
        ],
      );
}

/// "Read as: Article | Manga" switch used when saving a link.
class ReadAsSwitch extends StatelessWidget {
  final bool manga;
  final ValueChanged<bool> onChanged;
  const ReadAsSwitch({super.key, required this.manga, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    Widget seg(String label, IconData icon, bool value) {
      final on = manga == value;
      return Expanded(
        child: Tap(
          label: 'Read as $label',
          onTap: () {
            if (!on) onChanged(value);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOutCubic,
            height: 42,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: on ? kSheetInk : Colors.transparent,
              borderRadius: BorderRadius.circular(21),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, size: 18, color: on ? kSheetBg : kSheetInk),
              const SizedBox(width: 6),
              Text(label, style: ts(14, w: FontWeight.w500, color: on ? kSheetBg : kSheetInk)),
            ]),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(color: kSheetChip, borderRadius: BorderRadius.circular(24)),
      child: Row(children: [
        seg('Article', Icons.article_outlined, false),
        seg('Manga', Icons.auto_stories_outlined, true),
      ]),
    );
  }
}
