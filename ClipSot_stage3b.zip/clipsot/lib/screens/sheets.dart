import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../panel/side_panel.dart' show showItemPanel;

import '../files.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';

Future<void> _sheet(BuildContext context, WidgetBuilder b) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: kSheetBg,
      barrierColor: const Color(0x8C000000),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: b,
    );

Future<void> showAddSheet(BuildContext context, {String? initial}) =>
    _sheet(context, (_) => AddSheet(initial: initial));

Future<void> showItemActions(BuildContext context, int id, {VoidCallback? onDeleted}) =>
    showItemPanel(context, id, onDeleted: onDeleted);

class _Grip extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(
        child: Container(
          width: 40,
          height: 4,
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: const Color(0xFFAAAAAA),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      );
}

class SheetField extends StatelessWidget {
  final TextEditingController c;
  final String hint;
  final bool autofocus;
  final TextInputType? type;
  final int maxLines;
  const SheetField(this.c, this.hint, {super.key, this.autofocus = false, this.type, this.maxLines = 1});

  @override
  Widget build(BuildContext context) => TextField(
        controller: c,
        autofocus: autofocus,
        keyboardType: maxLines > 1 ? TextInputType.multiline : type,
        minLines: 1,
        maxLines: maxLines,
        style: ts(15, color: kSheetInk),
        cursorColor: kSheetInk,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: ts(15, color: const Color(0xFF8A8984)),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.all(14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      );
}

class SheetButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool primary;
  const SheetButton(this.label, {super.key, required this.onTap, this.primary = true});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Tap(
      onTap: onTap,
      label: label,
      child: Container(
        height: 50,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: primary ? p.ac : const Color(0xFFCFCEC8),
          borderRadius: BorderRadius.circular(26),
        ),
        child: Text(label, style: ts(16, w: FontWeight.w500, color: kSheetInk)),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class AddSheet extends StatefulWidget {
  final String? initial;
  const AddSheet({super.key, this.initial});

  @override
  State<AddSheet> createState() => _AddSheetState();
}

class _AddSheetState extends State<AddSheet> {
  late final TextEditingController _u = TextEditingController(text: widget.initial ?? '');
  final _n = TextEditingController();
  Set<String> _sel = {};
  bool _init = false;
  String _err = '';

  @override
  void dispose() {
    _u.dispose();
    _n.dispose();
    super.dispose();
  }

  void _save() {
    final store = StoreScope.of(context);
    final cols = store.cols.where(_sel.contains).toList();
    final it = Item.fromUrl(_u.text, _n.text, cols);
    if (it == null) {
      setState(() => _err = 'That doesn’t look like a valid link.');
      return;
    }
    final ok = store.addItem(it);
    final m = ScaffoldMessenger.of(context);
    final p = P.of(context);
    Navigator.pop(context);
    toastWith(m, p, ok ? 'Saved' : 'Already saved');
  }

  Future<void> _pickFiles() async {
    final store = StoreScope.read(context);
    final m = ScaffoldMessenger.of(context);
    final p = P.of(context);
    final cols = store.cols.where(_sel.contains).toList();
    final r = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: [...kImageExt, ...kDocExt],
    );
    if (r == null) return;
    var n = 0;
    for (final f in r.files) {
      if (f.path == null) continue;
      if (await store.addFile(f.path!, name: f.name, cols: cols) != null) n++;
    }
    if (!mounted) return;
    Navigator.pop(context);
    toastWith(m, p, n == 0 ? 'Couldn’t save that file' : (n == 1 ? 'File saved' : '$n files saved'));
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    if (!_init) {
      _sel = {if (store.cols.contains(store.defaultCol)) store.defaultCol};
      _init = true;
    }
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Grip(),
            Text('Save to ClipSot', style: ts(18, w: FontWeight.w500, color: kSheetInk)),
            const SizedBox(height: 12),
            SheetField(_u, 'Paste a link', autofocus: true, type: TextInputType.url),
            SizedBox(
              height: 26,
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(_err, style: ts(13, color: kDanger)),
              ),
            ),
            if (store.askNote) SheetField(_n, 'Add a note (optional)'),
            const SizedBox(height: 12),
            Tap(
              onTap: _pickFiles,
              label: 'Choose an image or PDF',
              child: Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(children: [
                  const Icon(Icons.attach_file, size: 20, color: kSheetInk),
                  const SizedBox(width: 8),
                  Text('Or save an image or PDF from this device', style: ts(14, color: kSheetInk)),
                ]),
              ),
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in store.cols)
                  Pill(c, sheet: true, on: _sel.contains(c), onTap: () {
                    setState(() => _sel.contains(c) ? _sel.remove(c) : _sel.add(c));
                  }),
              ],
            ),
            const SizedBox(height: 14),
            SheetButton('Save', onTap: _save),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

/// Simple single-choice picker sheet.
Future<void> showChoice(
  BuildContext context, {
  required String title,
  required List<String> options,
  required String current,
  required ValueChanged<String> onPick,
}) =>
    _sheet(
      context,
      (_) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Grip(),
              Text(title, style: ts(18, w: FontWeight.w500, color: kSheetInk)),
              const SizedBox(height: 8),
              for (final o in options)
                Tap(
                  onTap: () {
                    onPick(o);
                    Navigator.pop(context);
                  },
                  label: o,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
                    child: Row(children: [
                      Expanded(child: Text(o, style: ts(16, color: kSheetInk))),
                      if (o == current) const Icon(Icons.check, size: 20, color: kSheetInk),
                    ]),
                  ),
                ),
            ],
          ),
        ),
      ),
    );

Future<void> showImportSheet(BuildContext context) => _sheet(context, (_) => const _ImportSheet());

class _ImportSheet extends StatefulWidget {
  const _ImportSheet();

  @override
  State<_ImportSheet> createState() => _ImportSheetState();
}

class _ImportSheetState extends State<_ImportSheet> {
  final _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Grip(),
            Text('Import links', style: ts(18, w: FontWeight.w500, color: kSheetInk)),
            const SizedBox(height: 4),
            Text('Paste links separated by spaces or new lines.',
                style: ts(13, color: const Color(0xFF777671))),
            const SizedBox(height: 12),
            TextField(
              controller: _c,
              minLines: 3,
              maxLines: 6,
              autofocus: true,
              style: ts(15, color: kSheetInk),
              cursorColor: kSheetInk,
              decoration: InputDecoration(
                hintText: 'https://\u2026',
                hintStyle: ts(15, color: const Color(0xFF8A8984)),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 14),
            SheetButton('Import', onTap: () {
              final n = store.importLinks(_c.text);
              final m = ScaffoldMessenger.of(context);
              final p = P.of(context);
              Navigator.pop(context);
              toastWith(m, p, n == 0 ? 'No new links found' : '$n imported');
            }),
          ],
        ),
      ),
    );
  }
}
