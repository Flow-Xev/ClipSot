/// Preset reminder times used by the link panel.
class RemindOpt {
  final String label;
  final DateTime at;
  const RemindOpt(this.label, this.at);
}

List<RemindOpt> remindOptions([DateTime? now]) {
  final n = now ?? DateTime.now();
  DateTime at(DateTime d, int h) => DateTime(d.year, d.month, d.day, h);
  final out = <RemindOpt>[];
  if (n.hour < 17) out.add(RemindOpt('This evening', at(n, 18)));
  final tomorrow = n.add(const Duration(days: 1));
  out.add(RemindOpt('Tomorrow', at(tomorrow, 9)));
  final toSat = (DateTime.saturday - n.weekday) % 7;
  if (toSat >= 2) out.add(RemindOpt('This weekend', at(n.add(Duration(days: toSat)), 10)));
  final toMon = (DateTime.monday - n.weekday) % 7;
  out.add(RemindOpt('Next week', at(n.add(Duration(days: toMon == 0 ? 7 : toMon)), 9)));
  return out;
}

const _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

String remindLabel(DateTime d, [DateTime? now]) {
  final n = now ?? DateTime.now();
  final t = '${d.hour}:${d.minute.toString().padLeft(2, '0')}';
  final dd = DateTime(d.year, d.month, d.day);
  final today = DateTime(n.year, n.month, n.day);
  final diff = dd.difference(today).inDays;
  if (diff == 0) return 'Today, $t';
  if (diff == 1) return 'Tomorrow, $t';
  return '${_days[d.weekday - 1]} ${d.day}/${d.month}, $t';
}
