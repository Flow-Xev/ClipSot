import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'models.dart';

const kImageExt = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'heic'];
const kDocExt = ['pdf', 'txt', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'csv', 'epub'];

String _ext(String name) {
  final i = name.lastIndexOf('.');
  return i < 0 ? '' : name.substring(i + 1).toLowerCase();
}

String _base(String path) => path.split(RegExp(r'[\\/]')).last;

String _safe(String n) => n.replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');

/// Where saved images and documents live (private to the app).
Future<Directory> libDir() async {
  final d = Directory('${(await getApplicationDocumentsDirectory()).path}/library');
  if (!await d.exists()) await d.create(recursive: true);
  return d;
}

/// 'image' | 'document' by extension.
String fileType(String name) => kImageExt.contains(_ext(name)) ? 'image' : 'document';

/// Copies [srcPath] into the library and builds an [Item] for it.
Future<Item?> importFile(String srcPath, {String? name, List<String> cols = const []}) async {
  try {
    final src = File(srcPath);
    if (!await src.exists()) return null;
    final fname = name ?? _base(srcPath);
    final id = DateTime.now().microsecondsSinceEpoch;
    final dest = '${(await libDir()).path}/${id}_${_safe(fname)}';
    await src.copy(dest);
    final dot = fname.lastIndexOf('.');
    final title = dot > 0 ? fname.substring(0, dot) : fname;
    final type = fileType(fname);
    return Item(
      id: id,
      title: title,
      src: type == 'image' ? 'Image on this device' : '${_ext(fname).toUpperCase()} on this device',
      url: 'file:///$id/${_safe(fname)}',
      type: type,
      saved: DateTime.now(),
      cols: List<String>.from(cols),
      path: dest,
    );
  } catch (_) {
    return null;
  }
}

Future<void> deleteLocalFile(String path) async {
  try {
    final f = File(path);
    if (await f.exists()) await f.delete();
  } catch (_) {}
}

Future<String?> readFileBase64(String path, {required int maxBytes}) async {
  try {
    final f = File(path);
    if (!await f.exists() || await f.length() > maxBytes) return null;
    return base64Encode(await f.readAsBytes());
  } catch (_) {
    return null;
  }
}

Future<String?> writeFileFromBase64(String data, String name) async {
  try {
    final dest = '${(await libDir()).path}/${DateTime.now().microsecondsSinceEpoch}_${_safe(name)}';
    await File(dest).writeAsBytes(base64Decode(data));
    return dest;
  } catch (_) {
    return null;
  }
}
