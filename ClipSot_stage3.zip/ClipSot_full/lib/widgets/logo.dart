import 'dart:math' as math;

import 'package:flutter/widgets.dart';

/// The ClipSot mark: an open "C" ring with a small "saved" dot in its opening.
///
/// [ring] (0..1) draws the C from the top of the opening round to the bottom.
/// [dot] (0..1.4) scales the dot in; values above 1 overshoot for a springy pop.
/// With the defaults the mark is fully drawn.
class ClipSotMark extends StatelessWidget {
  final double size;
  final Color ringColor;
  final Color dotColor;
  final double ring;
  final double dot;

  const ClipSotMark({
    super.key,
    required this.size,
    required this.ringColor,
    required this.dotColor,
    this.ring = 1,
    this.dot = 1,
  });

  @override
  Widget build(BuildContext context) {
    return ExcludeSemantics(
      child: SizedBox(
        width: size,
        height: size,
        child: CustomPaint(painter: _MarkPainter(ringColor, dotColor, ring, dot)),
      ),
    );
  }
}

class _MarkPainter extends CustomPainter {
  final Color ringColor, dotColor;
  final double ring, dot;
  _MarkPainter(this.ringColor, this.dotColor, this.ring, this.dot);

  // Proportions of the 1024 master: ring r 250, stroke 96, dot r 46 at +192.
  // The whole mark spans about 596 units (ring radius + half stroke, both sides).
  static const double _span = 596;
  static const double _gap = 40; // half-opening, degrees

  @override
  void paint(Canvas canvas, Size size) {
    final k = size.width / _span;
    final c = Offset(size.width / 2, size.height / 2);
    final r = 250 * k;

    final t = ring.clamp(0.0, 1.0).toDouble();
    if (t > 0) {
      final start = -_gap * math.pi / 180;
      final full = (360 - 2 * _gap) * math.pi / 180;
      final paint = Paint()
        ..color = ringColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 96 * k
        ..strokeCap = StrokeCap.round;
      // Sweep counter-clockwise (negative) from the upper tip of the opening.
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), start, -full * t, false, paint);
    }

    final d = dot.clamp(0.0, 1.4).toDouble();
    if (d > 0) {
      canvas.drawCircle(
        Offset(c.dx + 192 * k, c.dy),
        46 * k * d,
        Paint()..color = dotColor,
      );
    }
  }

  @override
  bool shouldRepaint(_MarkPainter o) =>
      o.ringColor != ringColor || o.dotColor != dotColor || o.ring != ring || o.dot != dot;
}
