import 'package:flutter/material.dart';

import '../theme.dart';

/// Solid background, letter-by-letter wordmark, accent dot pop, accent shape rising.
class Splash extends StatefulWidget {
  final VoidCallback onDone;
  const Splash({super.key, required this.onDone});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  static const _word = 'clipsot';
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2400));
  late final List<Animation<double>> _letters;
  late final Animation<double> _dot, _tag, _blob;

  @override
  void initState() {
    super.initState();
    _letters = [
      for (var i = 0; i < _word.length; i++)
        CurvedAnimation(
          parent: _c,
          curve: Interval(0.12 + i * 0.035, 0.12 + i * 0.035 + 0.28, curve: Curves.easeOutCubic),
        ),
    ];
    _dot = CurvedAnimation(parent: _c, curve: const Interval(0.45, 0.62, curve: Curves.easeOutBack));
    _tag = CurvedAnimation(parent: _c, curve: const Interval(0.5, 0.75, curve: Curves.easeOut));
    _blob = CurvedAnimation(parent: _c, curve: const Interval(0.15, 0.7, curve: Curves.easeOutCubic));
    _c.forward().whenComplete(() {
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final size = MediaQuery.of(context).size;
    final reduce = MediaQuery.of(context).disableAnimations;
    final style = ts(64, w: FontWeight.w500, ls: -2.5, color: p.tx);

    return Scaffold(
      backgroundColor: p.bg,
      body: Stack(
        children: [
          Align(
            alignment: Alignment.bottomLeft,
            child: AnimatedBuilder(
              animation: _blob,
              builder: (_, __) => Transform.translate(
                offset: Offset(0, reduce ? 0 : size.height * 0.42 * (1 - _blob.value)),
                child: Container(
                  width: size.width,
                  height: size.height * 0.42,
                  decoration: BoxDecoration(
                    color: p.ac,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.elliptical(size.width * 0.9, size.height * 0.34),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Semantics(
                  label: 'clipsot',
                  child: ExcludeSemantics(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        for (var i = 0; i < _word.length; i++)
                          AnimatedBuilder(
                            animation: _letters[i],
                            builder: (_, __) {
                              final t = reduce ? 1.0 : _letters[i].value;
                              return Opacity(
                                opacity: t,
                                child: Transform.translate(
                                  offset: Offset(0, 24 * (1 - t)),
                                  child: Text(_word[i], style: style),
                                ),
                              );
                            },
                          ),
                        AnimatedBuilder(
                          animation: _dot,
                          builder: (_, __) {
                            final double t = reduce ? 1.0 : _dot.value.clamp(0.0, 1.4).toDouble();
                            return Opacity(
                              opacity: t.clamp(0.0, 1.0).toDouble(),
                              child: Transform.scale(
                                scale: t,
                                child: Text('.', style: style.copyWith(color: p.ac)),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                FadeTransition(
                  opacity: reduce ? const AlwaysStoppedAnimation(1.0) : _tag,
                  child: Text('Save now. Find anytime.', style: ts(16, color: p.tx2)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
