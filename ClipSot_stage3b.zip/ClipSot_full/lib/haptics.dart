import 'dart:async';

import 'package:flutter/services.dart';

import 'native.dart';

/// How strong the app's haptics feel. Chosen in Settings > Haptics.
enum HapticLevel { off, soft, medium, strong }

HapticLevel hapticLevelFrom(String? s) => HapticLevel.values.firstWhere(
      (l) => l.name == (s ?? '').toLowerCase(),
      orElse: () => HapticLevel.medium,
    );

/// One place for every vibration in ClipSot.
///
/// On Android 11+ this plays real "primitives" (tick, click, thud) through the
/// phone's haptic motor, which feel crisp instead of buzzy. On older phones it
/// plays short amplitude-shaped pulses, and anywhere else it falls back to
/// Flutter's built-in [HapticFeedback]. It never throws.
///
/// The system "Touch feedback / Vibration" setting is respected on Android.
class Haptics {
  Haptics._();

  static HapticLevel level = HapticLevel.medium;
  static bool? _nativeOk;
  static int _lastScroll = 0;
  static final List<Timer> _timers = [];

  static bool get enabled => level != HapticLevel.off;

  static double get _gain => switch (level) {
        HapticLevel.off => 0,
        HapticLevel.soft => .6,
        HapticLevel.medium => 1,
        HapticLevel.strong => 1.35,
      };

  // ---- the vocabulary ------------------------------------------------------

  /// Any button press. Barely there.
  static void tap() => _fire('tick', .45);

  /// Choosing a chip, tab or option.
  static void select() => _fire('click', .5);

  /// Switch flipped. On feels firmer than off.
  static void toggle(bool on) => on ? _fire('click', .8) : _fire('lowtick', .6);

  /// Long press recognised.
  static void longPress() => _fire('heavy', .75);

  /// A page of a manga / a step of a pager.
  static void pageTurn() => _fire('click', .55);

  /// Reached the top or bottom of a scroll.
  static void edge() => _fire('thud', .35);

  /// Something finished well (saved, restored).
  static void success() => _fire('success', .85);

  /// Careful: a destructive action is about to happen.
  static void warning() => _fire('warning', .7);

  /// A weighty landing (paper hits the bin).
  static void thud() => _fire('thud', 1);

  /// Lid of the bin closing.
  static void lid() => _fire('click', .7);

  /// One detent of a scroll. [pxPerMs] is how fast the content is moving, so a
  /// slow drag feels soft and a hard flick feels sharp.
  static void scrollTick(double pxPerMs) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastScroll < 24) return;
    _lastScroll = now;
    _fire('tick', (.3 + pxPerMs * .11).clamp(.3, .85));
  }

  /// Rising run of ticks, like paper slowly tearing away. About 530 ms.
  static void peel() {
    if (!enabled) return;
    _cancelTimers();
    final amp = _gain.clamp(0.0, 1.0);
    Native.haptic('peel', amp).then((ok) {
      if (!ok) _peelFallback();
    });
  }

  /// A short sampler for Settings, so the person can feel each level.
  static void preview() {
    _cancelTimers();
    _fire('tick', .6);
    _later(130, () => _fire('click', .7));
    _later(300, () => _fire('success', .9));
  }

  // ---- internals -----------------------------------------------------------

  static void _fire(String kind, double base) {
    final amp = (base * _gain).clamp(0.0, 1.0);
    if (amp <= 0) return;
    if (_nativeOk == false) {
      _fallback(kind, amp);
      return;
    }
    Native.haptic(kind, amp).then((ok) {
      if (ok) {
        _nativeOk = true;
      } else {
        _nativeOk ??= false;
        _fallback(kind, amp);
      }
    });
  }

  static void _fallback(String kind, double amp) {
    switch (kind) {
      case 'tick':
      case 'lowtick':
        if (amp > .4) HapticFeedback.selectionClick();
      case 'click':
        HapticFeedback.lightImpact();
      case 'heavy':
        HapticFeedback.mediumImpact();
      case 'thud':
        HapticFeedback.heavyImpact();
      case 'success':
        HapticFeedback.lightImpact();
        _later(70, HapticFeedback.mediumImpact);
      case 'warning':
        HapticFeedback.heavyImpact();
        _later(90, HapticFeedback.heavyImpact);
      default:
        HapticFeedback.selectionClick();
    }
  }

  static void _peelFallback() {
    var t = 0;
    for (var i = 0; i < 9; i++) {
      final at = t;
      final strong = i >= 5;
      _later(at, strong ? HapticFeedback.lightImpact : HapticFeedback.selectionClick);
      t += 90 - i * 7;
    }
  }

  static void _later(int ms, void Function() f) {
    _timers.add(Timer(Duration(milliseconds: ms), f));
  }

  static void _cancelTimers() {
    for (final t in _timers) {
      t.cancel();
    }
    _timers.clear();
  }
}
