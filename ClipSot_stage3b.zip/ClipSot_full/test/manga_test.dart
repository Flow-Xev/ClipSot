import 'package:clipsot/manga.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final base = Uri.parse('https://m.webtoons.com/en/romance/ugly/ep-1/viewer?title_no=1&episode_no=1');

  test('lazy-loaded pages (data-url) are found and the placeholder is ignored', () {
    final html = '''
      <html><head><title>Ep. 1</title></head><body>
      <img src="/static/bg_transparency.png" class="logo">
      ${[for (var i = 1; i <= 5; i++) '<img src="/static/bg_transparency.png" data-url="https://cdn.example.net/ch1/$i.jpg?type=q90" class="_images">'].join()}
      <img src="https://cdn.example.net/ads/banner.jpg" width="300" height="100">
      </body></html>''';
    final r = parseMangaPages(html, base);
    expect(r.pages.length, 5);
    expect(r.pages.first, 'https://cdn.example.net/ch1/1.jpg?type=q90');
  });

  test('pages that only exist inside script JSON are found', () {
    final html = '<script>var imgs = ["https:\\/\\/cdn.example.net\\/c\\/1.png","https:\\/\\/cdn.example.net\\/c\\/2.png",'
        '"https:\\/\\/cdn.example.net\\/c\\/3.png"];</script>';
    expect(parseMangaPages(html, base).pages.length, 3);
  });

  test('srcset picks the largest candidate', () {
    const html = '<img srcset="https://x.org/a/1-400.jpg 400w, https://x.org/a/1-900.jpg 900w">';
    expect(parseMangaPages(html, base).pages, ['https://x.org/a/1-900.jpg']);
  });

  test('image servers get a Referer from the site, Webtoons from www', () {
    expect(mangaHeaders('https://example.org/read/1')['Referer'], 'https://example.org/');
    expect(mangaHeaders('https://m.webtoons.com/en/x')['Referer'], 'https://www.webtoons.com/');
  });
}
