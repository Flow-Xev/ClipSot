package com.clipsot.clipsot

import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.android.FlutterActivityLaunchConfigs
import io.flutter.embedding.engine.FlutterEngine

/** Transparent activity that hosts the Flutter side panel (Dart entry point `panelMain`). */
class PanelActivity : FlutterActivity() {
    private var bridge: Bridge? = null

    override fun getDartEntrypointFunctionName(): String = "panelMain"

    override fun getBackgroundMode(): FlutterActivityLaunchConfigs.BackgroundMode =
        FlutterActivityLaunchConfigs.BackgroundMode.transparent

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        bridge = Bridge(this, flutterEngine, panel = true)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        bridge?.push(intent)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }
}
