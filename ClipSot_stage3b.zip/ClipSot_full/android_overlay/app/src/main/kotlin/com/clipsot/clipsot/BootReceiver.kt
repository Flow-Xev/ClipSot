package com.clipsot.clipsot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Alarms are cleared on reboot/update: put reminders and nudges back. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Reminders.restoreAll(ctx)
        Reminders.restoreRediscovery(ctx)
    }
}
