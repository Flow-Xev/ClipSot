package com.clipsot.clipsot

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Quick Settings tiles. Both open the quick-save sheet over whatever is on screen.
 * The Save link tile first tries the link grabber (page address of the app underneath);
 * without it, the sheet reads the clipboard.
 */
abstract class BaseTile(private val mode: String) : TileService() {
    override fun onStartListening() {
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            updateTile()
        }
    }

    override fun onClick() {
        if (mode == "clipboard") {
            val svc = LinkAccessibilityService.instance
            if (svc != null) {
                svc.grab { link -> launch(if (link != null) "share" else "clipboard", link) }
                return
            }
        }
        launch(mode, null)
    }

    @SuppressLint("StartActivityAndCollapseDeprecated")
    private fun launch(m: String, text: String?) {
        val i = Intent(this, PanelActivity::class.java)
            .putExtra("mode", m)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (text != null) i.putExtra("text", text)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = PendingIntent.getActivity(
                    this, m.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pi)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(i)
            }
        } catch (e: Exception) {
            try { startActivity(i) } catch (_: Exception) {}
        }
    }
}

class SaveTileService : BaseTile("clipboard")
class SurpriseTileService : BaseTile("surprise")
