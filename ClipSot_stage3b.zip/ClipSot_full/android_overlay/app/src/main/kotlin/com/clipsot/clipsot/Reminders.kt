package com.clipsot.clipsot

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.util.Calendar

/** Item reminders and rediscovery nudges, delivered with AlarmManager (no exact-alarm permission needed). */
object Reminders {
    const val ACT_REMIND = "com.clipsot.REMIND"
    const val ACT_REDISCOVER = "com.clipsot.REDISCOVER"
    const val ACT_SNOOZE = "com.clipsot.SNOOZE"
    const val ACT_DONE = "com.clipsot.DONE"
    const val TEST_ID = 1L
    private const val REDISC_ID = 2L
    private const val PREFS = "clipsot_native"
    private const val DAY = 24L * 60 * 60 * 1000

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun am(ctx: Context) = ctx.getSystemService(AlarmManager::class.java)

    private fun pi(ctx: Context, id: Long, action: String, title: String = "", src: String = ""): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(action)
            .putExtra("id", id).putExtra("title", title).putExtra("src", src)
        return PendingIntent.getBroadcast(ctx, Notifs.idFor(id), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun set(ctx: Context, at: Long, pi: PendingIntent) =
        am(ctx).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, maxOf(at, System.currentTimeMillis() + 3000), pi)

    // ---- per-item reminders ---------------------------------------------
    fun schedule(ctx: Context, id: Long, at: Long, title: String, src: String, remember: Boolean = true) {
        if (remember) {
            prefs(ctx).edit().putString("rem_$id", JSONObject().put("at", at).put("title", title).put("src", src).toString()).apply()
        }
        set(ctx, at, pi(ctx, id, ACT_REMIND, title, src))
    }

    fun cancel(ctx: Context, id: Long) {
        am(ctx).cancel(pi(ctx, id, ACT_REMIND))
        prefs(ctx).edit().remove("rem_$id").apply()
    }

    fun cancelAll(ctx: Context) {
        for (k in prefs(ctx).all.keys.filter { it.startsWith("rem_") }) {
            k.removePrefix("rem_").toLongOrNull()?.let { cancel(ctx, it) }
        }
    }

    fun forget(ctx: Context, id: Long) = prefs(ctx).edit().remove("rem_$id").apply()

    fun restoreAll(ctx: Context) {
        for ((k, v) in prefs(ctx).all) {
            if (!k.startsWith("rem_") || v !is String) continue
            val id = k.removePrefix("rem_").toLongOrNull() ?: continue
            try {
                val j = JSONObject(v)
                schedule(ctx, id, j.getLong("at"), j.optString("title"), j.optString("src"), remember = false)
            } catch (_: Exception) { }
        }
    }

    fun snooze(ctx: Context, id: Long, title: String, src: String) {
        val c = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        }
        schedule(ctx, id, c.timeInMillis, title, src)
    }

    // ---- rediscovery -----------------------------------------------------
    /** State saved by the Flutter app (shared_preferences stores it under "flutter."). */
    fun appState(ctx: Context): JSONObject? = try {
        val raw = ctx.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE).getString("flutter.clipsot_v1", null)
        raw?.let { JSONObject(it) }
    } catch (_: Exception) { null }

    private fun nextSlot(freq: String): Long {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        when (freq) {
            "Daily" -> c.add(Calendar.DAY_OF_YEAR, 1)
            "Monthly" -> c.add(Calendar.MONTH, 1)
            else -> c.add(Calendar.DAY_OF_YEAR, 7)
        }
        return c.timeInMillis
    }

    fun scheduleRediscovery(ctx: Context, freq: String) {
        set(ctx, nextSlot(freq), pi(ctx, REDISC_ID, ACT_REDISCOVER))
    }

    fun cancelRediscovery(ctx: Context) = am(ctx).cancel(pi(ctx, REDISC_ID, ACT_REDISCOVER))

    fun restoreRediscovery(ctx: Context) {
        val s = appState(ctx) ?: return
        if (s.optBoolean("rediscovery") && s.optBoolean("notif")) scheduleRediscovery(ctx, s.optString("rdFreq", "Weekly"))
    }

    /** Picks something forgotten, notifies, and schedules the next nudge. */
    fun fireRediscovery(ctx: Context) {
        val s = appState(ctx) ?: return
        if (!s.optBoolean("rediscovery") || !s.optBoolean("notif")) return
        val now = System.currentTimeMillis()
        val items = s.optJSONArray("items")
        val pool = ArrayList<JSONObject>()
        if (items != null) for (n in 0 until items.length()) {
            val it = items.getJSONObject(n)
            if (!it.optBoolean("read") && it.optString("type") != "note" && now - it.optLong("saved") > 7 * DAY) pool.add(it)
        }
        pool.sortBy { it.optLong("saved") }
        val pick = pool.take(5).randomOrNull()
        if (pick != null && Notifs.canPost(ctx)) {
            val days = ((now - pick.optLong("saved")) / DAY).toInt()
            Notifs.show(ctx, pick.getLong("id"), pick.optString("title"), pick.optString("src"), "Saved $days days ago, still unread")
        }
        scheduleRediscovery(ctx, s.optString("rdFreq", "Weekly"))
    }
}
