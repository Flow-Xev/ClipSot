import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../ads.dart';
import '../store.dart';
import '../theme.dart';

/// One native ad, styled like a ClipSot card and labelled "Ad" by Google's template.
/// Shows nothing (no gap, no placeholder) when ads are removed, not allowed by the
/// person's consent choice, not set up, or when no ad could be loaded.
/// Only used on Home. Never place it inside a reader or next to buttons.
class FeedAd extends StatelessWidget {
  const FeedAd({super.key});

  @override
  Widget build(BuildContext context) {
    final removed = StoreScope.of(context).adsRemoved;
    return ListenableBuilder(
      listenable: Ads.I,
      builder: (_, __) => removed || !Ads.I.canShow ? const SizedBox.shrink() : const _AdSlot(),
    );
  }
}

class _AdSlot extends StatefulWidget {
  const _AdSlot();

  @override
  State<_AdSlot> createState() => _AdSlotState();
}

class _AdSlotState extends State<_AdSlot> {
  NativeAd? _ad;
  bool _loaded = false;
  bool _tried = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_tried) return;
    _tried = true;
    final p = P.of(context);
    const ink = Color(0xFF171717);
    final ad = NativeAd(
      adUnitId: Ads.I.nativeUnit,
      request: const AdRequest(),
      listener: NativeAdListener(
        onAdLoaded: (_) {
          if (mounted) setState(() => _loaded = true);
        },
        onAdFailedToLoad: (a, _) {
          a.dispose();
          if (mounted) setState(() => _ad = null);
        },
      ),
      nativeTemplateStyle: NativeTemplateStyle(
        templateType: TemplateType.small,
        mainBackgroundColor: p.s1,
        cornerRadius: 22,
        callToActionTextStyle: NativeTemplateTextStyle(textColor: ink, backgroundColor: p.ac, size: 14),
        primaryTextStyle: NativeTemplateTextStyle(textColor: p.tx, size: 15),
        secondaryTextStyle: NativeTemplateTextStyle(textColor: p.tx2, size: 13),
        tertiaryTextStyle: NativeTemplateTextStyle(textColor: p.tx2, size: 12),
      ),
    );
    _ad = ad;
    ad.load();
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _ad == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 320, minHeight: 90, maxHeight: 120),
        child: AdWidget(ad: _ad!),
      ),
    );
  }
}
