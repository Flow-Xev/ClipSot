import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

const _kKey = 'clipsot_v1';

const _sampleBody = [
  'In a world full of noise, good design feels like a breath of fresh air. It’s not about doing more, but about removing what you don’t need.',
  'Q:Simplicity is the ultimate sophistication.',
  'Every element earns its place. A margin is a decision, a pause is a sentence, and the quiet parts of a page tell you where to look.',
  'Start by taking things away. When nothing else can be removed, what remains is the work.',
];

/// App state + local persistence. Everything stays on the device.
class Store extends ChangeNotifier {
  Store._(this._prefs);
  final SharedPreferences _prefs;

  List<Item> items = [];
  List<String> cols = List.of(kDefaultCols);
  ThemeMode themeMode = ThemeMode.dark;
  String filter = 'All';
  double fontSize = 18;
  double lineHeight = 1.6;
  bool readerDark = false;
  bool seeded = false;
  List<Note> notes = [];
  Map<String, int> colIcons = {};
  List<String> recents = [];
  String defaultCol = 'Reading List';
  bool askNote = true;
  bool notif = false;
  bool rediscovery = false;
  String rdFreq = 'Weekly';
  final Random _rng = Random();

  static Future<Store> load() async {
    final s = Store._(await SharedPreferences.getInstance());
    s._read();
    // Realistic sample data in DEBUG builds only, once.
    if (kDebugMode && !s.seeded && s.items.isEmpty) {
      s.items = _debugSeed();
      s.seeded = true;
      s._persist();
    }
    return s;
  }

  static List<Item> _debugSeed() {
    final n = DateTime.now();
    Item mk(int id, String t, String src, String type, int d, int m, bool r,
            List<String> c, String url,
            {String note = '', bool body = true}) =>
        Item(
          id: id,
          title: t,
          src: src,
          url: url,
          type: type,
          saved: n.subtract(Duration(days: d)),
          mins: m,
          read: r,
          cols: c,
          note: note,
          body: body ? _sampleBody : null,
        );
    return [
      mk(1, 'A quieter way to design', 'designnotes.co', 'article', 0, 6, false,
          ['Reading List', 'Inspiration'], 'https://designnotes.co/quieter'),
      mk(2, 'Android internals', 'youtube.com', 'video', 1, 12, false,
          ['Watch Later'], 'https://youtube.com/watch?v=abc',
          body: false),
      mk(3, 'The art of simplicity', 'minimal.fm', 'article', 2, 8, false,
          ['Reading List'], 'https://minimal.fm/simplicity'),
      mk(4, 'Type systems that scale', 'typography.dev', 'article', 12, 9, true,
          ['Research', 'Favorites'], 'https://typography.dev/scale',
          note: 'Revisit for the reader screen.'),
      mk(5, 'Room database migrations', 'developer.android.com', 'article', 20, 7,
          false, ['Research'], 'https://developer.android.com/room'),
    ];
  }

  void _read() {
    final raw = _prefs.getString(_kKey);
    if (raw == null) return;
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      items = ((j['items'] as List?) ?? [])
          .map((e) => Item.fromJson(e as Map<String, dynamic>))
          .toList();
      cols = ((j['cols'] as List?) ?? kDefaultCols).map((e) => e.toString()).toList();
      themeMode = ThemeMode.values.firstWhere(
        (m) => m.name == j['theme'],
        orElse: () => ThemeMode.dark,
      );
      fontSize = ((j['fs'] ?? 18) as num).toDouble();
      lineHeight = ((j['ls'] ?? 1.6) as num).toDouble();
      readerDark = (j['rdark'] ?? false) as bool;
      seeded = (j['seeded'] ?? false) as bool;
      notes = ((j['notes'] as List?) ?? [])
          .map((e) => Note.fromJson(e as Map<String, dynamic>))
          .toList();
      colIcons = ((j['colIcons'] as Map?) ?? {})
          .map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
      recents = ((j['recents'] as List?) ?? []).map((e) => e.toString()).toList();
      defaultCol = (j['defaultCol'] ?? 'Reading List') as String;
      askNote = (j['askNote'] ?? true) as bool;
      notif = (j['notif'] ?? false) as bool;
      rediscovery = (j['rediscovery'] ?? false) as bool;
      rdFreq = (j['rdFreq'] ?? 'Weekly') as String;
    } catch (e) {
      debugPrint('ClipSot: could not read saved data: $e');
    }
  }

  void _persist() {
    final j = {
      'items': items.map((e) => e.toJson()).toList(),
      'cols': cols,
      'theme': themeMode.name,
      'fs': fontSize,
      'ls': lineHeight,
      'rdark': readerDark,
      'seeded': seeded,
      'notes': notes.map((e) => e.toJson()).toList(),
      'colIcons': colIcons,
      'recents': recents,
      'defaultCol': defaultCol,
      'askNote': askNote,
      'notif': notif,
      'rediscovery': rediscovery,
      'rdFreq': rdFreq,
    };
    _prefs.setString(_kKey, jsonEncode(j));
  }

  void _commit() {
    _persist();
    notifyListeners();
  }

  // ---- queries -----------------------------------------------------------
  Item? byId(int id) {
    for (final i in items) {
      if (i.id == id) return i;
    }
    return null;
  }

  List<Item> get filtered {
    final t = kFilterType[filter];
    final l = items.where((i) {
      if (filter == 'All') return true;
      if (filter == 'Unread') return !i.read;
      return i.type == t;
    }).toList();
    l.sort((a, b) => b.saved.compareTo(a.saved));
    return l;
  }

  /// Oldest-first candidate for "Rediscover": unread and saved over 7 days ago.
  Item? get forgotten {
    final l = items.where((i) => !i.read && i.daysAgo > 7).toList()
      ..sort((a, b) => a.saved.compareTo(b.saved));
    return l.isEmpty ? null : l.first;
  }

  int countIn(String col) => items.where((i) => i.cols.contains(col)).length;

  // ---- mutations ---------------------------------------------------------
  void setFilter(String f) {
    filter = f;
    notifyListeners();
  }

  /// Returns false when the link is already saved.
  bool addItem(Item it) {
    if (items.any((i) => i.url == it.url)) return false;
    items.insert(0, it);
    filter = 'All';
    _commit();
    return true;
  }

  void removeItem(int id) {
    items.removeWhere((i) => i.id == id);
    _commit();
  }

  void markOpened(Item i) {
    if (!i.isVideo && !i.read) {
      i.read = true;
      _commit();
    }
  }

  void toggleRead(Item i) {
    i.read = !i.read;
    _commit();
  }

  /// Returns true if the item is now in the collection.
  bool toggleCol(Item i, String col) {
    if (i.cols.contains(col)) {
      i.cols.remove(col);
      _commit();
      return false;
    }
    i.cols.add(col);
    _commit();
    return true;
  }

  void setNote(Item i, String n) {
    i.note = n;
    _commit();
  }

  void setReader({double? fs, double? ls, bool? dark}) {
    if (fs != null) fontSize = fs;
    if (ls != null) lineHeight = ls;
    if (dark != null) readerDark = dark;
    _commit();
  }

  // ---- collections -------------------------------------------------------
  int iconOf(String col) => colIcons[col] ?? kDefaultIcon[col] ?? 0;

  /// Returns an error message, or null on success.
  String? addCol(String name, int icon) {
    final n = name.trim();
    if (n.isEmpty) return 'Give it a name';
    if (_nameTaken(n)) return 'That name already exists';
    cols.add(n);
    colIcons[n] = icon;
    _commit();
    return null;
  }

  bool _nameTaken(String n, {String? except}) =>
      kLockedCols.any((c) => c.toLowerCase() == n.toLowerCase()) ||
      cols.any((c) => c != except && c.toLowerCase() == n.toLowerCase());

  String? editCol(String old, String name, int icon) {
    final n = name.trim();
    if (n.isEmpty) return 'Give it a name';
    if (n != old && _nameTaken(n, except: old)) return 'That name already exists';
    if (n != old) {
      final i = cols.indexOf(old);
      if (i >= 0) cols[i] = n;
      for (final it in items) {
        final k = it.cols.indexOf(old);
        if (k >= 0) it.cols[k] = n;
      }
      colIcons.remove(old);
      if (defaultCol == old) defaultCol = n;
    }
    colIcons[n] = icon;
    _commit();
    return null;
  }

  void deleteCol(String name) {
    cols.remove(name);
    colIcons.remove(name);
    for (final it in items) {
      it.cols.remove(name);
    }
    if (defaultCol == name) defaultCol = 'Reading List';
    _commit();
  }

  List<Item> itemsIn(String col) {
    final l = col == 'All Items' ? List.of(items) : items.where((i) => i.cols.contains(col)).toList();
    l.sort((a, b) => b.saved.compareTo(a.saved));
    return l;
  }

  // ---- notes -------------------------------------------------------------
  Note? noteById(int id) {
    for (final n in notes) {
      if (n.id == id) return n;
    }
    return null;
  }

  void saveNote(Note n) {
    n.updated = DateTime.now();
    if (!notes.any((x) => x.id == n.id)) notes.insert(0, n);
    _commit();
  }

  void deleteNote(int id) {
    notes.removeWhere((n) => n.id == id);
    _commit();
  }

  // ---- search ------------------------------------------------------------
  void addRecent(String q) {
    final t = q.trim();
    if (t.isEmpty) return;
    recents.remove(t);
    recents.insert(0, t);
    if (recents.length > 8) recents = recents.sublist(0, 8);
    _commit();
  }

  void clearRecents() {
    recents = [];
    _commit();
  }

  // ---- rediscovery -------------------------------------------------------
  /// Unread items saved more than a week ago, oldest first (max [n]).
  List<Item> forgottenList(int n) {
    final l = items.where((i) => !i.read && i.daysAgo > 7).toList()
      ..sort((a, b) => a.saved.compareTo(b.saved));
    return l.take(n).toList();
  }

  Item? randomItem() => items.isEmpty ? null : items[_rng.nextInt(items.length)];

  // ---- settings ----------------------------------------------------------
  void setPrefs({String? defCol, bool? ask, bool? n, bool? rd, String? freq}) {
    if (defCol != null) defaultCol = defCol;
    if (ask != null) askNote = ask;
    if (n != null) notif = n;
    if (rd != null) rediscovery = rd;
    if (freq != null) rdFreq = freq;
    _commit();
  }

  /// Adds links; returns how many were new and valid.
  int importLinks(String raw) {
    var n = 0;
    for (final t in raw.split(RegExp(r'\s+')).where((e) => e.isNotEmpty)) {
      final it = Item.fromUrl(t, '', []);
      if (it != null && !items.any((i) => i.url == it.url)) {
        // ids must be unique even when created in the same microsecond
        items.add(Item(
          id: it.id + n,
          title: it.title,
          src: it.src,
          url: it.url,
          type: it.type,
          saved: it.saved,
        ));
        n++;
      }
    }
    if (n > 0) _commit();
    return n;
  }

  String exportJson() => const JsonEncoder.withIndent(' ').convert({
        'app': 'ClipSot',
        'version': 1,
        'items': items.map((e) => e.toJson()).toList(),
        'notes': notes.map((e) => e.toJson()).toList(),
        'collections': cols,
      });

  int get storageBytes => utf8.encode(jsonEncode({
        'items': items.map((e) => e.toJson()).toList(),
        'notes': notes.map((e) => e.toJson()).toList(),
      })).length;

  void deleteAll() {
    items = [];
    notes = [];
    cols = List.of(kDefaultCols);
    colIcons = {};
    recents = [];
    seeded = true; // don't re-seed sample data after a deliberate wipe
    _commit();
  }

  void setTheme(ThemeMode m) {
    themeMode = m;
    _commit();
  }
}

class StoreScope extends InheritedNotifier<Store> {
  const StoreScope({super.key, required Store store, required super.child})
      : super(notifier: store);

  /// Reads the store without subscribing (safe in initState / callbacks).
  static Store read(BuildContext c) =>
      c.getInheritedWidgetOfExactType<StoreScope>()!.notifier!;

  static Store of(BuildContext c) =>
      c.dependOnInheritedWidgetOfExactType<StoreScope>()!.notifier!;
}
