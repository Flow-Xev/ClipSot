package com.clipsot.clipsot

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val id = i.getLongExtra("id", 0L)
        val title = i.getStringExtra("title") ?: ""
        val src = i.getStringExtra("src") ?: ""
        when (i.action) {
            Reminders.ACT_REMIND -> {
                Reminders.forget(ctx, id)
                if (Notifs.canPost(ctx)) Notifs.show(ctx, id, title, src, "Reminder")
            }
            Reminders.ACT_REDISCOVER -> Reminders.fireRediscovery(ctx)
            Reminders.ACT_SNOOZE -> {
                ctx.getSystemService(NotificationManager::class.java).cancel(Notifs.idFor(id))
                Reminders.snooze(ctx, id, title, src)
            }
            Reminders.ACT_DONE ->
                ctx.getSystemService(NotificationManager::class.java).cancel(Notifs.idFor(id))
        }
    }
}
