import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'sheets.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  String _themeLabel(ThemeMode m) =>
      m == ThemeMode.dark ? 'Dark' : (m == ThemeMode.light ? 'Light' : 'System');

  String _size(int b) => b < 1024 ? '$b B' : (b < 1048576 ? '${(b / 1024).toStringAsFixed(1)} KB' : '${(b / 1048576).toStringAsFixed(1)} MB');

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final s = StoreScope.of(context);

    Widget row(IconData icon, String label, {String? value, String? sub, Widget? trailing, VoidCallback? onTap, Color? color}) {
      return Tap(
        onTap: onTap,
        label: label,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Row(children: [
            Icon(icon, size: 22, color: color ?? p.tx),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: ts(16, color: color ?? p.tx)),
                if (sub != null) Text(sub, style: ts(12.5, color: p.tx2)),
              ]),
            ),
            if (value != null) Text(value, style: ts(14, color: p.tx2)),
            if (trailing != null) trailing,
            if (trailing == null && onTap != null && color == null)
              Icon(Icons.chevron_right, size: 20, color: p.tx2),
          ]),
        ),
      );
    }

    Widget rule() => Divider(height: 1, color: p.s1);

    Widget heading(String t) => Padding(
          padding: const EdgeInsets.only(top: 22, bottom: 4),
          child: Text(t.toUpperCase(), style: ts(12, color: p.tx2, ls: .6)),
        );

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 140),
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 8),
          child: Text('Settings', style: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx)),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Row(children: [
            Container(
              width: 68,
              height: 68,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: p.ac, shape: BoxShape.circle),
              child: Text('C', style: ts(26, w: FontWeight.w600, color: const Color(0xFF171717))),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Local library', style: ts(22, color: p.tx)),
                Text('No account · ${s.items.length} saved · ${s.notes.length} notes',
                    style: ts(13, color: p.tx2)),
              ]),
            ),
          ]),
        ),
        rule(),
        heading('General'),
        row(Icons.wb_sunny_outlined, 'Appearance', value: _themeLabel(s.themeMode), onTap: () {
          showChoice(
            context,
            title: 'Appearance',
            options: const ['Dark', 'Light', 'System'],
            current: _themeLabel(s.themeMode),
            onPick: (v) => s.setTheme(v == 'Dark' ? ThemeMode.dark : (v == 'Light' ? ThemeMode.light : ThemeMode.system)),
          );
        }),
        rule(),
        row(Icons.folder_outlined, 'Default collection', value: s.defaultCol, onTap: () {
          showChoice(
            context,
            title: 'Default collection',
            options: s.cols,
            current: s.defaultCol,
            onPick: (v) => s.setPrefs(defCol: v),
          );
        }),
        rule(),
        row(Icons.edit_outlined, 'Note field when saving',
            sub: 'Show an optional note in the save sheet',
            trailing: Sw(on: s.askNote, onChanged: (v) => s.setPrefs(ask: v), label: 'Note field when saving')),
        heading('Reminders'),
        row(Icons.notifications_none, 'Notifications',
            sub: 'Delivery is added in Stage 3',
            trailing: Sw(on: s.notif, onChanged: (v) => s.setPrefs(n: v), label: 'Notifications')),
        rule(),
        row(Icons.auto_awesome_outlined, 'Rediscovery reminders',
            sub: 'A gentle nudge about things you forgot',
            trailing: Sw(on: s.rediscovery, onChanged: (v) => s.setPrefs(rd: v), label: 'Rediscovery reminders')),
        if (s.rediscovery) ...[
          rule(),
          row(Icons.schedule, 'Frequency', value: s.rdFreq, onTap: () {
            showChoice(
              context,
              title: 'Remind me',
              options: const ['Daily', 'Weekly', 'Monthly'],
              current: s.rdFreq,
              onPick: (v) => s.setPrefs(freq: v),
            );
          }),
        ],
        heading('Your data'),
        row(Icons.ios_share, 'Export library', value: 'JSON', onTap: () {
          if (s.items.isEmpty && s.notes.isEmpty) {
            toast(context, 'Nothing to export yet');
            return;
          }
          Share.share(s.exportJson(), subject: 'ClipSot library');
        }),
        rule(),
        row(Icons.download_outlined, 'Import links', onTap: () => showImportSheet(context)),
        rule(),
        row(Icons.storage_outlined, 'Storage', value: _size(s.storageBytes), onTap: () {
          toast(context, 'Stored on this device only');
        }),
        heading('About'),
        row(Icons.shield_outlined, 'Privacy', onTap: () {
          showDialog<void>(
            context: context,
            builder: (_) => AlertDialog(
              backgroundColor: kSheetBg,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              title: Text('Privacy', style: ts(20, w: FontWeight.w500, color: kSheetInk)),
              content: Text(
                'No account. No ads. No analytics. Your library lives on this device and is never uploaded. '
                'ClipSot only contacts a website when you ask it to open a link.',
                style: ts(14, color: const Color(0xFF55544F), h: 1.4),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Close', style: ts(15, color: kSheetInk)),
                ),
              ],
            ),
          );
        }),
        rule(),
        row(Icons.info_outline, 'About ClipSot', value: 'v0.2', onTap: () {
          toast(context, 'ClipSot · Save now. Find anytime.');
        }),
        rule(),
        row(Icons.description_outlined, 'Open-source licenses', onTap: () {
          showLicensePage(context: context, applicationName: 'ClipSot', applicationVersion: '0.2');
        }),
        rule(),
        row(Icons.delete_outline, 'Delete all data', color: kDanger, onTap: () async {
          final m = ScaffoldMessenger.of(context);
          final ok = await confirm(
            context,
            'Delete everything?',
            'All saved items, notes and collections will be removed from this device. This can’t be undone.',
            'Delete all',
          );
          if (!ok) return;
          s.deleteAll();
          toastWith(m, p, 'Library cleared');
        }),
      ],
    );
  }
}
