import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'sheets.dart';

/// Full-screen viewer for saved images (pinch to zoom).
class ImageScreen extends StatelessWidget {
  final int id;
  const ImageScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final it = store.byId(id);
    if (it == null || it.path == null) return Scaffold(backgroundColor: p.bg);
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              RoundIcon(Icons.arrow_back_ios_new, label: 'Back', color: Colors.white, onTap: () => Navigator.pop(context)),
              Row(children: [
                RoundIcon(Icons.ios_share,
                    label: 'Share image', color: Colors.white, onTap: () => Share.shareXFiles([XFile(it.path!)])),
                RoundIcon(Icons.more_vert,
                    label: 'More',
                    color: Colors.white,
                    onTap: () => showItemActions(context, it.id, onDeleted: () => Navigator.of(context).maybePop())),
              ]),
            ]),
          ),
          Expanded(
            child: InteractiveViewer(
              maxScale: 6,
              child: Center(
                child: Image.file(
                  File(it.path!),
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Text('This image is no longer on the device.', style: ts(15, color: Colors.white70)),
                ),
              ),
            ),
          ),
          if (it.title.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              child: Text(it.title, style: ts(14, color: Colors.white70)),
            ),
        ]),
      ),
    );
  }
}
