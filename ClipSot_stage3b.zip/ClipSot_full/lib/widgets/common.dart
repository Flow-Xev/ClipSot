
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../haptics.dart';
import '../models.dart';
import '../theme.dart';
import 'cover.dart';
import 'peel.dart';
import '../screens/home.dart' show openItem;
import '../screens/sheets.dart' show showItemActions;

/// Press-scale feedback used across the app (replaces ink ripples).
class Tap extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final String? label;

  /// Long-press opens the link side panel on item cards and rows.
  final VoidCallback? onLong;

  /// A soft tick on tap. Turn off when the caller plays its own haptic.
  final bool haptic;
  const Tap({super.key, required this.child, this.onTap, this.label, this.onLong, this.haptic = true});

  @override
  State<Tap> createState() => _TapState();
}

class _TapState extends State<Tap> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: widget.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) => setState(() => _down = false),
        onTapCancel: () => setState(() => _down = false),
        onTap: widget.onTap == null
            ? null
            : () {
                if (widget.haptic) Haptics.tap();
                widget.onTap!();
              },
        onLongPress: widget.onLong == null
            ? null
            : () {
                Haptics.longPress();
                setState(() => _down = false);
                widget.onLong!();
              },
        child: AnimatedScale(
          scale: _down ? 0.96 : 1,
          duration: const Duration(milliseconds: 120),
          child: widget.child,
        ),
      ),
    );
  }
}

/// Entrance animation: fade + rise, staggered by [i].
class Rise extends StatefulWidget {
  final int i;
  final Widget child;
  const Rise({super.key, this.i = 0, required this.child});

  @override
  State<Rise> createState() => _RiseState();
}

class _RiseState extends State<Rise> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 550));

  @override
  void initState() {
    super.initState();
    final delay = 45 * widget.i.clamp(0, 10).toInt();
    Future.delayed(Duration(milliseconds: delay), () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) return widget.child;
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (_, ch) {
        final t = Curves.easeOutCubic.transform(_c.value);
        return Opacity(
          opacity: t,
          child: Transform.translate(offset: Offset(0, 22 * (1 - t)), child: ch),
        );
      },
    );
  }
}

/// Filter / collection chip. [sheet] = style for the light bottom sheets.
class Pill extends StatelessWidget {
  final String label;
  final bool on;
  final VoidCallback onTap;
  final bool sheet;
  const Pill(this.label, {super.key, required this.on, required this.onTap, this.sheet = false});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final bg = sheet ? (on ? kSheetInk : kSheetChip) : (on ? p.tx : p.s1);
    final fg = sheet ? (on ? const Color(0xFFF4F3F0) : kSheetInk) : (on ? p.bg : p.tx);
    return Tap(
      haptic: false,
      onTap: () {
        Haptics.select();
        onTap();
      },
      label: label,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
        child: Text(label, style: ts(14, color: fg)),
      ),
    );
  }
}

class RoundIcon extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final String label;
  final Color? color;
  const RoundIcon(this.icon, {super.key, required this.onTap, required this.label, this.color});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Tap(
      onTap: onTap,
      label: label,
      child: SizedBox(
        width: 40,
        height: 40,
        child: Icon(icon, size: 22, color: color ?? p.tx),
      ),
    );
  }
}

/// Floating pill toast, used for success + error feedback.
void toastWith(ScaffoldMessengerState m, P p, String msg) {
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Center(child: Text(msg, style: ts(14, color: p.bg))),
    backgroundColor: p.tx,
    behavior: SnackBarBehavior.floating,
    elevation: 0,
    margin: const EdgeInsets.fromLTRB(56, 0, 56, 100),
    shape: const StadiumBorder(),
    duration: const Duration(milliseconds: 1800),
  ));
}

void toast(BuildContext c, String msg) =>
    toastWith(ScaffoldMessenger.of(c), P.of(c), msg);

Future<void> openExternal(BuildContext context, String url) async {
  final m = ScaffoldMessenger.of(context);
  final p = P.of(context);
  try {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok) toastWith(m, p, 'Couldn’t open that link');
  } catch (_) {
    toastWith(m, p, 'Couldn’t open that link');
  }
}

/// Confirmation dialog for destructive actions. Returns true if confirmed.
Future<bool> confirm(BuildContext context, String title, String body, String action,
    {bool danger = true}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      backgroundColor: kSheetBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      title: Text(title, style: ts(20, w: FontWeight.w500, color: kSheetInk)),
      content: Text(body, style: ts(14, color: const Color(0xFF55544F), h: 1.4)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: Text('Cancel', style: ts(15, color: kSheetInk)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, true),
          child: Text(action, style: ts(15, w: FontWeight.w600, color: danger ? kDanger : kSheetInk)),
        ),
      ],
    ),
  );
  return r ?? false;
}

/// Toggle switch matching the design.
class Sw extends StatelessWidget {
  final bool on;
  final ValueChanged<bool> onChanged;
  final String label;
  const Sw({super.key, required this.on, required this.onChanged, required this.label});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Semantics(
      toggled: on,
      label: label,
      child: Tap(
        haptic: false,
        onTap: () {
          Haptics.toggle(!on);
          onChanged(!on);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOutCubic,
          width: 50,
          height: 30,
          padding: const EdgeInsets.all(3),
          alignment: on ? Alignment.centerRight : Alignment.centerLeft,
          decoration: BoxDecoration(
            color: on ? p.ac : p.s2,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: on ? Colors.white : p.tx2,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}

/// Splits [q] into lowercase search tokens.
List<String> tokens(String q) =>
    q.toLowerCase().split(RegExp(r'\s+')).where((t) => t.isNotEmpty).toList();

/// Text with matching [toks] highlighted.
TextSpan highlight(String text, List<String> toks, TextStyle style, P p) {
  if (toks.isEmpty || text.isEmpty) return TextSpan(text: text, style: style);
  final re = RegExp(toks.map(RegExp.escape).join('|'), caseSensitive: false);
  final spans = <InlineSpan>[];
  var last = 0;
  for (final m in re.allMatches(text)) {
    if (m.start > last) spans.add(TextSpan(text: text.substring(last, m.start)));
    spans.add(TextSpan(
      text: m.group(0),
      style: TextStyle(backgroundColor: p.ac, color: const Color(0xFF171717)),
    ));
    last = m.end;
  }
  if (last < text.length) spans.add(TextSpan(text: text.substring(last)));
  return TextSpan(style: style, children: spans);
}

/// List row used by collections and search.
class ItemRow extends StatelessWidget {
  final Item item;
  final List<String> toks;
  const ItemRow(this.item, {super.key, this.toks = const []});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final it = item;
    final meta = [
      it.src,
      it.type,
      if (it.mins > 0) '${it.mins} min',
    ].join(' \u00B7 ');
    return PeelItem(
      id: it.id,
      child: Tap(
      onTap: () => openItem(context, it),
      onLong: () => showItemActions(context, it.id),
      label: it.title,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.s1))),
        child: Row(children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: it.isMedia
                    ? const [Color(0xFFC9A574), Color(0xFF6E5A3C)]
                    : const [Color(0xFF77776F), Color(0xFF2B2B2B)],
              ),
            ),
            clipBehavior: Clip.antiAlias,
            child: coverProvider(it, width: 200) != null
                ? Image(image: coverProvider(it, width: 200)!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox())
                : (it.isMedia
                    ? Icon(it.isVideo ? Icons.play_arrow : Icons.headphones, color: Colors.white)
                    : (it.isFile ? const Icon(Icons.description_outlined, color: Colors.white) : null)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text.rich(highlight(it.title, toks, ts(16, w: FontWeight.w500, h: 1.2, color: p.tx), p)),
              const SizedBox(height: 3),
              Text.rich(highlight(meta, toks, ts(13, color: p.tx2), p)),
              if (it.note.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text.rich(highlight(it.note, toks, ts(13, color: p.tx2), p),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
            ]),
          ),
          RoundIcon(Icons.more_vert, label: 'More', onTap: () => showItemActions(context, it.id)),
        ]),
      ),
    ));
  }
}

/// Rounded search field.
class SearchField extends StatelessWidget {
  final TextEditingController c;
  final String hint;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  const SearchField(this.c, this.hint, {super.key, this.onChanged, this.onSubmitted});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(24)),
      child: Row(children: [
        Icon(Icons.search, size: 22, color: p.tx2),
        const SizedBox(width: 12),
        Expanded(
          child: TextField(
            controller: c,
            onChanged: onChanged,
            onSubmitted: onSubmitted,
            textInputAction: TextInputAction.search,
            cursorColor: p.ac,
            style: ts(15, color: p.tx),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: ts(15, color: p.tx2),
              border: InputBorder.none,
              isDense: true,
            ),
          ),
        ),
      ]),
    );
  }
}
