# ClipSot (Flutter)

Save now. Find anytime. A private, offline-first personal library.

## Status: Stage 2 of 3

Done: design system, splash, home (filters, cards, rediscovery with "Surprise me"),
save sheet (default collection, optional note), item actions, article reader,
video screen, **Collections** (create/rename/icon/delete, search inside, All Items),
**Search** (every word must match; titles, URLs, sources, notes, article text,
collections; filters, sorting, highlighting, recents), **Notes** (create/edit/delete,
tags, attach to a saved item, share), **Settings** (appearance, default collection,
save behaviour, reminders prefs, export JSON, import links, storage, privacy,
licenses, delete all).

Coming in Stage 3: Android share-sheet intake, metadata + readable-text extraction,
image/PDF file saving, file-based backup/restore, real reminder delivery, tests.

## Run it

This archive contains `lib/`, `pubspec.yaml` and tests only. Generate the Android
platform folder once, then run:

```bash
cd clipsot
flutter create . --org com.clipsot --project-name clipsot --platforms android
flutter pub get
flutter run
```

Requires Flutter 3.22 or newer.

## Notes

- Sample articles are seeded only in **debug** builds. Release builds start empty.
- Readable-text extraction and metadata fetching arrive in Stage 3; until then
  saved links show an "Open original site" fallback in the reader.
- The font is Inter Tight via `google_fonts` (downloaded on first run, then cached).
  Bundle the font files as assets if you need guaranteed first-run offline typography.
