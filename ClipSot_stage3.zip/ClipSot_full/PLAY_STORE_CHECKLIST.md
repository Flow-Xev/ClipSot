# ClipSot: Google Play checklist

Nobody can guarantee approval, but these are the things Play reviews for an app like this.
Items marked **YOU** need you in Play Console; the rest is already done in the code.

## Already done in the app
- [x] No account, no ads, no analytics, no tracking SDKs. Library stays on the device.
- [x] Privacy screen in Settings that matches what the app really does.
- [x] Deleting is reversible: Trash for 30 days, Undo after every delete, "Empty Trash" asks first.
- [x] Haptics use only the normal `VIBRATE` permission, respect the system "Touch feedback" switch, and can be turned off (Settings › Haptics).
- [x] The paper-peel animation is skipped when the phone's "remove animations" setting is on.
- [x] Clipboard is read only when you tap Paste (never in the background).
- [x] Optional permissions (notifications, display over other apps) are asked only when the person turns the feature on.
- [x] `allowBackup="false"`, no cleartext traffic (Android default for current targets).

## YOU: needed in Play Console
- [ ] **Privacy policy URL** (required because the app uses the INTERNET permission and notifications). Host a page that says the same as the Privacy screen.
- [ ] **Data safety form**: "No data collected, no data shared". Fetching a page you saved is a request to that site, not collection by you.
- [ ] **Foreground service declaration** for `FOREGROUND_SERVICE_SPECIAL_USE` (the edge handle). Subtype text is already in the manifest: "Floating edge handle that opens the quick-save panel". Be ready to attach a short screen recording.
- [ ] **Display over other apps (`SYSTEM_ALERT_WINDOW`)** is a reviewed permission. It is optional and off by default here, but if you want the fastest approval, ship without the edge handle first (remove the permission, the service, and the Settings row) and add it in a later update.
- [ ] Content rating questionnaire. Say it is a reader/bookmark tool with user-chosen web content.
- [ ] Target API level: build with the latest stable Flutter so `targetSdk` meets Play's current requirement. Check in Play Console › App content.
- [ ] Increase `version:` in pubspec.yaml (the number after `+`) for every upload.
- [ ] Upload an **AAB** (`flutter build appbundle --release`). Play does not accept APKs for new apps. The current workflow builds an APK for sideloading.
- [ ] Store listing: icon (512 px, in `brand/`), feature graphic, at least 2 phone screenshots.

## Manga: the one real policy risk
- Play's Intellectual Property policy: the app must not host or distribute other people's copyrighted work, and must not encourage piracy.
- ClipSot saves a link and reads pages on the person's own device, like a browser reading mode. Keep it that way:
  - Do not ship a built-in list of manga sites, a search, or a catalogue.
  - Do not name or advertise pirate sites in the listing, screenshots or app text.
  - Keep a visible way to report content / contact you in the store listing.
- The Privacy screen already says users should read only what they have the right to read.
