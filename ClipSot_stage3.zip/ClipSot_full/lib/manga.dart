import 'dart:convert';

import 'package:http/http.dart' as http;

import 'extract.dart';

/// Page images found on a saved manga / comic link.
class MangaResult {
  final String? title;

  /// Page image addresses in reading order. Empty when none were found.
  final List<String> pages;
  const MangaResult({this.title, this.pages = const []});
}

const _ua = 'Mozilla/5.0 (Android) ClipSot/0.6';
const _maxPages = 400;

/// Looks up the pages of a chapter from the link the person saved.
///
/// - A direct image link is a one-page chapter.
/// - MangaDex chapter links use MangaDex's own public API.
/// - Any other page is read for the images a reader would see on it.
///
/// Only the addresses are kept; no image is downloaded or stored here. Returns
/// null when the page can't be reached.
Future<MangaResult?> fetchManga(String url) async {
  try {
    final u = Uri.parse(url);
    if (u.scheme != 'http' && u.scheme != 'https') return null;
    if (RegExp(r'\.(jpe?g|png|webp|avif)$', caseSensitive: false).hasMatch(u.path)) {
      return MangaResult(pages: [url]);
    }
    final md = RegExp(r'mangadex\.org/(?:[a-z]{2}/)?chapter/([0-9a-fA-F-]{36})').firstMatch(url);
    if (md != null) return await _mangaDex(md.group(1)!);

    final res = await http.get(u, headers: {
      'User-Agent': _ua,
      'Accept': 'text/html,application/xhtml+xml',
    }).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) return null;
    final type = res.headers['content-type'] ?? '';
    if (type.isNotEmpty && !type.contains('html')) return null;
    return parseMangaPages(utf8.decode(res.bodyBytes, allowMalformed: true), u);
  } catch (_) {
    return null;
  }
}

Future<MangaResult?> _mangaDex(String id) async {
  try {
    final srv = await http
        .get(Uri.parse('https://api.mangadex.org/at-home/server/$id'), headers: {'User-Agent': 'ClipSot/0.6'})
        .timeout(const Duration(seconds: 15));
    if (srv.statusCode != 200) return null;
    final j = jsonDecode(srv.body) as Map<String, dynamic>;
    final base = j['baseUrl'] as String?;
    final ch = j['chapter'] as Map<String, dynamic>?;
    final hash = ch?['hash'] as String?;
    final files = (ch?['data'] as List?)?.map((e) => e.toString()).toList();
    if (base == null || hash == null || files == null) return null;
    final pages = [for (final f in files) '$base/data/$hash/$f'];
    return MangaResult(title: await _mangaDexTitle(id), pages: pages);
  } catch (_) {
    return null;
  }
}

Future<String?> _mangaDexTitle(String id) async {
  try {
    final r = await http
        .get(Uri.parse('https://api.mangadex.org/chapter/$id?includes[]=manga'), headers: {'User-Agent': 'ClipSot/0.6'})
        .timeout(const Duration(seconds: 10));
    if (r.statusCode != 200) return null;
    final d = (jsonDecode(r.body) as Map<String, dynamic>)['data'] as Map<String, dynamic>;
    final attrs = (d['attributes'] as Map?) ?? const {};
    String? series;
    for (final rel in (d['relationships'] as List? ?? const [])) {
      if (rel is Map && rel['type'] == 'manga') {
        final t = (rel['attributes'] as Map?)?['title'];
        if (t is Map && t.isNotEmpty) series = (t['en'] ?? t.values.first).toString();
      }
    }
    final chNo = attrs['chapter']?.toString();
    final name = (attrs['title'] ?? '').toString().trim();
    final tail = [if (chNo != null && chNo.isNotEmpty) 'Ch. $chNo', if (name.isNotEmpty) name].join(' · ');
    final out = [if (series != null) series, if (tail.isNotEmpty) tail].join(' – ');
    return out.isEmpty ? null : out;
  } catch (_) {
    return null;
  }
}

String? _attr(String tag, String name) {
  final m = RegExp('(?<![\\w-])$name\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\')', caseSensitive: false).firstMatch(tag);
  final v = (m?.group(1) ?? m?.group(2))?.trim();
  return v == null || v.isEmpty ? null : v;
}

final _junk = RegExp(
  r'(logo|icon|avatar|banner|sprite|emoji|spinner|loading|placeholder|favicon|/ads?[/_-]|button|badge|thumb|gravatar|pixel|tracking)',
  caseSensitive: false,
);

/// Pure HTML -> page list. Public so it can be unit tested.
///
/// Reads every <img>, prefers lazy-load attributes (data-src...), drops icons,
/// logos, tiny images and tracking pixels, then keeps the largest group that
/// lives in the same folder (a chapter's pages normally do).
MangaResult parseMangaPages(String html, Uri base) {
  final title = parseReadable(html, titleOnly: true).title;
  final found = <String>[];
  final seen = <String>{};

  for (final m in RegExp(r'<img\b[^>]*>', caseSensitive: false, dotAll: true).allMatches(html)) {
    final tag = m.group(0)!;
    String? src;
    for (final a in const ['data-src', 'data-lazy-src', 'data-original', 'data-url', 'src']) {
      final v = _attr(tag, a);
      if (v != null && !v.startsWith('data:')) {
        src = v;
        break;
      }
    }
    if (src == null) continue;
    final w = int.tryParse(_attr(tag, 'width') ?? '');
    final h = int.tryParse(_attr(tag, 'height') ?? '');
    if ((w != null && w < 120) || (h != null && h < 120)) continue;

    Uri? u;
    try {
      u = base.resolve(src.replaceAll('&amp;', '&'));
    } catch (_) {
      continue;
    }
    if (u.scheme != 'http' && u.scheme != 'https') continue;
    final path = u.path.toLowerCase();
    if (path.endsWith('.svg') || path.endsWith('.gif') || path.endsWith('.ico')) continue;
    final s = u.toString();
    if (_junk.hasMatch(s)) continue;
    if (seen.add(s)) found.add(s);
    if (found.length >= _maxPages * 2) break;
  }

  var pages = found;
  if (found.length >= 4) {
    String dir(String s) => s.substring(0, s.lastIndexOf('/') + 1);
    final counts = <String, int>{};
    for (final s in found) {
      counts.update(dir(s), (c) => c + 1, ifAbsent: () => 1);
    }
    final best = counts.entries.reduce((a, b) => b.value > a.value ? b : a);
    if (best.value >= 3) pages = found.where((s) => dir(s) == best.key).toList();
  }
  if (pages.length > _maxPages) pages = pages.sublist(0, _maxPages);
  return MangaResult(title: title, pages: pages);
}
