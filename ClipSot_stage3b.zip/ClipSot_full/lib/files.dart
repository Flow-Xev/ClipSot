import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'extract.dart';
import 'models.dart';
import 'sources.dart';

export 'sources.dart' show kImageExt, kVideoExt, kAudioExt, kDocExt, kHtmlExt, kComicExt, kAllExt, fileKind;

/// Biggest download ClipSot makes on its own (direct file links).
const kMaxDownload = 250 * 1024 * 1024;

String _base(String path) => path.split(RegExp(r'[\\/]')).last;

String _safe(String n) => n.replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');

/// Where saved files live (private to the app).
Future<Directory> libDir() async {
  final d = Directory('${(await getApplicationDocumentsDirectory()).path}/library');
  if (!await d.exists()) await d.create(recursive: true);
  return d;
}

/// 'image' | 'video' | 'audio' | 'document' by extension.
String fileType(String name) {
  final k = fileKind(name);
  return k == 'image' || k == 'video' || k == 'audio' ? k : 'document';
}

String _title(String fname) {
  final dot = fname.lastIndexOf('.');
  return dot > 0 ? fname.substring(0, dot) : fname;
}

String _where(String type, String fname) => switch (type) {
      'image' => 'Image on this device',
      'video' => 'Video on this device',
      'audio' => 'Audio on this device',
      _ => '${extOf(fname).toUpperCase()} on this device',
    };

/// Brings a picked or shared file into the library and builds an [Item] for it.
/// - HTML files become readable articles.
/// - CBZ / ZIP files of pictures become manga.
/// - Everything else is kept as a file (moved rather than copied when [move] is true,
///   which saves space for big videos picked through the system picker).
Future<Item?> importFile(String srcPath, {String? name, List<String> cols = const [], bool move = false}) async {
  try {
    final src = File(srcPath);
    if (!await src.exists()) return null;
    final fname = name ?? _base(srcPath);
    final id = DateTime.now().microsecondsSinceEpoch;
    final kind = fileKind(fname);

    if (kind == 'html') return await _importHtml(src, fname, id, cols);
    if (kind == 'comic') {
      final c = await _importComic(src, fname, id, cols);
      if (c != null) return c;
      // A ZIP that isn't a comic is kept as an ordinary file.
    }

    final dest = '${(await libDir()).path}/${id}_${_safe(fname)}';
    if (move) {
      try {
        await src.rename(dest);
      } catch (_) {
        await src.copy(dest);
      }
    } else {
      await src.copy(dest);
    }
    final type = fileType(fname);
    return Item(
      id: id,
      title: _title(fname),
      src: _where(type, fname),
      url: 'file:///$id/${_safe(fname)}',
      type: type,
      saved: DateTime.now(),
      cols: List<String>.from(cols),
      path: dest,
    );
  } catch (_) {
    return null;
  }
}

// ---- HTML ---------------------------------------------------------------------

String _plainText(String html) {
  var h = html.replaceAll(RegExp(r'<(script|style|noscript|svg)[\s>].*?</\1>', caseSensitive: false, dotAll: true), ' ');
  h = h.replaceAll(RegExp(r'<!--.*?-->', dotAll: true), ' ');
  h = h.replaceAll(RegExp(r'</(p|div|br|li|h[1-6]|tr|section|article)>|<br\s*/?>', caseSensitive: false), '\n\n');
  h = h.replaceAll(RegExp(r'<[^>]+>'), ' ');
  h = h
      .replaceAll('&nbsp;', ' ')
      .replaceAll('&amp;', '&')
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'");
  return h.replaceAll(RegExp(r'[ \t]+'), ' ');
}

/// Builds a readable article from the text of an HTML page.
Item? articleFromHtml(String html, {required String fallbackTitle, required String src, required int id, List<String> cols = const []}) {
  final r = parseReadable(html);
  var body = r.body;
  if (body == null || body.isEmpty) {
    body = paragraphsOf(_plainText(html)).where((e) => e.length > 1).take(300).toList();
  }
  if (body.isEmpty) return null;
  final words = body.fold<int>(0, (a, p) => a + p.split(' ').length);
  return Item(
    id: id,
    title: (r.title ?? '').trim().isEmpty ? fallbackTitle : r.title!.trim(),
    src: src,
    url: 'file:///$id/${_safe(fallbackTitle)}.html',
    type: 'article',
    saved: DateTime.now(),
    mins: (words / 220).round().clamp(1, 999).toInt(),
    cols: List<String>.from(cols),
    body: body,
  );
}

Future<Item?> _importHtml(File src, String fname, int id, List<String> cols) async {
  final html = utf8.decode(await src.readAsBytes(), allowMalformed: true);
  return articleFromHtml(html, fallbackTitle: _title(fname), src: 'HTML file', id: id, cols: cols);
}

// ---- Typed or pasted text -----------------------------------------------------

/// An article written or pasted by the person. Nothing is fetched.
Item? articleFromText(String title, String text, {List<String> cols = const []}) {
  final body = paragraphsOf(text);
  if (body.isEmpty) return null;
  final id = DateTime.now().microsecondsSinceEpoch;
  final words = body.fold<int>(0, (a, p) => a + p.split(' ').length);
  final t = title.trim().isEmpty ? (body.first.length > 60 ? '${body.first.substring(0, 57)}...' : body.first) : title.trim();
  return Item(
    id: id,
    title: t,
    src: 'Pasted text',
    url: 'text://$id',
    type: 'article',
    saved: DateTime.now(),
    mins: (words / 220).round().clamp(1, 999).toInt(),
    cols: List<String>.from(cols),
    body: body,
  );
}

// ---- CBZ / ZIP comics ----------------------------------------------------------

int _natural(String a, String b) {
  final re = RegExp(r'(\d+)|(\D+)');
  final x = re.allMatches(a.toLowerCase()).map((m) => m.group(0)!).toList();
  final y = re.allMatches(b.toLowerCase()).map((m) => m.group(0)!).toList();
  for (var i = 0; i < x.length && i < y.length; i++) {
    final nx = int.tryParse(x[i]), ny = int.tryParse(y[i]);
    final c = (nx != null && ny != null) ? nx.compareTo(ny) : x[i].compareTo(y[i]);
    if (c != 0) return c;
  }
  return x.length.compareTo(y.length);
}

/// Runs in a background isolate. Returns the page file paths in reading order.
List<String> _unzipPages(String zipPath, String destDir) {
  final bytes = File(zipPath).readAsBytesSync();
  final arc = ZipDecoder().decodeBytes(bytes);
  final files = arc.files.where((f) => f.isFile && kImageExt.contains(extOf(f.name)) && !_base(f.name).startsWith('.')).toList()
    ..sort((a, b) => _natural(a.name, b.name));
  Directory(destDir).createSync(recursive: true);
  final out = <String>[];
  for (var i = 0; i < files.length; i++) {
    final p = '$destDir/${(i + 1).toString().padLeft(4, '0')}.${extOf(files[i].name)}';
    File(p).writeAsBytesSync(files[i].content as List<int>);
    out.add(p);
  }
  return out;
}

Future<Item?> _importComic(File src, String fname, int id, List<String> cols) async {
  final dir = '${(await libDir()).path}/comic_$id';
  final zip = src.path;
  List<String> pages;
  try {
    pages = await Isolate.run(() => _unzipPages(zip, dir));
  } catch (_) {
    pages = const [];
  }
  if (pages.length < 2) {
    try {
      await Directory(dir).delete(recursive: true);
    } catch (_) {}
    return null;
  }
  return Item(
    id: id,
    title: _title(fname),
    src: 'Comic file',
    url: 'file:///$id/${_safe(fname)}',
    type: 'manga',
    saved: DateTime.now(),
    cols: List<String>.from(cols),
    pages: pages,
  );
}

// ---- Downloading direct file links ---------------------------------------------

const _mimeExt = {
  'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'video/x-matroska': 'mkv',
  'audio/mpeg': 'mp3', 'audio/mp4': 'm4a', 'audio/ogg': 'ogg', 'audio/wav': 'wav', 'audio/flac': 'flac', 'audio/aac': 'aac',
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif',
  'application/pdf': 'pdf', 'application/epub+zip': 'epub',
};

/// Downloads a direct file link (mp4, mp3, jpg, pdf and so on) into the library.
/// Returns null when the link is not a plain file, or it is bigger than [kMaxDownload].
Future<Item?> downloadToLibrary(String url, {List<String> cols = const [], void Function(double)? onProgress}) async {
  final client = http.Client();
  try {
    final u = Uri.parse(url);
    final req = http.Request('GET', u)..headers['User-Agent'] = 'Mozilla/5.0 (Android) ClipSot';
    final res = await client.send(req).timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) return null;
    final mime = (res.headers['content-type'] ?? '').split(';').first.trim().toLowerCase();
    if (mime.contains('html')) return null;
    final total = res.contentLength ?? 0;
    if (total > kMaxDownload) return null;

    var name = _base(Uri.decodeComponent(u.path));
    if (extOf(name).isEmpty || !kAllExt.contains(extOf(name))) {
      final e = _mimeExt[mime];
      if (e == null) return null;
      name = '${name.isEmpty ? 'download' : name}.$e';
    }
    final id = DateTime.now().microsecondsSinceEpoch;
    final dest = File('${(await libDir()).path}/${id}_${_safe(name)}');
    final sink = dest.openWrite();
    var got = 0;
    try {
      await for (final chunk in res.stream) {
        got += chunk.length;
        if (got > kMaxDownload) throw const FormatException('too big');
        sink.add(chunk);
        if (total > 0) onProgress?.call(got / total);
      }
      await sink.flush();
      await sink.close();
    } catch (_) {
      try {
        await sink.close();
        await dest.delete();
      } catch (_) {}
      return null;
    }
    final type = fileType(name);
    return Item(
      id: id,
      title: _title(name).replaceAll(RegExp(r'[-_]+'), ' ').trim(),
      src: u.host.startsWith('www.') ? u.host.substring(4) : u.host,
      url: u.toString(),
      type: type,
      saved: DateTime.now(),
      cols: List<String>.from(cols),
      path: dest.path,
    );
  } catch (_) {
    return null;
  } finally {
    client.close();
  }
}

// ---- Cleaning up ---------------------------------------------------------------

Future<void> deleteLocalFile(String path) async {
  try {
    final f = File(path);
    if (await f.exists()) await f.delete();
  } catch (_) {}
}

/// Removes everything ClipSot stored on the device for [it] (the file, or the pages of a CBZ comic).
Future<void> deleteItemFiles(Item it) async {
  if (it.path != null) await deleteLocalFile(it.path!);
  if (it.hasLocalPages) {
    try {
      final d = Directory(File(it.pages!.first).parent.path);
      if (d.path.contains('comic_') && await d.exists()) await d.delete(recursive: true);
    } catch (_) {}
  }
}

Future<String?> readFileBase64(String path, {required int maxBytes}) async {
  try {
    final f = File(path);
    if (!await f.exists() || await f.length() > maxBytes) return null;
    return base64Encode(await f.readAsBytes());
  } catch (_) {
    return null;
  }
}

Future<String?> writeFileFromBase64(String data, String name) async {
  try {
    final dest = '${(await libDir()).path}/${DateTime.now().microsecondsSinceEpoch}_${_safe(name)}';
    await File(dest).writeAsBytes(base64Decode(data));
    return dest;
  } catch (_) {
    return null;
  }
}
