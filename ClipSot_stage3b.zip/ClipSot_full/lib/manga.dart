import 'dart:convert';

import 'package:http/http.dart' as http;

import 'extract.dart';

/// Page images found on a saved manga / comic link.
class MangaResult {
  final String? title;

  /// Page image addresses in reading order. Empty when none were found.
  final List<String> pages;
  const MangaResult({this.title, this.pages = const []});
}

const _ua = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Mobile Safari/537.36';

/// What image servers expect when a page is opened from their own site. Many hosts
/// (Webtoons, most manga CDNs) refuse images that come without the right Referer.
Map<String, String> mangaHeaders(String pageUrl) {
  final u = Uri.tryParse(pageUrl);
  var ref = (u == null || u.host.isEmpty) ? pageUrl : '${u.scheme}://${u.host}/';
  if (u != null && u.host.toLowerCase().endsWith('webtoons.com')) ref = 'https://www.webtoons.com/';
  return {
    'Referer': ref,
    'User-Agent': _ua,
    'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
  };
}
const _maxPages = 400;

/// Looks up the pages of a chapter from the link the person saved.
///
/// - A direct image link is a one-page chapter.
/// - MangaDex chapter links use MangaDex's own public API.
/// - Any other page is read for the images a reader would see on it.
///
/// Only the addresses are kept; no image is downloaded or stored here. Returns
/// null when the page can't be reached.
Future<MangaResult?> fetchManga(String url) async {
  try {
    final u = Uri.parse(url);
    if (u.scheme != 'http' && u.scheme != 'https') return null;
    if (RegExp(r'\.(jpe?g|png|webp|avif)$', caseSensitive: false).hasMatch(u.path)) {
      return MangaResult(pages: [url]);
    }
    final md = RegExp(r'mangadex\.org/(?:[a-z]{2}/)?chapter/([0-9a-fA-F-]{36})').firstMatch(url);
    if (md != null) return await _mangaDex(md.group(1)!);

    final res = await http.get(u, headers: {
      'User-Agent': _ua,
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
    }).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) return null;
    final type = res.headers['content-type'] ?? '';
    if (type.isNotEmpty && !type.contains('html')) return null;
    return parseMangaPages(utf8.decode(res.bodyBytes, allowMalformed: true), u);
  } catch (_) {
    return null;
  }
}

Future<MangaResult?> _mangaDex(String id) async {
  try {
    final srv = await http
        .get(Uri.parse('https://api.mangadex.org/at-home/server/$id'), headers: {'User-Agent': 'ClipSot/0.6'})
        .timeout(const Duration(seconds: 15));
    if (srv.statusCode != 200) return null;
    final j = jsonDecode(srv.body) as Map<String, dynamic>;
    final base = j['baseUrl'] as String?;
    final ch = j['chapter'] as Map<String, dynamic>?;
    final hash = ch?['hash'] as String?;
    final files = (ch?['data'] as List?)?.map((e) => e.toString()).toList();
    if (base == null || hash == null || files == null) return null;
    final pages = [for (final f in files) '$base/data/$hash/$f'];
    return MangaResult(title: await _mangaDexTitle(id), pages: pages);
  } catch (_) {
    return null;
  }
}

Future<String?> _mangaDexTitle(String id) async {
  try {
    final r = await http
        .get(Uri.parse('https://api.mangadex.org/chapter/$id?includes[]=manga'), headers: {'User-Agent': 'ClipSot/0.6'})
        .timeout(const Duration(seconds: 10));
    if (r.statusCode != 200) return null;
    final d = (jsonDecode(r.body) as Map<String, dynamic>)['data'] as Map<String, dynamic>;
    final attrs = (d['attributes'] as Map?) ?? const {};
    String? series;
    for (final rel in (d['relationships'] as List? ?? const [])) {
      if (rel is Map && rel['type'] == 'manga') {
        final t = (rel['attributes'] as Map?)?['title'];
        if (t is Map && t.isNotEmpty) series = (t['en'] ?? t.values.first).toString();
      }
    }
    final chNo = attrs['chapter']?.toString();
    final name = (attrs['title'] ?? '').toString().trim();
    final tail = [if (chNo != null && chNo.isNotEmpty) 'Ch. $chNo', if (name.isNotEmpty) name].join(' · ');
    final out = [if (series != null) series, if (tail.isNotEmpty) tail].join(' – ');
    return out.isEmpty ? null : out;
  } catch (_) {
    return null;
  }
}

String? _attr(String tag, String name) {
  final m = RegExp('(?<![\\w-])$name\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\')', caseSensitive: false).firstMatch(tag);
  final v = (m?.group(1) ?? m?.group(2))?.trim();
  return v == null || v.isEmpty ? null : v;
}

final _junk = RegExp(
  r'(logo|icon|avatar|banner|sprite|emoji|spinner|loading|placeholder|favicon|/ads?[/_-]|button|badge|gravatar|pixel|tracking|bg_transparency|blank\.|1x1)',
  caseSensitive: false,
);

String? _bestSrcset(String? v) {
  if (v == null) return null;
  String? best;
  var bestW = -1.0;
  for (final part in v.split(',')) {
    final bits = part.trim().split(RegExp(r'\s+'));
    if (bits.isEmpty || bits.first.isEmpty) continue;
    final d = bits.length > 1 ? (double.tryParse(bits[1].replaceAll(RegExp(r'[wx]$'), '')) ?? 0.0) : 0.0;
    if (d >= bestW) {
      bestW = d;
      best = bits.first;
    }
  }
  return best;
}

/// Keeps the largest group of images that live in the same folder (a chapter's
/// pages normally do) and caps the count. Public so the in-app browser reuses it.
List<String> pickChapterPages(List<String> found) {
  var pages = found;
  if (found.length >= 4) {
    String dir(String s) {
      final q = s.indexOf('?');
      final clean = q < 0 ? s : s.substring(0, q);
      return clean.substring(0, clean.lastIndexOf('/') + 1);
    }

    final counts = <String, int>{};
    for (final s in found) {
      counts.update(dir(s), (c) => c + 1, ifAbsent: () => 1);
    }
    final best = counts.entries.reduce((a, b) => b.value > a.value ? b : a);
    if (best.value >= 3) pages = found.where((s) => dir(s) == best.key).toList();
  }
  if (pages.length > _maxPages) pages = pages.sublist(0, _maxPages);
  return pages;
}

bool _okImage(Uri u) {
  if (u.scheme != 'http' && u.scheme != 'https') return false;
  final path = u.path.toLowerCase();
  if (path.endsWith('.svg') || path.endsWith('.gif') || path.endsWith('.ico')) return false;
  return !_junk.hasMatch(u.toString());
}

/// True for an address the in-app browser may keep as a page image.
bool isPageImage(String url) {
  final u = Uri.tryParse(url);
  return u != null && _okImage(u);
}

final _jsonImage = RegExp(
  r'https?://[^"\s<>\\)]+?\.(?:jpe?g|png|webp|avif)(?:\?[^"\s<>\\)]*)?',
  caseSensitive: false,
);

/// Pure HTML -> page list. Public so it can be unit tested.
///
/// Reads every <img> (lazy-load attributes, srcset, <noscript> copies), then, when
/// that is not enough, every image address that appears anywhere in the page's
/// scripts and JSON. Drops icons, logos, tiny images and tracking pixels, then keeps
/// the largest group that lives in the same folder.
MangaResult parseMangaPages(String html, Uri base) {
  final title = parseReadable(html, titleOnly: true).title;
  final found = <String>[];
  final seen = <String>{};

  void add(String? raw) {
    if (raw == null) return;
    Uri? u;
    try {
      u = base.resolve(raw.trim().replaceAll('&amp;', '&'));
    } catch (_) {
      return;
    }
    if (!_okImage(u)) return;
    final s = u.toString();
    if (seen.add(s)) found.add(s);
  }

  for (final m in RegExp(r'<img\b[^>]*>', caseSensitive: false, dotAll: true).allMatches(html)) {
    final tag = m.group(0)!;
    final w = int.tryParse(_attr(tag, 'width') ?? '');
    final h = int.tryParse(_attr(tag, 'height') ?? '');
    if ((w != null && w < 120) || (h != null && h < 120)) continue;
    String? src;
    for (final a in const ['data-src', 'data-lazy-src', 'data-original', 'data-url', 'data-lazy', 'data-img', 'data-image']) {
      final v = _attr(tag, a);
      if (v != null && !v.startsWith('data:')) {
        src = v;
        break;
      }
    }
    src ??= _bestSrcset(_attr(tag, 'data-srcset') ?? _attr(tag, 'srcset'));
    if (src == null) {
      final v = _attr(tag, 'src');
      if (v != null && !v.startsWith('data:')) src = v;
    }
    add(src);
    if (found.length >= _maxPages * 2) break;
  }

  var pages = pickChapterPages(found);

  if (pages.length < 3) {
    // Scripts often carry the page list as JSON: ["https:\/\/cdn...\/1.jpg", ...]
    final scripts = StringBuffer();
    for (final m in RegExp(r'<script\b[^>]*>(.*?)</script>', caseSensitive: false, dotAll: true).allMatches(html)) {
      scripts.writeln(m.group(1));
    }
    final raw = scripts.toString().replaceAll(r'\/', '/').replaceAll(r'\u0026', '&').replaceAll('&amp;', '&');
    for (final m in _jsonImage.allMatches(raw)) {
      add(m.group(0));
      if (found.length >= _maxPages * 3) break;
    }
    final more = pickChapterPages(found);
    if (more.length > pages.length) pages = more;
  }
  return MangaResult(title: title, pages: pages);
}
