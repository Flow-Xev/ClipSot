import 'package:flutter/services.dart';

/// Bridge to the Android side (notifications, share sheet, quick tiles, link grabber).
/// Every call is safe on any platform: failures return a neutral default.
class Native {
  static const _ch = MethodChannel('clipsot/native');

  static Future<T?> _call<T>(String m, [Object? args]) async {
    try {
      return await _ch.invokeMethod<T>(m, args);
    } catch (_) {
      return null;
    }
  }

  /// Receives payloads pushed from Android while the screen is already open
  /// (new share, notification tap, tile tap).
  static void listen(void Function(Map<String, dynamic>) onPayload) {
    _ch.setMethodCallHandler((c) async {
      if (c.method == 'payload' && c.arguments is Map) {
        onPayload(Map<String, dynamic>.from(c.arguments as Map));
      }
      return null;
    });
  }

  /// What this screen was launched for: {mode, text, subject, itemId}.
  static Future<Map<String, dynamic>> launch() async {
    final r = await _call<Map>('launch');
    return r == null ? {'mode': 'none'} : Map<String, dynamic>.from(r);
  }

  // ---- haptics ---------------------------------------------------------------
  /// Plays a haptic on the phone's motor. Returns false when the phone (or
  /// platform) can't, so the caller can fall back to Flutter's HapticFeedback.
  static Future<bool> haptic(String kind, double amp) async =>
      (await _call<bool>('haptic', {'kind': kind, 'amp': amp})) ?? false;

  // ---- permissions ---------------------------------------------------------
  static Future<bool> notifGranted() async => (await _call<bool>('notifStatus')) ?? false;
  static Future<bool> requestNotif() async => (await _call<bool>('requestNotif')) ?? false;
  static Future<void> openNotifSettings() => _call<void>('openNotifSettings');
  // ---- link grabber (accessibility) ------------------------------------------
  static Future<bool> a11yEnabled() async => (await _call<bool>('a11yStatus')) ?? false;
  static Future<void> openA11ySettings() => _call<void>('openA11ySettings');

  // ---- reminders -----------------------------------------------------------
  static Future<void> scheduleReminder({
    required int id,
    required DateTime at,
    required String title,
    required String src,
  }) =>
      _call<void>('scheduleReminder', {
        'id': id,
        'at': at.millisecondsSinceEpoch,
        'title': title,
        'src': src,
      });

  static Future<void> cancelReminder(int id) => _call<void>('cancelReminder', {'id': id});
  static Future<void> cancelAllReminders() => _call<void>('cancelAllReminders');
  static Future<void> scheduleRediscovery(String freq) =>
      _call<void>('scheduleRediscovery', {'freq': freq});
  static Future<void> cancelRediscovery() => _call<void>('cancelRediscovery');
  static Future<void> testNotification() => _call<void>('testNotification');

  // ---- quick tiles ---------------------------------------------------------
  /// 'added' | 'already' | 'dismissed' | 'unsupported'
  static Future<String> requestTile(String which) async =>
      (await _call<String>('requestTile', {'which': which})) ?? 'unsupported';

  // ---- navigation ----------------------------------------------------------
  static Future<void> openMain({int? itemId}) => _call<void>('openMain', {'itemId': itemId});
  static Future<void> finish() => _call<void>('finish');
}
