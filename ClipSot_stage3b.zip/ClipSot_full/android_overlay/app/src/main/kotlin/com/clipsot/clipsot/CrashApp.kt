package com.clipsot.clipsot

import android.app.ActivityManager
import android.app.Application
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Starts before anything else (even before ad/plugin content providers). It records why the
 * app died and saves it as Downloads/ClipSot_crash_report.txt so it can be read on the phone
 * itself, without a computer.
 */
class CrashApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        CrashReport.install(base)
    }
}

object CrashReport {
    private const val NAME = "ClipSot_crash_report.txt"

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    fun install(ctx: Context) {
        try {
            saveExits(ctx)
            publish(ctx)
        } catch (_: Throwable) {
        }
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(ctx.filesDir, "java_crash.txt").writeText("Time: ${now()}\nThread: ${t.name}\n\n$sw")
                publish(ctx)
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    private fun readOrEmpty(f: File): String = try { if (f.exists()) f.readText() else "" } catch (_: Throwable) { "" }

    private fun reasonName(r: Int) = when (r) {
        1 -> "EXIT_SELF"; 2 -> "SIGNALED"; 3 -> "LOW_MEMORY"; 4 -> "CRASH (Java)"
        5 -> "CRASH_NATIVE"; 6 -> "ANR"; 7 -> "INITIALIZATION_FAILURE"; 8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"; 10 -> "USER_REQUESTED"; 11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"; 13 -> "OTHER"; else -> "UNKNOWN($r)"
    }

    /** What Android says about how the previous runs of this app ended (Android 11+). */
    private fun saveExits(ctx: Context) {
        val out = File(ctx.filesDir, "exits.txt")
        if (Build.VERSION.SDK_INT < 30) {
            out.writeText("(exit reasons need Android 11 or newer)")
            return
        }
        val am = ctx.getSystemService(ActivityManager::class.java) ?: return
        val sb = StringBuilder()
        for (i in am.getHistoricalProcessExitReasons(ctx.packageName, 0, 6)) {
            sb.append("- ").append(SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date(i.timestamp)))
                .append("  ").append(reasonName(i.reason))
                .append("  process=").append(i.processName)
                .append("  status=").append(i.status)
                .append("  ").append(i.description ?: "").append('\n')
            if (i.reason == 4 || i.reason == 5) {
                try {
                    val raw = i.traceInputStream?.use { it.readBytes() }
                    if (raw != null && raw.isNotEmpty()) {
                        val txt = String(raw, Charsets.ISO_8859_1)
                            .replace(Regex("[^\\x20-\\x7E\\n]+"), " ")
                            .trim()
                        sb.append("  trace: ").append(txt.take(3000)).append('\n')
                    }
                } catch (_: Throwable) {
                }
            }
        }
        out.writeText(sb.toString())
    }

    private fun publish(ctx: Context) {
        val java = readOrEmpty(File(ctx.filesDir, "java_crash.txt"))
        val exits = readOrEmpty(File(ctx.filesDir, "exits.txt"))
        val text = buildString {
            append("ClipSot crash report\n")
            append("Written: ").append(now()).append('\n')
            append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(", Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n\n")
            append("== Last Java crash ==\n").append(if (java.isEmpty()) "(none recorded)\n" else java).append("\n\n")
            append("== How earlier runs ended (Android's own record) ==\n").append(if (exits.isEmpty()) "(none)\n" else exits)
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val res = ctx.contentResolver
            val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            var found: Uri? = null
            res.query(
                coll, arrayOf(MediaStore.Downloads._ID),
                "${MediaStore.Downloads.DISPLAY_NAME}=?", arrayOf(NAME), null
            )?.use { c -> if (c.moveToFirst()) found = ContentUris.withAppendedId(coll, c.getLong(0)) }
            val target = found ?: res.insert(coll, ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, NAME)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/")
            })
            if (target != null) res.openOutputStream(target, "wt")?.use { it.write(text.toByteArray()) }
        } else {
            ctx.getExternalFilesDir(null)?.let { File(it, NAME).writeText(text) }
        }
    }
}
