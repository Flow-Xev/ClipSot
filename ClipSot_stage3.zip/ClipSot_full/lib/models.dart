import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart' show Icons;

class Item {
  final int id;
  String title;
  String src;
  String url;

  /// article | video | image | document | note
  String type;
  String note;
  DateTime saved;
  int mins;
  bool read;
  List<String> cols;

  /// When ClipSot should remind the person about this item (null = none).
  DateTime? remind;

  /// Reading position 0..1 (powers "Continue reading").
  double progress;

  /// When the item was last opened (ms since epoch, 0 = never).
  int opened;

  /// Local copy for saved images and documents (null for links).
  String? path;

  /// Extracted readable text. Paragraphs starting with "Q:" render as pull quotes.
  /// Null when no readable text is stored (reader then offers the original site).
  List<String>? body;

  /// Manga / comic: the page image addresses found on the saved link, in reading
  /// order. Only the addresses are stored; the images are loaded from their own
  /// site when the person reads (nothing is copied to the device).
  List<String>? pages;

  /// When this item was moved to the Trash (ms since epoch, 0 = not in the Trash).
  int trashed = 0;

  Item({
    required this.id,
    required this.title,
    required this.src,
    required this.url,
    required this.type,
    required this.saved,
    this.mins = 0,
    this.read = false,
    List<String>? cols,
    this.note = '',
    this.body,
    this.remind,
    this.progress = 0,
    this.opened = 0,
    this.path,
    this.pages,
    this.trashed = 0,
  }) : cols = cols ?? [];

  int get daysAgo => DateTime.now().difference(saved).inDays;

  String get savedLabel {
    final d = daysAgo;
    if (d <= 0) return 'Saved today';
    if (d == 1) return 'Saved yesterday';
    return 'Saved $d days ago';
  }

  bool get isVideo => type == 'video';
  bool get isFile => path != null;
  bool get isImage => type == 'image';
  bool get isManga => type == 'manga';

  /// Days left before the Trash removes this for good.
  int get trashDaysLeft {
    final gone = DateTime.fromMillisecondsSinceEpoch(trashed).add(const Duration(days: kTrashDays));
    return gone.difference(DateTime.now()).inDays.clamp(0, kTrashDays).toInt();
  }

  /// Short line used under titles on cards.
  String get metaShort {
    if (isVideo) return mins > 0 ? '$mins min' : 'Video';
    if (isManga) return (pages?.length ?? 0) > 0 ? '${pages!.length} pages' : 'Manga';
    return mins > 0 ? '$mins min read' : src;
  }

  bool get hasReminder => remind != null && remind!.isAfter(DateTime.now());

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'src': src,
        'url': url,
        'type': type,
        'note': note,
        'saved': saved.millisecondsSinceEpoch,
        'mins': mins,
        'read': read,
        'cols': cols,
        'body': body,
        'remind': remind?.millisecondsSinceEpoch,
        'progress': progress,
        'opened': opened,
        'path': path,
        'pages': pages,
        'trashed': trashed,
      };

  factory Item.fromJson(Map<String, dynamic> j) => Item(
        id: (j['id'] as num).toInt(),
        title: (j['title'] ?? '') as String,
        src: (j['src'] ?? '') as String,
        url: (j['url'] ?? '') as String,
        type: (j['type'] ?? 'article') as String,
        note: (j['note'] ?? '') as String,
        saved: DateTime.fromMillisecondsSinceEpoch((j['saved'] as num).toInt()),
        mins: ((j['mins'] ?? 0) as num).toInt(),
        read: (j['read'] ?? false) as bool,
        cols: ((j['cols'] as List?) ?? []).map((e) => e.toString()).toList(),
        body: (j['body'] as List?)?.map((e) => e.toString()).toList(),
        remind: j['remind'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch((j['remind'] as num).toInt()),
        progress: ((j['progress'] ?? 0) as num).toDouble(),
        opened: ((j['opened'] ?? 0) as num).toInt(),
        path: j['path'] as String?,
        pages: (j['pages'] as List?)?.map((e) => e.toString()).toList(),
        trashed: ((j['trashed'] ?? 0) as num).toInt(),
      );

  /// Builds an item from a pasted/shared link. Returns null for invalid input.
  /// Only the URL itself is used - no network access happens here.
  ///
  /// [manga] forces the type: true = manga, false = never manga, null = guess
  /// from the address (the person can always change it).
  static Item? fromUrl(String raw, String note, List<String> cols, {bool? manga}) {
    final t = raw.trim();
    if (t.isEmpty || t.contains(RegExp(r'\s'))) return null;
    final hasScheme = RegExp(r'^https?://', caseSensitive: false).hasMatch(t);
    final u = Uri.tryParse(hasScheme ? t : 'https://$t');
    if (u == null || u.host.isEmpty || !u.host.contains('.')) return null;

    var host = u.host.toLowerCase();
    if (host.startsWith('www.')) host = host.substring(4);
    final vid = RegExp(r'youtube|youtu\.be|vimeo').hasMatch(host);
    final pdf = u.path.toLowerCase().endsWith('.pdf');

    final segs = u.pathSegments.where((s) => s.isNotEmpty).toList();
    var slug = '';
    if (segs.isNotEmpty) {
      try {
        slug = Uri.decodeComponent(segs.last);
      } catch (_) {
        slug = segs.last;
      }
      slug = slug.replaceAll(RegExp(r'[-_]'), ' ').replaceAll(RegExp(r'\.\w+$'), '').trim();
    }
    if (vid && slug.toLowerCase() == 'watch') slug = '';
    final title = slug.isEmpty ? host : slug[0].toUpperCase() + slug.substring(1);

    return Item(
      id: DateTime.now().microsecondsSinceEpoch,
      title: title,
      src: host,
      url: u.toString(),
      type: vid ? 'video' : (pdf ? 'document' : ((manga ?? looksLikeManga(u)) ? 'manga' : 'article')),
      saved: DateTime.now(),
      mins: 0,
      cols: List<String>.from(cols),
      note: note.trim(),
    );
  }
}

/// Days the Trash keeps things before removing them for good.
const kTrashDays = 30;

final _mangaHost = RegExp(r'mangadex|webtoon|manga|manhwa|manhua|comick|tapas\.io|mangaplus');
final _mangaPath = RegExp(r'/(manga|manhwa|manhua|webtoons?|comics?|chapter)[/\-_]', caseSensitive: false);
final _imageExt = RegExp(r'\.(jpe?g|png|webp|avif)$', caseSensitive: false);

/// A best guess at whether a link is a manga / comic chapter. Only looks at the
/// address; the person can flip it when saving.
bool looksLikeManga(Uri u) {
  final host = u.host.toLowerCase();
  final path = '${u.path.toLowerCase()}/';
  return _mangaHost.hasMatch(host) || _mangaPath.hasMatch(path) || _imageExt.hasMatch(u.path);
}

const kFilters = ['All', 'Unread', 'Articles', 'Manga', 'Videos', 'Images', 'Documents', 'Notes'];
const kFilterType = {
  'Articles': 'article',
  'Manga': 'manga',
  'Videos': 'video',
  'Images': 'image',
  'Documents': 'document',
  'Notes': 'note',
};
const kDefaultCols = ['Reading List', 'Watch Later', 'Inspiration', 'Research', 'Favorites'];

class Note {
  final int id;
  String title;
  String text;
  List<String> tags;

  /// Optional link to a saved item.
  int? itemId;
  DateTime updated;

  /// When this note was moved to the Trash (ms since epoch, 0 = not in the Trash).
  int trashed = 0;

  Note({
    required this.id,
    this.title = '',
    this.text = '',
    List<String>? tags,
    this.itemId,
    DateTime? updated,
    this.trashed = 0,
  })  : tags = tags ?? [],
        updated = updated ?? DateTime.now();

  bool get isEmpty => title.trim().isEmpty && text.trim().isEmpty;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'text': text,
        'tags': tags,
        'itemId': itemId,
        'updated': updated.millisecondsSinceEpoch,
        'trashed': trashed,
      };

  int get trashDaysLeft {
    final gone = DateTime.fromMillisecondsSinceEpoch(trashed).add(const Duration(days: kTrashDays));
    return gone.difference(DateTime.now()).inDays.clamp(0, kTrashDays).toInt();
  }

  factory Note.fromJson(Map<String, dynamic> j) => Note(
        id: (j['id'] as num).toInt(),
        title: (j['title'] ?? '') as String,
        text: (j['text'] ?? '') as String,
        tags: ((j['tags'] as List?) ?? []).map((e) => e.toString()).toList(),
        itemId: (j['itemId'] as num?)?.toInt(),
        updated: DateTime.fromMillisecondsSinceEpoch(((j['updated'] ?? 0) as num).toInt()),
        trashed: ((j['trashed'] ?? 0) as num).toInt(),
      );
}

/// Curated icon set for collections.
const kIcons = <IconData>[
  Icons.folder_outlined,
  Icons.bookmark_border,
  Icons.play_circle_outline,
  Icons.lightbulb_outline,
  Icons.science_outlined,
  Icons.star_border,
  Icons.restaurant_outlined,
  Icons.movie_outlined,
  Icons.school_outlined,
  Icons.code,
  Icons.palette_outlined,
  Icons.flight_outlined,
  Icons.work_outline,
  Icons.favorite_border,
  Icons.music_note_outlined,
  Icons.shopping_bag_outlined,
];

const kDefaultIcon = {
  'Reading List': 1,
  'Watch Later': 2,
  'Inspiration': 3,
  'Research': 4,
  'Favorites': 5,
};

const kLockedCols = ['All Items', ...kDefaultCols];
