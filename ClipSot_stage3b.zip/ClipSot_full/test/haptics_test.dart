import 'package:clipsot/haptics.dart';
import 'package:clipsot/models.dart';
import 'package:clipsot/widgets/peel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('haptic level names map to levels, unknown falls back to Medium', () {
    expect(hapticLevelFrom('Off'), HapticLevel.off);
    expect(hapticLevelFrom('soft'), HapticLevel.soft);
    expect(hapticLevelFrom('STRONG'), HapticLevel.strong);
    expect(hapticLevelFrom('nonsense'), HapticLevel.medium);
    expect(hapticLevelFrom(null), HapticLevel.medium);
  });

  test('turning haptics off never throws', () {
    Haptics.level = HapticLevel.off;
    expect(Haptics.enabled, isFalse);
    Haptics.tap();
    Haptics.peel();
    Haptics.thud();
    Haptics.scrollTick(3);
    Haptics.level = HapticLevel.medium;
  });

  group('Read as article / manga', () {
    test('the picker overrides the guess from the link', () {
      const url = 'https://example.com/post/hello';
      expect(Item.fromUrl(url, '', [])!.type, 'article');
      expect(Item.fromUrl(url, '', [], manga: true)!.type, 'manga');
      const mangaUrl = 'https://mangadex.org/chapter/abc';
      expect(Item.fromUrl(mangaUrl, '', [])!.type, 'manga');
      expect(Item.fromUrl(mangaUrl, '', [], manga: false)!.type, 'article');
    });

    test('videos and PDFs ignore the manga switch', () {
      expect(Item.fromUrl('https://youtu.be/abc', '', [], manga: true)!.type, 'video');
      expect(Item.fromUrl('https://x.org/a.pdf', '', [], manga: true)!.type, 'document');
    });
  });

  testWidgets('a peel row is found, and skips the animation when motion is reduced', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(disableAnimations: true),
          child: const Scaffold(body: PeelItem(id: 7, child: SizedBox(height: 60, child: Text('row')))),
        ),
      ),
    );
    await tester.pump();
    final row = PeelRegistry.of(7);
    expect(row, isNotNull);
    expect(await row!.peel(), isFalse);
    expect(find.text('row'), findsOneWidget);
  });
}
