import 'dart:math';

/// A two-part editorial headline: [lead] in the main colour, [tail] dimmed.
class Headline {
  final String id;
  final String lead;
  final String tail;
  const Headline(this.id, this.lead, this.tail);
}

class _Ctx {
  final DateTime now;
  final int total, unread, forgotten, inProgress;
  const _Ctx(this.now, this.total, this.unread, this.forgotten, this.inProgress);
  int get hour => now.hour;
  bool get weekend => now.weekday == DateTime.saturday || now.weekday == DateTime.sunday;
}

class _Line {
  final String id;
  final String Function(_Ctx) lead;
  final String Function(_Ctx) tail;
  final bool Function(_Ctx) when;
  final int weight;
  const _Line(this.id, this.lead, this.tail, this.when, this.weight);
}

bool _hasItems(_Ctx c) => c.total > 0;

_Line _g(String id, String lead, String tail) =>
    _Line(id, (_) => lead, (_) => tail, _hasItems, 1);

_Line _w(String id, String lead, String tail, bool Function(_Ctx) when, [int weight = 3]) =>
    _Line(id, (_) => lead, (_) => tail, when, weight);

final List<_Line> _lines = [
  // ---- evergreen -----------------------------------------------------------
  _g('mind', 'Your mind,', 'without the clutter.'),
  _g('savefind', 'Save now.', 'Find anytime.'),
  _g('meant', 'Everything you meant', 'to come back to.'),
  _g('vanish', 'Read it', 'before it disappears.'),
  _g('small', 'Small saves,', 'big ideas later.'),
  _g('curious', 'Curiosity', 'deserves a home.'),
  _g('future', 'Future you', 'will say thanks.'),
  _g('keep', 'Found something good?', 'Keep it close.'),
  _g('room', 'Make room', 'for what matters.'),
  _g('quiet', 'A quieter kind', 'of library.'),
  _g('wander', 'Collect now.', 'Wander later.'),
  _g('keeping', 'Less scrolling.', 'More keeping.'),
  _g('golinks', 'Where good links', 'go to be read.'),
  _g('slowlook', 'Take a slow look', 'at what you saved.'),
  _g('tab', 'The best tab', 'is no tab at all.'),

  // ---- time of day ---------------------------------------------------------
  _w('am1', 'Good morning.', 'Something good to read?', (c) => c.total > 0 && c.hour >= 5 && c.hour < 12),
  _w('am2', 'Start slow.', 'Pick one thing to read.', (c) => c.total > 0 && c.hour >= 5 && c.hour < 12),
  _w('pm1', 'Afternoon break?', 'Read something small.', (c) => c.total > 0 && c.hour >= 12 && c.hour < 17),
  _w('eve1', 'Good evening.', 'Time to unwind and read.', (c) => c.total > 0 && c.hour >= 17 && c.hour < 22),
  _w('late1', 'Still up?', 'Save it for tomorrow.', (c) => c.total > 0 && (c.hour >= 22 || c.hour < 5)),
  _w('late2', 'Night reading.', 'Quiet hours, good links.', (c) => c.total > 0 && (c.hour >= 22 || c.hour < 5)),
  _w('wknd', 'Slow weekend.', 'Plenty to catch up on.', (c) => c.total > 0 && c.weekend),

  // ---- what is actually in the library --------------------------------------
  _Line(
    'unread',
    (c) => c.unread == 1 ? 'One thing' : '${c.unread} things',
    (c) => c.unread == 1 ? 'is waiting for you.' : 'are waiting for you.',
    (c) => c.unread >= 1 && c.unread < 10,
    3,
  ),
  _w('stack', 'A big stack.', 'Pick just one today.', (c) => c.unread >= 10),
  _w('forgot1', 'Remember this?', 'Some saves are waiting.', (c) => c.forgotten >= 1),
  _w('forgot2', 'Dust off', 'a forgotten find.', (c) => c.forgotten >= 1),
  _w('progress', 'Pick up', 'where you left off.', (c) => c.inProgress >= 1, 4),
  _w('growing', 'Your library', 'is growing nicely.', (c) => c.total >= 50, 2),

  // ---- empty library ----------------------------------------------------------
  _w('empty1', 'A clean slate.', 'Save your first link.', (c) => c.total == 0, 1),
  _w('empty2', 'Start your library', 'one link at a time.', (c) => c.total == 0, 1),
  _w('empty3', 'Nothing saved yet.', 'That changes today.', (c) => c.total == 0, 1),
];

/// Picks a headline for this visit. Never repeats [lastId], and favours lines that
/// match the time of day and what is actually in the library.
Headline pickHeadline({
  required Random rng,
  required DateTime now,
  required int total,
  required int unread,
  required int forgotten,
  required int inProgress,
  String? lastId,
}) {
  final c = _Ctx(now, total, unread, forgotten, inProgress);
  var pool = _lines.where((l) => l.when(c) && l.id != lastId).toList();
  if (pool.isEmpty) pool = _lines.where((l) => l.when(c)).toList();
  if (pool.isEmpty) pool = [_lines.first];

  final sum = pool.fold<int>(0, (a, l) => a + l.weight);
  var roll = rng.nextInt(sum);
  var pick = pool.last;
  for (final l in pool) {
    if (roll < l.weight) {
      pick = l;
      break;
    }
    roll -= l.weight;
  }
  return Headline(pick.id, pick.lead(c), pick.tail(c));
}

/// Number of distinct lines (used by tests).
int get headlineCount => _lines.length;
