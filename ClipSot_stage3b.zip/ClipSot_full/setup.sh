#!/usr/bin/env bash
# One-time Android setup for ClipSot. Run from the clipsot/ folder.
set -e
if [ ! -d android ]; then
  flutter create . --org com.clipsot --project-name clipsot --platforms android
fi
# The default template test does not match ClipSot; remove it.
rm -f test/widget_test.dart
# Copy the ClipSot native layer (manifest, Kotlin, notification layouts, tiles).
cp -R android_overlay/app/. android/app/
# Notification channels, tiles and the overlay need Android 8.0+.
for f in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$f" ] && sed -i.bak 's/flutter\.minSdkVersion/26/' "$f" && rm -f "$f.bak"
done
# Plugins such as file_picker still compile against old Android APIs, but newer AndroidX
# libraries need compileSdk 36+. Raise it for every plugin module (the app itself is fine).
python3 - <<'PY'
from pathlib import Path
kts = Path("android/build.gradle.kts")
groovy = Path("android/build.gradle")
MARK = "clipsot-compilesdk-fix"
kts_code = """
// clipsot-compilesdk-fix
subprojects {
    val raiseSdk: Project.() -> Unit = {
        val ext = extensions.findByName("android")
        if (ext != null && name != "app") {
            val setters = listOf("setCompileSdk" to Int::class.javaObjectType, "setCompileSdkVersion" to Int::class.javaPrimitiveType!!)
            for ((m, t) in setters) {
                try { ext.javaClass.getMethod(m, t).invoke(ext, 36); break } catch (e: Exception) { }
            }
        }
    }
    if (state.executed) raiseSdk() else afterEvaluate { raiseSdk() }
}
"""
groovy_code = """
// clipsot-compilesdk-fix
subprojects {
    def raise = { p ->
        if (p.name != 'app' && p.extensions.findByName('android') != null) {
            p.android.compileSdkVersion 36
        }
    }
    if (project.state.executed) { raise(project) } else { afterEvaluate { raise(it) } }
}
"""
for f, code in ((kts, kts_code), (groovy, groovy_code)):
    if f.exists():
        t = f.read_text()
        if MARK not in t:
            f.write_text(t + code)
        print("compileSdk fix applied to", f)
        break
PY
flutter pub get
echo "Done. Run: flutter run"
