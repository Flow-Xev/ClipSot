package com.clipsot.clipsot

import android.Manifest
import android.annotation.TargetApi
import android.app.Activity
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.MimeTypeMap
import java.io.File
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/** Method channel shared by MainActivity and PanelActivity ("clipsot/native"). */
class Bridge(private val act: Activity, engine: FlutterEngine, private val panel: Boolean) {
    private val ch = MethodChannel(engine.dartExecutor.binaryMessenger, "clipsot/native")

    init {
        ch.setMethodCallHandler { call, res ->
            try {
                handle(call, res)
            } catch (e: Exception) {
                res.error("native", e.message, null)
            }
        }
    }

    fun push(i: Intent) = ch.invokeMethod("payload", payload(i))

    private fun payload(i: Intent?): Map<String, Any?> {
        val m = HashMap<String, Any?>()
        m["panel"] = panel
        when {
            i == null -> m["mode"] = "none"
            i.action == Intent.ACTION_SEND -> {
                val stream = streamOf(i)
                val copy = if (stream != null) copyShared(stream) else null
                if (copy != null) {
                    m["mode"] = "file"
                    m["file"] = copy["path"]
                    m["fileName"] = copy["name"]
                } else {
                    m["mode"] = "share"
                    m["text"] = i.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                    m["subject"] = i.getStringExtra(Intent.EXTRA_SUBJECT)
                }
            }
            i.action == Intent.ACTION_PROCESS_TEXT -> {
                m["mode"] = "share"
                m["text"] = i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            }
            i.hasExtra("mode") -> m["mode"] = i.getStringExtra("mode")
            else -> m["mode"] = if (panel) "clipboard" else "main"
        }
        if (i != null && i.hasExtra("item_id")) m["itemId"] = i.getLongExtra("item_id", 0L)
        return m
    }

    @Suppress("DEPRECATION")
    private fun streamOf(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)

    /** Copies a shared image/PDF into the cache so Flutter can read it as a normal file. */
    private fun copyShared(uri: Uri): Map<String, String>? = try {
        var name = "shared"
        act.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        if (!name.contains('.')) {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(act.contentResolver.getType(uri))?.let { name += ".$it" }
        }
        val dir = File(act.cacheDir, "incoming").apply { mkdirs() }
        val out = File(dir, "${System.currentTimeMillis()}_$name")
        act.contentResolver.openInputStream(uri)?.use { inp -> out.outputStream().use { inp.copyTo(it) } }
        mapOf("path" to out.absolutePath, "name" to name)
    } catch (e: Exception) {
        null
    }

    private fun long(call: MethodCall, key: String): Long = (call.argument<Number>(key) ?: 0).toLong()

    private fun handle(call: MethodCall, res: MethodChannel.Result) {
        when (call.method) {
            "launch" -> {
                val p = payload(act.intent)
                if (!panel) act.intent?.removeExtra("item_id") // consume once
                res.success(p)
            }
            "notifStatus" -> res.success(Notifs.canPost(act))
            "requestNotif" -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                    act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
                    res.success(false)
                } else res.success(Notifs.canPost(act))
            }
            "openNotifSettings" -> {
                act.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)
                )
                res.success(null)
            }
            "overlayStatus" -> res.success(Settings.canDrawOverlays(act))
            "openOverlaySettings" -> {
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${act.packageName}"))
                )
                res.success(null)
            }
            "setHandle" -> {
                val on = call.argument<Boolean>("on") == true
                res.success(OverlayService.set(act, on))
            }
            "scheduleReminder" -> {
                Reminders.schedule(
                    act, long(call, "id"), long(call, "at"),
                    call.argument<String>("title") ?: "", call.argument<String>("src") ?: ""
                )
                res.success(null)
            }
            "cancelReminder" -> { Reminders.cancel(act, long(call, "id")); res.success(null) }
            "cancelAllReminders" -> { Reminders.cancelAll(act); res.success(null) }
            "scheduleRediscovery" -> {
                Reminders.scheduleRediscovery(act, call.argument<String>("freq") ?: "Weekly")
                res.success(null)
            }
            "cancelRediscovery" -> { Reminders.cancelRediscovery(act); res.success(null) }
            "testNotification" -> {
                Notifs.show(
                    act, Reminders.TEST_ID, "A quieter way to design",
                    "designnotes.co", "Saved 12 days ago, still unread"
                )
                res.success(null)
            }
            "requestTile" -> {
                if (Build.VERSION.SDK_INT >= 33) addTile(call.argument<String>("which"), res)
                else res.success("unsupported")
            }
            "openMain" -> {
                val i = Intent(act, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                call.argument<Number>("itemId")?.let { i.putExtra("item_id", it.toLong()) }
                act.startActivity(i)
                if (panel) act.finish()
                res.success(null)
            }
            "finish" -> { act.finish(); res.success(null) }
            else -> res.notImplemented()
        }
    }

    @TargetApi(33)
    private fun addTile(which: String?, res: MethodChannel.Result) {
        val surprise = which == "surprise"
        val cls = if (surprise) SurpriseTileService::class.java else SaveTileService::class.java
        val label = if (surprise) "Surprise me" else "Save link"
        val icon = Icon.createWithResource(act, if (surprise) R.drawable.ic_tile_surprise else R.drawable.ic_tile_save)
        val sbm = act.getSystemService(StatusBarManager::class.java)
        sbm.requestAddTileService(ComponentName(act, cls), label, icon, act.mainExecutor) { code ->
            res.success(
                when (code) {
                    StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED -> "added"
                    StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED -> "already"
                    else -> "dismissed"
                }
            )
        }
    }
}
