import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'sheets.dart';

class _HeroClip extends CustomClipper<Path> {
  @override
  Path getClip(Size s) => Path()
    ..lineTo(s.width, 0)
    ..lineTo(s.width, s.height * 0.8)
    ..lineTo(0, s.height)
    ..close();

  @override
  bool shouldReclip(covariant CustomClipper<Path> old) => false;
}

class ReaderScreen extends StatefulWidget {
  final int id;
  const ReaderScreen({super.key, required this.id});

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  final _scroll = ScrollController();
  final _progress = ValueNotifier<double>(0);

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (!_scroll.hasClients) return;
      final max = _scroll.position.maxScrollExtent;
      _progress.value = max <= 0 ? 0 : (_scroll.offset / max).clamp(0.0, 1.0);
    });
  }

  @override
  void dispose() {
    _scroll.dispose();
    _progress.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final it = store.byId(widget.id);
    if (it == null) return Scaffold(backgroundColor: p.bg);

    final dk = store.readerDark;
    final paperBg = dk ? const Color(0xFF161616) : kSheetBg;
    final paperFg = dk ? const Color(0xFFE8E6E1) : const Color(0xFF171717);
    final fav = it.cols.contains('Favorites');

    final body = it.body;
    final paragraphs = <Widget>[];
    if (body != null) {
      for (final t in body) {
        if (t.startsWith('Q:')) {
          paragraphs.add(Container(
            margin: const EdgeInsets.symmetric(vertical: 24),
            padding: const EdgeInsets.only(left: 16),
            decoration: BoxDecoration(border: Border(left: BorderSide(color: p.ac, width: 3))),
            child: Text(t.substring(2), style: ts(19, color: paperFg, h: 1.3)),
          ));
        } else {
          paragraphs.add(Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: SelectableText(
              t,
              style: ts(store.fontSize, color: paperFg, h: store.lineHeight),
            ),
          ));
        }
      }
    } else {
      paragraphs.add(Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Text(
          'Reader view isn’t available for this link yet. You can open the original page instead.',
          style: ts(store.fontSize, color: paperFg, h: store.lineHeight),
        ),
      ));
    }

    final kind = it.type == 'document' ? 'Document' : (it.type == 'image' ? 'Image' : 'Article');

    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.pop(context)),
                  Row(children: [
                    RoundIcon(
                      fav ? Icons.bookmark : Icons.bookmark_border,
                      label: fav ? 'Remove bookmark' : 'Bookmark',
                      color: fav ? p.ac : null,
                      onTap: () {
                        final now = store.toggleCol(it, 'Favorites');
                        toast(context, now ? 'Added to Favorites' : 'Removed from Favorites');
                      },
                    ),
                    RoundIcon(Icons.more_vert, label: 'More',
                        onTap: () => showItemActions(context, it.id,
                            onDeleted: () => Navigator.of(context).maybePop())),
                  ]),
                ],
              ),
            ),
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                        child: Container(
                          color: paperBg,
                          child: SingleChildScrollView(
                            controller: _scroll,
                            padding: const EdgeInsets.only(bottom: 110),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipPath(
                                  clipper: _HeroClip(),
                                  child: Container(
                                    height: 190,
                                    decoration: const BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [Color(0xFF8A8A86), Color(0xFF1F1F1F)],
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(24, 22, 24, 0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '${kind.toUpperCase()}${it.mins > 0 ? ' · ${it.mins} MIN READ' : ''} · ${it.src.toUpperCase()}',
                                        style: ts(12, color: alpha(paperFg, .6), ls: .3),
                                      ),
                                      const SizedBox(height: 10),
                                      Text(it.title, style: ts(34, w: FontWeight.w500, ls: -1.2, h: 1.05, color: paperFg)),
                                      const SizedBox(height: 20),
                                      ...paragraphs,
                                      const SizedBox(height: 8),
                                      Tap(
                                        onTap: () => openExternal(context, it.url),
                                        label: 'Open original site',
                                        child: Container(
                                          height: 50,
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            color: alpha(paperFg, .08),
                                            borderRadius: BorderRadius.circular(26),
                                          ),
                                          child: Text('Open original site',
                                              style: ts(16, w: FontWeight.w500, color: paperFg)),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Reading progress
                  Positioned(
                    top: 0,
                    left: 12,
                    right: 12,
                    child: ValueListenableBuilder<double>(
                      valueListenable: _progress,
                      builder: (_, v, __) => Align(
                        alignment: Alignment.centerLeft,
                        child: FractionallySizedBox(
                          widthFactor: v,
                          child: Container(height: 3, color: p.ac),
                        ),
                      ),
                    ),
                  ),
                  // Reading controls
                  Positioned(
                    left: 28,
                    right: 28,
                    bottom: 20 + MediaQuery.of(context).padding.bottom,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF171717),
                        borderRadius: BorderRadius.circular(28),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _Ctl(label: 'Text size', child: Text('Aa', style: ts(16, color: const Color(0xFFF4F3F0))),
                              onTap: () => store.setReader(fs: store.fontSize >= 26 ? 15 : store.fontSize + 2)),
                          _Ctl(label: 'Line spacing',
                              child: const Icon(Icons.format_line_spacing, size: 22, color: Color(0xFFF4F3F0)),
                              onTap: () => store.setReader(
                                  ls: store.lineHeight >= 2.0 ? 1.4 : double.parse((store.lineHeight + .2).toStringAsFixed(1)))),
                          _Ctl(label: 'Reading theme',
                              child: Icon(dk ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
                                  size: 22, color: const Color(0xFFF4F3F0)),
                              onTap: () => store.setReader(dark: !dk)),
                          _Ctl(label: 'Share',
                              child: const Icon(Icons.ios_share, size: 22, color: Color(0xFFF4F3F0)),
                              onTap: () => Share.share(it.url)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Ctl extends StatelessWidget {
  final Widget child;
  final VoidCallback onTap;
  final String label;
  const _Ctl({required this.child, required this.onTap, required this.label});

  @override
  Widget build(BuildContext context) => Tap(
        onTap: onTap,
        label: label,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          child: child,
        ),
      );
}
