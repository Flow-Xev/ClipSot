import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../manga.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Opens the page in a real browser view, scrolls it so lazy images load, and collects
/// the chapter's page images. This is the fallback for sites that build their pages
/// with scripts, need a tap to confirm age or cookies, or need you to sign in first
/// (you can do all of that right here, then tap "Grab pages").
///
/// Pops with the list of page addresses, or null when the person goes back.
class WebHarvestScreen extends StatefulWidget {
  final String url;
  const WebHarvestScreen({super.key, required this.url});

  @override
  State<WebHarvestScreen> createState() => _WebHarvestState();
}

class _WebHarvestState extends State<WebHarvestScreen> {
  late final WebViewController _c;
  bool _busy = false;
  bool _autoDone = false;
  int _pct = 0;
  String _note = 'Loading the page…';

  static const _js = r'''
(async function () {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function abs(u) { try { return new URL(u, location.href).href; } catch (e) { return null; } }
  function pick(img) {
    const keys = ['data-url', 'data-src', 'data-original', 'data-lazy-src', 'data-lazy', 'data-img'];
    for (const k of keys) {
      const v = img.getAttribute(k);
      if (v && v.indexOf('data:') !== 0) { const a = abs(v); if (a) return a; }
    }
    const ss = img.getAttribute('data-srcset') || img.getAttribute('srcset');
    if (ss) {
      const parts = ss.split(',').map((x) => x.trim().split(/\s+/));
      const last = parts[parts.length - 1];
      if (last && last[0]) { const a = abs(last[0]); if (a) return a; }
    }
    const v = img.currentSrc || img.src;
    if (v && v.indexOf('data:') !== 0) return abs(v);
    return null;
  }
  function collect() {
    const out = [];
    document.querySelectorAll('img').forEach((img) => {
      const src = pick(img);
      if (!src) return;
      const r = img.getBoundingClientRect();
      out.push({ src: src, w: img.naturalWidth || Math.round(r.width) || 0,
                 h: img.naturalHeight || Math.round(r.height) || 0, top: r.top + window.scrollY });
    });
    document.querySelectorAll('canvas').forEach((c) => {
      // canvas-drawn pages cannot be saved as an address; counted so the app can explain
      if (c.width > 300 && c.height > 300) out.push({ canvas: true });
    });
    return out;
  }
  let last = 0, still = 0;
  for (let i = 0; i < 500 && still < 5; i++) {
    window.scrollBy(0, Math.round(window.innerHeight * 0.85));
    await sleep(320);
    const h = document.documentElement.scrollHeight;
    const atEnd = window.scrollY + window.innerHeight >= h - 4;
    if (atEnd && h === last) still++; else still = 0;
    last = h;
    Harvest.postMessage('p:' + Math.min(99, Math.round(100 * (window.scrollY + window.innerHeight) / h)));
  }
  await sleep(700);
  Harvest.postMessage('r:' + JSON.stringify(collect()));
})();
''';

  @override
  void initState() {
    super.initState();
    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent('Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) '
          'Chrome/124.0.0.0 Mobile Safari/537.36')
      ..addJavaScriptChannel('Harvest', onMessageReceived: (m) => _onMessage(m.message))
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (v) {
          if (mounted && !_busy) setState(() => _pct = v);
        },
        onPageFinished: (_) {
          if (!_autoDone && mounted) {
            _autoDone = true;
            // Give scripts a moment to build the page, then grab.
            Future<void>.delayed(const Duration(milliseconds: 1200), () {
              if (mounted && !_busy) _grab();
            });
          }
        },
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  Future<void> _grab() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _pct = 0;
      _note = 'Finding the pages…';
    });
    try {
      await _c.runJavaScript(_js);
    } catch (_) {
      if (mounted) {
        setState(() {
          _busy = false;
          _note = 'Couldn’t read this page. Try scrolling to the chapter and tap Grab pages.';
        });
      }
    }
  }

  void _onMessage(String m) {
    if (!mounted) return;
    if (m.startsWith('p:')) {
      setState(() => _pct = int.tryParse(m.substring(2)) ?? _pct);
      return;
    }
    if (!m.startsWith('r:')) return;
    List<dynamic> raw;
    try {
      raw = jsonDecode(m.substring(2)) as List<dynamic>;
    } catch (_) {
      raw = const [];
    }
    final rows = <Map<String, dynamic>>[];
    var canvas = false;
    for (final e in raw) {
      if (e is! Map) continue;
      if (e['canvas'] == true) {
        canvas = true;
        continue;
      }
      final src = e['src'];
      if (src is! String || !isPageImage(src)) continue;
      final w = (e['w'] as num?)?.toInt() ?? 0;
      final h = (e['h'] as num?)?.toInt() ?? 0;
      if (w > 0 && h > 0 && w < 150 && h < 150) continue; // icons and avatars
      rows.add(Map<String, dynamic>.from(e));
    }
    rows.sort((a, b) => ((a['top'] as num?) ?? 0).compareTo((b['top'] as num?) ?? 0));
    final seen = <String>{};
    final urls = <String>[
      for (final r in rows)
        if (seen.add(r['src'] as String)) r['src'] as String,
    ];
    final pages = pickChapterPages(urls);
    if (pages.isNotEmpty) {
      Navigator.of(context).pop(pages);
      return;
    }
    setState(() {
      _busy = false;
      _note = canvas
          ? 'This site draws its pages in a way that can’t be saved. Use Open site to read it there.'
          : 'No pages yet. Sign in or accept any prompt, scroll to the chapter, then tap Grab pages.';
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final top = MediaQuery.paddingOf(context).top;
    final bottom = MediaQuery.paddingOf(context).bottom;
    return Scaffold(
      backgroundColor: const Color(0xFF0B0B0B),
      body: Stack(children: [
        Positioned.fill(
          child: Padding(
            padding: EdgeInsets.only(top: top + 52, bottom: bottom + 84),
            child: WebViewWidget(controller: _c),
          ),
        ),
        // top bar
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: Container(
            padding: EdgeInsets.only(top: top + 4, left: 8, right: 16, bottom: 6),
            color: const Color(0xFF0B0B0B),
            child: Row(children: [
              RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.of(context).pop(), color: Colors.white),
              const SizedBox(width: 4),
              Expanded(
                child: Text(Uri.tryParse(widget.url)?.host ?? widget.url,
                    maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(15, w: FontWeight.w500, color: Colors.white)),
              ),
            ]),
          ),
        ),
        // bottom bar
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
            padding: EdgeInsets.fromLTRB(20, 12, 20, bottom + 14),
            color: const Color(0xFF0B0B0B),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (_busy) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(2),
                  child: LinearProgressIndicator(
                    value: _pct <= 0 ? null : _pct / 100,
                    minHeight: 3,
                    backgroundColor: const Color(0x33FFFFFF),
                    color: p.ac,
                  ),
                ),
                const SizedBox(height: 10),
              ],
              Text(_busy ? 'Loading every page… $_pct%' : _note,
                  textAlign: TextAlign.center, style: ts(13, color: Colors.white70, h: 1.3)),
              const SizedBox(height: 10),
              Tap(
                onTap: _busy ? null : _grab,
                label: 'Grab pages',
                child: Container(
                  height: 46,
                  width: double.infinity,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: _busy ? const Color(0x33FFFFFF) : p.ac,
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Text('Grab pages', style: ts(15, w: FontWeight.w500, color: const Color(0xFF171717))),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
