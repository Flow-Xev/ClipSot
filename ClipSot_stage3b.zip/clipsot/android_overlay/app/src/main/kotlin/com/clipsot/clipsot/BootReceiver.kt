package com.clipsot.clipsot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Alarms are cleared on reboot/update: put reminders, nudges and the edge handle back. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Reminders.restoreAll(ctx)
        Reminders.restoreRediscovery(ctx)
        if (OverlayService.wanted(ctx) && Settings.canDrawOverlays(ctx)) OverlayService.start(ctx)
    }
}
