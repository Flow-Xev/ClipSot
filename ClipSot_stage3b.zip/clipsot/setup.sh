#!/usr/bin/env bash
# One-time Android setup for ClipSot. Run from the clipsot/ folder.
set -e
if [ ! -d android ]; then
  flutter create . --org com.clipsot --project-name clipsot --platforms android
fi
# Copy the ClipSot native layer (manifest, Kotlin, notification layouts, tiles).
cp -R android_overlay/app/. android/app/
# Notification channels, tiles and the overlay need Android 8.0+.
for f in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$f" ] && sed -i.bak 's/flutter\.minSdkVersion/26/' "$f" && rm -f "$f.bak"
done
flutter pub get
echo "Done. Run: flutter run"
