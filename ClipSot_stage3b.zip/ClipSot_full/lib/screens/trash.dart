import 'package:flutter/material.dart';

import '../haptics.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/peel.dart';

/// Everything you deleted waits here for [kTrashDays] days, then goes for good.
class TrashScreen extends StatefulWidget {
  const TrashScreen({super.key});

  @override
  State<TrashScreen> createState() => _TrashScreenState();
}

class _TrashScreenState extends State<TrashScreen> with SingleTickerProviderStateMixin {
  // The bin's lid opens a little when the screen appears and when you empty it.
  late final AnimationController _lid =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 420));

  @override
  void initState() {
    super.initState();
    _lid.forward().then((_) {
      if (mounted) _lid.reverse();
    });
  }

  @override
  void dispose() {
    _lid.dispose();
    super.dispose();
  }

  Future<void> _empty(Store s) async {
    final m = ScaffoldMessenger.of(context);
    final p = P.of(context);
    Haptics.warning();
    final ok = await confirm(
      context,
      'Empty Trash?',
      'These ${s.trashCount} ${s.trashCount == 1 ? 'thing' : 'things'} will be removed for good. This can’t be undone.',
      'Empty Trash',
    );
    if (!ok) return;
    s.emptyTrash();
    Haptics.thud();
    _lid.forward(from: 0).then((_) => _lid.reverse());
    toastWith(m, p, 'Trash emptied');
  }

  void _restoreItem(Store s, Item it) {
    final m = ScaffoldMessenger.of(context);
    final p = P.of(context);
    if (s.restoreItem(it.id)) {
      Haptics.success();
      toastWith(m, p, 'Restored');
    } else {
      Haptics.warning();
      toastWith(m, p, 'That link is already saved');
    }
  }

  void _restoreNote(Store s, Note n) {
    final m = ScaffoldMessenger.of(context);
    final p = P.of(context);
    s.restoreNote(n.id);
    Haptics.success();
    toastWith(m, p, 'Note restored');
  }

  Future<void> _forgetItem(Store s, Item it) async {
    final ok = await confirm(context, 'Delete for good?', '“${it.title}” can’t be brought back.', 'Delete');
    if (!ok) return;
    Haptics.thud();
    s.deleteForever(it.id);
  }

  Future<void> _forgetNote(Store s, Note n) async {
    final ok = await confirm(context, 'Delete for good?', 'This note can’t be brought back.', 'Delete');
    if (!ok) return;
    Haptics.thud();
    s.deleteNoteForever(n.id);
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final s = StoreScope.of(context);

    // One list, newest first.
    final rows = <_TrashRow>[
      for (final i in s.trash) _TrashRow(i.trashed, item: i),
      for (final n in s.trashNotes) _TrashRow(n.trashed, note: n),
    ]..sort((a, b) => b.at.compareTo(a.at));

    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
            child: Row(children: [
              RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.pop(context)),
              const Spacer(),
              if (rows.isNotEmpty)
                Tap(
                  onTap: () => _empty(s),
                  label: 'Empty Trash',
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    child: Text('Empty', style: ts(15, w: FontWeight.w500, color: kDanger)),
                  ),
                ),
            ]),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 4),
                  child: Row(children: [
                    Expanded(child: Text('Trash', style: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx))),
                    AnimatedBuilder(
                      animation: _lid,
                      builder: (_, __) => TrashBinIcon(
                        size: 64,
                        lid: Curves.easeOutCubic.transform(_lid.value),
                        fill: rows.isEmpty ? 0 : 1,
                      ),
                    ),
                  ]),
                ),
                Text(
                  rows.isEmpty
                      ? 'Nothing here.'
                      : 'Things you delete stay here for $kTrashDays days, then they are removed for good.',
                  style: ts(13.5, h: 1.4, color: p.tx2),
                ),
                const SizedBox(height: 14),
                if (rows.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 60),
                    child: Center(child: Text('Deleted links and notes show up here.', style: ts(14, color: p.tx2))),
                  ),
                for (final r in rows)
                  r.item != null
                      ? _TrashTile(
                          key: ValueKey('i${r.item!.id}'),
                          title: r.item!.title,
                          meta: '${r.item!.src} · ${_left(r.item!.trashDaysLeft)}',
                          icon: r.item!.isManga ? Icons.auto_stories_outlined : Icons.article_outlined,
                          onRestore: () => _restoreItem(s, r.item!),
                          onForget: () => _forgetItem(s, r.item!),
                        )
                      : _TrashTile(
                          key: ValueKey('n${r.note!.id}'),
                          title: r.note!.title.trim().isEmpty ? 'Untitled note' : r.note!.title.trim(),
                          meta: 'Note · ${_left(r.note!.trashDaysLeft)}',
                          icon: Icons.edit_note,
                          onRestore: () => _restoreNote(s, r.note!),
                          onForget: () => _forgetNote(s, r.note!),
                        ),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  String _left(int d) => d <= 0 ? 'goes today' : (d == 1 ? '1 day left' : '$d days left');
}

class _TrashRow {
  final int at;
  final Item? item;
  final Note? note;
  _TrashRow(this.at, {this.item, this.note});
}

class _TrashTile extends StatelessWidget {
  final String title, meta;
  final IconData icon;
  final VoidCallback onRestore, onForget;
  const _TrashTile({
    super.key,
    required this.title,
    required this.meta,
    required this.icon,
    required this.onRestore,
    required this.onForget,
  });

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.s1))),
      child: Row(children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, size: 22, color: p.tx2),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(15.5, color: p.tx)),
            const SizedBox(height: 2),
            Text(meta, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, color: p.tx2)),
          ]),
        ),
        RoundIcon(Icons.restore, label: 'Restore', onTap: onRestore),
        RoundIcon(Icons.delete_forever_outlined, label: 'Delete for good', onTap: onForget),
      ]),
    );
  }
}
