import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';

import '../headlines.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/haptic_scroll.dart';
import '../widgets/logo.dart';
import '../widgets/peel.dart';
import 'manga_reader.dart';
import 'notes.dart';
import 'image_view.dart';
import 'reader.dart';
import 'sheets.dart';
import 'video_view.dart';

/// Opens an item in the right viewer and marks articles as read.
void openItem(BuildContext context, Item it) {
  final store = StoreScope.of(context);
  store.markOpened(it);
  if (it.isFile && !it.isImage) {
    // PDFs and other documents open in the phone's own viewer.
    OpenFilex.open(it.path!).then((r) {
      if (r.type != ResultType.done && context.mounted) toast(context, 'No app found to open this file');
    });
    return;
  }
  Navigator.of(context).push(MaterialPageRoute<void>(
    builder: (_) => it.isVideo
        ? VideoScreen(id: it.id)
        : (it.isManga
            ? MangaScreen(id: it.id)
            : (it.isImage && it.isFile ? ImageScreen(id: it.id) : ReaderScreen(id: it.id))),
  ));
}

enum _HeroKind { resume, archive, fresh, revisit }

class _Hero {
  final Item item;
  final String eyebrow;
  final _HeroKind kind;
  const _Hero(this.item, this.eyebrow, this.kind);
}

class HomeScreen extends StatefulWidget {
  /// Goes up each time the person comes back to Home, so the page feels fresh.
  final int visit;
  final VoidCallback onSearch;
  final VoidCallback onSettings;
  const HomeScreen({super.key, this.visit = 0, required this.onSearch, required this.onSettings});

  @override
  State<HomeScreen> createState() => _HomeState();
}

class _HomeState extends State<HomeScreen> {
  final Random _rng = Random();
  late int _seed;
  late Headline _hl;

  @override
  void initState() {
    super.initState();
    _seed = _rng.nextInt(1 << 20);
    _hl = _pickHeadline();
  }

  @override
  void didUpdateWidget(HomeScreen old) {
    super.didUpdateWidget(old);
    if (old.visit != widget.visit) {
      _seed = _rng.nextInt(1 << 20);
      _hl = _pickHeadline();
    }
  }

  Headline _pickHeadline() {
    final s = StoreScope.read(context);
    final h = pickHeadline(
      rng: _rng,
      now: DateTime.now(),
      total: s.items.length,
      unread: s.items.where((i) => !i.read).length,
      forgotten: s.forgottenList(99).length,
      inProgress: s.continueList(99).length,
      lastId: s.lastHeadline,
    );
    s.rememberHeadline(h.id);
    return h;
  }

  void _shuffle() => setState(() {
        _seed = _rng.nextInt(1 << 20);
        _hl = _pickHeadline();
      });

  /// What to feature at the top. Rotates between what you are reading,
  /// something old, something new, or a random unread save.
  _Hero? _hero(Store s) {
    if (s.items.isEmpty) return null;
    final cont = s.continueList(1);
    final forgot = s.forgottenList(1);
    final fresh = s.items.where((i) => !i.read && i.daysAgo <= 7).toList();
    final options = <_Hero>[
      if (cont.isNotEmpty) _Hero(cont.first, 'Pick up where you left off', _HeroKind.resume),
      if (forgot.isNotEmpty) _Hero(forgot.first, 'From your archive', _HeroKind.archive),
      if (fresh.isNotEmpty) _Hero(fresh.first, 'Fresh in your library', _HeroKind.fresh),
    ];
    if (options.isEmpty) {
      final pool = s.items.where((i) => !i.read).toList();
      final src = pool.isEmpty ? s.items : pool;
      return _Hero(src[_seed % src.length], 'Worth another look', _HeroKind.revisit);
    }
    return options[_seed % options.length];
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final notesMode = store.filter == 'Notes';
    final showFeatured = store.filter == 'All' && store.items.isNotEmpty;
    final hero = showFeatured ? _hero(store) : null;

    final list = store.filtered.where((i) => hero == null || i.id != hero.item.id).toList();
    final cont = store.continueList(1).where((i) => hero?.kind != _HeroKind.resume).toList();
    final skip = hero?.item.id;
    final rediscover = <(Item, String)>[
      for (final f in store.forgottenList(3))
        if (f.id != skip) (f, 'Saved ${f.daysAgo} days ago, still unread'),
      for (final f in store.items.where((i) => !i.read && i.daysAgo <= 7).take(1))
        if (f.id != skip) (f, 'Recently saved, not opened yet'),
    ];
    final unread = store.items.where((i) => !i.read).length;
    final tailColor = _seed % 3 == 0 ? p.ac : p.tx2;

    return HapticScroll(
      child: ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 160),
      children: [
        // Header: logo + wordmark, search, settings
        Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                ClipSotMark(size: 32, ringColor: p.ac, dotColor: p.tx),
                const SizedBox(width: 8),
                Text('clipsot.', style: ts(28, w: FontWeight.w500, ls: -1, color: p.tx)),
              ]),
              Row(children: [
                RoundIcon(Icons.search, onTap: widget.onSearch, label: 'Search'),
                const SizedBox(width: 4),
                RoundIcon(Icons.tune, onTap: widget.onSettings, label: 'Settings'),
              ]),
            ],
          ),
        ),
        // A different line every visit. Tap it for another one.
        Tap(
          onTap: _shuffle,
          label: 'Show another line',
          child: Padding(
            padding: const EdgeInsets.only(top: 18, bottom: 18),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 380),
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(begin: const Offset(0, .12), end: Offset.zero).animate(anim),
                  child: child,
                ),
              ),
              layoutBuilder: (current, previous) => Stack(
                alignment: Alignment.centerLeft,
                children: [...previous, if (current != null) current],
              ),
              child: Align(
                key: ValueKey(_hl.id),
                alignment: Alignment.centerLeft,
                child: Text.rich(
                  TextSpan(children: [
                    TextSpan(text: '${_hl.lead}\n', style: ts(36, ls: -1.4, h: 1.05, color: p.tx)),
                    TextSpan(text: _hl.tail, style: ts(36, ls: -1.4, h: 1.05, color: tailColor)),
                  ]),
                ),
              ),
            ),
          ),
        ),
        if (showFeatured) ...[
          // Quick numbers; each one is also a shortcut
          Row(children: [
            Expanded(child: _Stat(n: store.items.length, label: 'Saved', onTap: () => store.setFilter('All'))),
            const SizedBox(width: 8),
            Expanded(child: _Stat(n: unread, label: 'Unread', dot: unread > 0, onTap: () => store.setFilter('Unread'))),
            const SizedBox(width: 8),
            Expanded(child: _Stat(n: store.notes.length, label: 'Notes', onTap: () => store.setFilter('Notes'))),
          ]),
          if (hero != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: _HeroCard(
                key: ValueKey('hero${hero.item.id}$_seed'),
                hero: hero,
                look: (_seed ~/ 3) % 3,
                onAnother: _shuffle,
              ),
            ),
          const SizedBox(height: 4),
        ],
        // Filters
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.only(top: 16, bottom: 16),
          child: Row(children: [
            for (final f in kFilters)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Pill(f, on: store.filter == f, onTap: () => store.setFilter(f)),
              ),
          ]),
        ),
        if (notesMode) ...[
          if (store.notes.isEmpty)
            _Empty(
              title: 'No notes yet',
              body: 'Capture a thought, or attach a note to anything you save.',
              action: 'Write a note',
              onAction: () => openNote(context),
            )
          else ...[
            for (final n in (List.of(store.notes)..sort((a, b) => b.updated.compareTo(a.updated))))
              NoteTile(note: n, key: ValueKey('hn${n.id}')),
          ],
        ] else if (store.items.isEmpty)
          _Empty(
            title: 'No saves yet',
            body: 'Start saving articles, videos and more to find them later.',
            action: 'Save something',
            onAction: () => showAddSheet(context),
          )
        else if (list.isEmpty)
          _Empty(title: 'Nothing here', body: 'No ${store.filter.toLowerCase()} items yet.')
        else
          _Mosaic(items: list, seed: _seed),
        if (store.filter == 'All' && cont.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.only(top: 22, bottom: 12),
            child: Text('Continue reading', style: ts(15, w: FontWeight.w500, color: p.tx)),
          ),
          for (final c in cont) _ContinueRow(item: c),
        ],
        if (store.filter == 'All' && store.items.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.only(top: 22, bottom: 12),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Rediscover', style: ts(15, w: FontWeight.w500, color: p.tx)),
              Tap(
                onTap: () {
                  final r = store.randomItem();
                  if (r != null) openItem(context, r);
                },
                label: 'Surprise me',
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Text('Surprise me', style: ts(13, color: p.ac)),
                ),
              ),
            ]),
          ),
          if (rediscover.isNotEmpty)
            SizedBox(
              height: 168,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: rediscover.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) => _RediscoverCard(item: rediscover[i].$1, sub: rediscover[i].$2),
              ),
            ),
        ],
      ],
    ));
  }
}

/// Small number tile that doubles as a filter shortcut.
class _Stat extends StatelessWidget {
  final int n;
  final String label;
  final bool dot;
  final VoidCallback onTap;
  const _Stat({required this.n, required this.label, required this.onTap, this.dot = false});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Tap(
      onTap: onTap,
      label: '$n $label',
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text('$n', style: ts(24, w: FontWeight.w500, ls: -.6, color: p.tx)),
            if (dot) ...[
              const SizedBox(width: 6),
              Container(width: 7, height: 7, decoration: BoxDecoration(color: p.ac, shape: BoxShape.circle)),
            ],
          ]),
          const SizedBox(height: 2),
          Text(label, style: ts(12, color: p.tx2)),
        ]),
      ),
    );
  }
}

/// The big featured card. Its colours change between visits (look 0..2).
class _HeroCard extends StatelessWidget {
  final _Hero hero;
  final int look;
  final VoidCallback onAnother;
  const _HeroCard({super.key, required this.hero, required this.look, required this.onAnother});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final it = hero.item;
    const ink = Color(0xFF171717);
    final Color bg = look == 0 ? p.ac : (look == 1 ? p.card : p.s1);
    final Color fg = look == 2 ? p.tx : ink;
    final Color btnBg = look == 2 ? p.ac : ink;
    final Color btnFg = look == 2 ? ink : const Color(0xFFF4F3F0);
    final showBar = hero.kind == _HeroKind.resume;
    final meta = it.metaShort;

    return Tap(
      onTap: () => openItem(context, it),
      onLong: () => showItemActions(context, it.id),
      label: '${hero.eyebrow}: ${it.title}',
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(28)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(hero.eyebrow.toUpperCase(), style: ts(11.5, ls: .8, color: alpha(fg, .65))),
          const SizedBox(height: 12),
          Text(it.title,
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
              style: ts(28, w: FontWeight.w500, ls: -.9, h: 1.1, color: fg)),
          const SizedBox(height: 10),
          Text('${it.savedLabel} \u00B7 $meta', style: ts(13, color: alpha(fg, .65))),
          if (showBar) ...[
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: it.progress.clamp(0.0, 1.0).toDouble(),
                minHeight: 4,
                backgroundColor: alpha(fg, .18),
                color: fg,
              ),
            ),
          ],
          const SizedBox(height: 18),
          Row(children: [
            Container(
              height: 44,
              padding: const EdgeInsets.symmetric(horizontal: 22),
              alignment: Alignment.center,
              decoration: BoxDecoration(color: btnBg, borderRadius: BorderRadius.circular(24)),
              child: Text(it.isVideo ? 'Watch now' : (it.isManga ? 'Read chapter' : 'Read now'), style: ts(15, w: FontWeight.w500, color: btnFg)),
            ),
            const SizedBox(width: 6),
            Tap(
              onTap: onAnother,
              label: 'Show something else',
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Text('Something else', style: ts(14, color: alpha(fg, .75))),
              ),
            ),
          ]),
        ]),
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  final String title, body;
  final String? action;
  final VoidCallback? onAction;
  const _Empty({required this.title, required this.body, this.action, this.onAction});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 20),
      child: Column(children: [
        Container(
          width: 110,
          height: 110,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: p.s1, shape: BoxShape.circle),
          child: ClipSotMark(size: 58, ringColor: p.ac, dotColor: p.tx),
        ),
        const SizedBox(height: 24),
        Text(title, style: ts(22, w: FontWeight.w500, color: p.tx)),
        const SizedBox(height: 8),
        Text(body, textAlign: TextAlign.center, style: ts(14, color: p.tx2)),
        if (action != null) ...[
          const SizedBox(height: 24),
          Tap(
            onTap: onAction,
            label: action,
            child: Container(
              height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 28),
              alignment: Alignment.center,
              decoration: BoxDecoration(color: p.ac, borderRadius: BorderRadius.circular(26)),
              child: Text(action!, style: ts(16, w: FontWeight.w500, color: const Color(0xFF171717))),
            ),
          ),
        ],
      ]),
    );
  }
}

/// Mixed rhythm: full-width feature cards between two-up rows, with colours
/// that shift every visit. Replaces the old plain two-column grid.
class _Mosaic extends StatelessWidget {
  final List<Item> items;
  final int seed;
  const _Mosaic({required this.items, required this.seed});

  @override
  Widget build(BuildContext context) {
    // How many cards per row, repeating. Two rhythms, picked per visit.
    final rhythm = seed.isEven ? const [1, 2, 2] : const [2, 1, 2];
    final rows = <Widget>[];
    var i = 0, r = 0;
    while (i < items.length) {
      final per = rhythm[r % rhythm.length];
      final take = min(per, items.length - i);
      final slice = items.sublist(i, i + take);

      Widget card(int idx, {required bool wide}) => Rise(
            key: ValueKey('c${items[idx].id}'),
            i: idx,
            child: PeelItem(
              id: items[idx].id,
              child: ItemCard(item: items[idx], variant: (idx + seed) % 4, wide: wide),
            ),
          );

      rows.add(Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: take == 1
            ? card(i, wide: true)
            : Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (var k = 0; k < slice.length; k++) ...[
                    if (k > 0) const SizedBox(width: 10),
                    Expanded(child: card(i + k, wide: false)),
                  ],
                ],
              ),
      ));
      i += take;
      r++;
    }
    return Column(children: rows);
  }
}

/// variant: 0 light card, 1 image card, 2 accent, 3 dark.
class ItemCard extends StatelessWidget {
  final Item item;
  final int variant;
  final bool wide;
  const ItemCard({super.key, required this.item, required this.variant, this.wide = false});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final it = item;

    if (variant == 1) {
      return Tap(
        onTap: () => openItem(context, it),
        onLong: () => showItemActions(context, it.id),
        label: it.title,
        child: Container(
          constraints: BoxConstraints(minHeight: wide ? 190 : 150),
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
          alignment: Alignment.bottomLeft,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF6B6B69), Color(0xFF2A2A2A)],
              stops: [0, 0.7],
            ),
            image: it.isImage && it.isFile
                ? DecorationImage(
                    image: ResizeImage(FileImage(File(it.path!)), width: 600),
                    fit: BoxFit.cover,
                    colorFilter: const ColorFilter.mode(Color(0x66000000), BlendMode.darken),
                  )
                : null,
          ),
          child: Text(it.title,
              style: ts(wide ? 22 : 15, w: FontWeight.w500, color: Colors.white, h: 1.2)),
        ),
      );
    }

    final bg = variant == 0 ? p.card : (variant == 2 ? p.ac : p.s1);
    final fg = variant == 3 ? p.tx : const Color(0xFF171717);
    final meta = it.metaShort;
    final pct = it.progress > 0.03 && it.progress < 0.95 ? ' \u00B7 ${(it.progress * 100).round()}%' : '';

    return Tap(
      onTap: () => openItem(context, it),
      onLong: () => showItemActions(context, it.id),
      label: it.title,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(wide ? 20 : 16),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(22)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(it.savedLabel, style: ts(11.5, color: alpha(fg, .6))),
            const SizedBox(height: 10),
            Text(it.title,
                maxLines: wide ? 3 : 6,
                overflow: TextOverflow.ellipsis,
                style: ts(wide ? 25 : 19, w: FontWeight.w500, ls: wide ? -.7 : -.4, h: 1.15, color: fg)),
            SizedBox(height: wide ? 28 : 22),
            Row(children: [
              if (it.isVideo) ...[
                Container(
                  width: 26,
                  height: 26,
                  decoration: const BoxDecoration(color: Color(0xFF171717), shape: BoxShape.circle),
                  child: const Icon(Icons.play_arrow, size: 16, color: Color(0xFFF4F3F0)),
                ),
                const SizedBox(width: 6),
              ],
              Flexible(
                child: Text('$meta$pct',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: ts(12, color: alpha(fg, .6))),
              ),
              if (!it.read) ...[
                const SizedBox(width: 6),
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(color: p.ac, shape: BoxShape.circle),
                ),
              ],
            ]),
          ],
        ),
      ),
    );
  }
}

class _ContinueRow extends StatelessWidget {
  final Item item;
  const _ContinueRow({required this.item});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final left = item.mins > 0 ? ' \u00B7 about ${(item.mins * (1 - item.progress)).ceil().clamp(1, 999)} min left' : '';
    return Tap(
      onTap: () => openItem(context, item),
      onLong: () => showItemActions(context, item.id),
      label: 'Continue reading ${item.title}',
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(22)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(16, w: FontWeight.w500, h: 1.2, color: p.tx)),
          const SizedBox(height: 4),
          Text('${(item.progress * 100).round()}% read$left', style: ts(12.5, color: p.tx2)),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(value: item.progress, minHeight: 4, backgroundColor: p.s2, color: p.ac),
          ),
        ]),
      ),
    );
  }
}

class _RediscoverCard extends StatelessWidget {
  final Item item;
  final String sub;
  const _RediscoverCard({required this.item, required this.sub});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return SizedBox(
      width: 250,
      child: Tap(
        onTap: () => openItem(context, item),
        onLong: () => showItemActions(context, item.id),
        label: 'Rediscover ${item.title}',
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(24)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item.title,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: ts(18, w: FontWeight.w500, ls: -.3, h: 1.15, color: p.tx)),
            const Spacer(),
            Text(sub, style: ts(12.5, color: p.tx2)),
          ]),
        ),
      ),
    );
  }
}
