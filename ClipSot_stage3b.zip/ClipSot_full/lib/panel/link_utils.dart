import '../models.dart';

final _urlRe = RegExp(r'''https?://[^\s<>"'\)\]]+''', caseSensitive: false);

/// Finds the first link in [text] (shared text, clipboard, selected text).
/// Accepts bare domains like "example.com/page" when the text is only a link.
String? extractLink(String? text) {
  if (text == null) return null;
  final t = text.trim();
  if (t.isEmpty) return null;
  final m = _urlRe.firstMatch(t);
  if (m != null) return m.group(0)!.replaceAll(RegExp(r'[.,;:!?]+$'), '');
  if (!t.contains(RegExp(r'\s')) && Item.fromUrl(t, '', []) != null) return t;
  return null;
}

/// Every link in [text] (pasted lists, shared text). A lone bare domain counts too.
List<String> extractAllLinks(String? text) {
  if (text == null || text.trim().isEmpty) return const [];
  final out = <String>[];
  for (final m in _urlRe.allMatches(text)) {
    final l = m.group(0)!.replaceAll(RegExp(r'[.,;:!?]+$'), '');
    if (!out.contains(l)) out.add(l);
  }
  if (out.isEmpty) {
    final one = extractLink(text);
    if (one != null) out.add(one);
  }
  return out;
}
