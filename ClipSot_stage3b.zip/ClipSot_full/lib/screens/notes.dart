import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';

void openNote(BuildContext context, {int? id, int? itemId}) =>
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => NoteEditor(id: id, itemId: itemId)));

String _stamp(DateTime d) {
  final diff = DateTime.now().difference(d).inDays;
  if (diff <= 0) return 'Today';
  if (diff == 1) return 'Yesterday';
  return '$diff days ago';
}

class NoteTile extends StatelessWidget {
  final Note note;
  final List<String> toks;
  const NoteTile({super.key, required this.note, this.toks = const []});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final linked = note.itemId == null ? null : store.byId(note.itemId!);
    final title = note.title.trim().isEmpty ? 'Untitled note' : note.title.trim();
    return Tap(
      onTap: () => openNote(context, id: note.id),
      label: title,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(22)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('NOTE · ${_stamp(note.updated).toUpperCase()}', style: ts(11.5, color: p.tx2, ls: .3)),
          const SizedBox(height: 8),
          Text.rich(highlight(title, toks, ts(18, w: FontWeight.w500, ls: -.3, color: p.tx), p)),
          if (note.text.trim().isNotEmpty) ...[
            const SizedBox(height: 6),
            Text.rich(
              highlight(note.text.trim(), toks, ts(14, color: p.tx2, h: 1.35), p),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
          if (note.tags.isNotEmpty || linked != null) ...[
            const SizedBox(height: 10),
            Wrap(spacing: 6, runSpacing: 6, children: [
              for (final t in note.tags)
                Text('#$t', style: ts(12, color: p.ac)),
              if (linked != null)
                Text('↗ ${linked.title}', style: ts(12, color: p.tx2)),
            ]),
          ],
        ]),
      ),
    );
  }
}

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final toks = tokens(_q.text);
    final list = store.notes.where((n) {
      if (toks.isEmpty) return true;
      final hay = '${n.title} ${n.text} ${n.tags.join(' ')}'.toLowerCase();
      return toks.every(hay.contains);
    }).toList()
      ..sort((a, b) => b.updated.compareTo(a.updated));

    return Scaffold(
      backgroundColor: p.bg,
      floatingActionButton: Tap(
        onTap: () => openNote(context),
        label: 'New note',
        child: Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(color: p.ac, shape: BoxShape.circle),
          child: const Icon(Icons.add, size: 28, color: Color(0xFF171717)),
        ),
      ),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
            child: Row(children: [
              RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.pop(context)),
              const SizedBox(width: 4),
              Text('Notes', style: ts(28, w: FontWeight.w500, ls: -.8, color: p.tx)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: SearchField(_q, 'Search notes…', onChanged: (_) => setState(() {})),
          ),
          Expanded(
            child: list.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.edit_note, size: 48, color: p.tx2),
                        const SizedBox(height: 16),
                        Text(toks.isEmpty ? 'No notes yet' : 'No matches', style: ts(22, w: FontWeight.w500, color: p.tx)),
                        const SizedBox(height: 8),
                        Text(
                          toks.isEmpty ? 'Tap + to write your first note.' : 'Try a different word.',
                          style: ts(14, color: p.tx2),
                        ),
                      ]),
                    ),
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                    children: [for (final n in list) NoteTile(note: n, toks: toks, key: ValueKey(n.id))],
                  ),
          ),
        ]),
      ),
    );
  }
}

/// Create/edit a note. Saves automatically when you leave, unless it is empty.
class NoteEditor extends StatefulWidget {
  final int? id;
  final int? itemId;
  const NoteEditor({super.key, this.id, this.itemId});

  @override
  State<NoteEditor> createState() => _NoteEditorState();
}

class _NoteEditorState extends State<NoteEditor> {
  late final Note _note;
  late final TextEditingController _title, _text, _tags;
  bool _deleted = false;

  @override
  void initState() {
    super.initState();
    final store = StoreScope.read(context);
    final existing = widget.id == null ? null : store.noteById(widget.id!);
    _note = existing ?? Note(id: DateTime.now().microsecondsSinceEpoch, itemId: widget.itemId);
    _title = TextEditingController(text: _note.title);
    _text = TextEditingController(text: _note.text);
    _tags = TextEditingController(text: _note.tags.map((t) => '#$t').join(' '));
  }

  @override
  void dispose() {
    _title.dispose();
    _text.dispose();
    _tags.dispose();
    super.dispose();
  }

  void _save() {
    if (_deleted) return;
    _note.title = _title.text.trim();
    _note.text = _text.text;
    _note.tags = _tags.text
        .split(RegExp(r'[\s,]+'))
        .map((t) => t.replaceAll('#', '').trim())
        .where((t) => t.isNotEmpty)
        .toList();
    final store = StoreScope.read(context);
    if (_note.isEmpty) {
      store.deleteNote(_note.id);
    } else {
      store.saveNote(_note);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final linked = _note.itemId == null ? null : store.byId(_note.itemId!);

    return PopScope(
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) _save();
      },
      child: Scaffold(
        backgroundColor: p.bg,
        body: SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.pop(context)),
                Row(children: [
                  RoundIcon(Icons.ios_share, label: 'Share note', onTap: () {
                    final body = [
                      if (_title.text.trim().isNotEmpty) _title.text.trim(),
                      if (_text.text.trim().isNotEmpty) _text.text.trim(),
                    ].join('\n\n');
                    if (body.isEmpty) {
                      toast(context, 'Nothing to share yet');
                    } else {
                      Share.share(body);
                    }
                  }),
                  RoundIcon(Icons.delete_outline, label: 'Delete note', onTap: () async {
                    final nav = Navigator.of(context);
                    final m = ScaffoldMessenger.of(context);
                    final ok = await confirm(context, 'Delete this note?', 'This can’t be undone.', 'Delete');
                    if (!ok) return;
                    _deleted = true;
                    store.deleteNote(_note.id);
                    nav.pop();
                    toastWith(m, p, 'Note deleted');
                  }),
                ]),
              ]),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
                children: [
                  if (linked != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text('ATTACHED TO ${linked.title.toUpperCase()}',
                          style: ts(12, color: p.tx2, ls: .3)),
                    ),
                  TextField(
                    controller: _title,
                    textCapitalization: TextCapitalization.sentences,
                    cursorColor: p.ac,
                    style: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx, h: 1.1),
                    decoration: InputDecoration(
                      hintText: 'Title',
                      hintStyle: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx2, h: 1.1),
                      border: InputBorder.none,
                    ),
                  ),
                  TextField(
                    controller: _text,
                    minLines: 8,
                    maxLines: null,
                    textCapitalization: TextCapitalization.sentences,
                    cursorColor: p.ac,
                    style: ts(17, color: p.tx, h: 1.5),
                    decoration: InputDecoration(
                      hintText: 'Write something…',
                      hintStyle: ts(17, color: p.tx2),
                      border: InputBorder.none,
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _tags,
                    cursorColor: p.ac,
                    style: ts(14, color: p.ac),
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.tag, size: 20, color: p.tx2),
                      hintText: 'Tags, e.g. #design #ideas',
                      hintStyle: ts(14, color: p.tx2),
                      filled: true,
                      fillColor: p.s1,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
