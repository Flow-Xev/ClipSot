import 'package:clipsot/extract.dart';
import 'package:flutter_test/flutter_test.dart';

String _para(int words) => List.filled(words, 'quiet').join(' ');

void main() {
  test('extracts title and article paragraphs, skips chrome', () {
    final html = '''
<html><head><title>Fallback title</title>
<meta property="og:title" content="A quieter &amp; better way">
<script>var x = "<p>$_junk</p>";</script></head>
<body><nav><p>${_para(30)}</p></nav>
<article><h1>Heading</h1>
<p>${_para(60)}</p>
<p>short</p>
<blockquote>${_para(20)}</blockquote>
<p>${_para(40)}</p>
</article><footer><p>${_para(50)}</p></footer></body></html>''';
    final r = parseReadable(html);
    expect(r.title, 'A quieter & better way');
    expect(r.body, isNotNull);
    expect(r.body!.length, 3);
    expect(r.body![1].startsWith('Q:'), isTrue);
    expect(r.mins, 1);
  });

  test('pages with too little text return only the title', () {
    final r = parseReadable('<title>Hi</title><p>${_para(20)}</p>');
    expect(r.title, 'Hi');
    expect(r.body, isNull);
  });

  test('titleOnly never returns a body', () {
    final r = parseReadable('<meta property="og:title" content="Video"><article><p>${_para(200)}</p></article>', titleOnly: true);
    expect(r.title, 'Video');
    expect(r.body, isNull);
  });

  test('decodes numeric entities', () {
    final r = parseReadable('<title>It&#8217;s &#x41;</title>');
    expect(r.title, 'It\u2019s A');
  });
}

const _junk = 'script paragraph that must be ignored by the extractor';
