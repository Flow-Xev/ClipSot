package com.clipsot.clipsot

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/**
 * Optional "link grabber". It never listens to events. When the Save link tile is tapped it
 * looks once at the app under the Quick Settings shade and returns the page address
 * (browser address bar, or a visible link). Nothing is stored or sent anywhere.
 */
class LinkAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: LinkAccessibilityService? = null

        private val urlRe = Regex("""https?://[^\s<>"'()\[\]]+""", RegexOption.IGNORE_CASE)
        private val hostRe = Regex("""^(?:[a-z0-9-]+\.)+[a-z]{2,}(?::\d+)?(?:[/?#]\S*)?$""", RegexOption.IGNORE_CASE)

        private val barIds = listOf(
            "url_bar",                       // Chrome, Brave, Edge, Vivaldi, Opera (Chromium)
            "mozac_browser_toolbar_url_view", // Firefox, Focus
            "location_bar_edit_text",        // Samsung Internet
            "url_bar_title",
            "addressbarEdit",
            "url_field",
            "toolbar_url",
            "search_box_text"
        )
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not used */ }
    override fun onInterrupt() { /* not used */ }

    private class Hit(var bar: AccessibilityNodeInfo? = null, var barText: String? = null, var link: String? = null)

    /** Calls [done] with the best link found, or null. Always runs [done] on the main thread. */
    fun grab(done: (String?) -> Unit) {
        val hit = scan()
        val explicit = hit.link
        val bt = hit.barText?.trim()
        if (bt != null && urlRe.containsMatchIn(bt)) {
            done(urlRe.find(bt)!!.value)
            return
        }
        if (bt != null && hostRe.matches(bt)) {
            val withPath = bt.contains('/')
            if (withPath || explicit == null) {
                if (withPath) {
                    done("https://$bt")
                    return
                }
                // Only the site name is shown (Chrome hides the rest). Tap the bar once to reveal the
                // full address, read it, then close the bar again.
                val bar = hit.bar
                if (bar != null && bar.isEnabled && bar.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    main.postDelayed({
                        val again = scan()
                        val t = again.barText?.trim()
                        val full = when {
                            t != null && urlRe.containsMatchIn(t) -> urlRe.find(t)!!.value
                            t != null && hostRe.matches(t) && t.contains('/') -> "https://$t"
                            else -> null
                        }
                        performGlobalAction(GLOBAL_ACTION_BACK)
                        main.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 120)
                        done(full ?: explicit ?: "https://$bt")
                    }, 380)
                    return
                }
            }
        }
        done(explicit)
    }

    /** The app window to look at: not ClipSot, not System UI. */
    private fun appRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            val ws = windows
            if (ws != null) {
                for (w in ws.sortedByDescending { it.layer }) {
                    if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                    val r = w.root ?: continue
                    val pkg = r.packageName?.toString() ?: ""
                    if (pkg == packageName || pkg == "com.android.systemui") continue
                    out.add(r)
                }
            }
        } catch (_: Exception) {
        }
        if (out.isEmpty()) {
            val r = rootInActiveWindow
            val pkg = r?.packageName?.toString() ?: ""
            if (r != null && pkg != packageName && pkg != "com.android.systemui") out.add(r)
        }
        return out
    }

    private fun scan(): Hit {
        val hit = Hit()
        for (root in appRoots()) {
            var budget = 2500
            fun walk(n: AccessibilityNodeInfo?, depth: Int) {
                if (n == null || budget-- <= 0 || depth > 60) return
                val id = n.viewIdResourceName ?: ""
                val text = n.text?.toString()
                if (hit.bar == null && id.isNotEmpty() && barIds.any { id.endsWith(it) } && !text.isNullOrBlank()) {
                    hit.bar = n
                    hit.barText = text
                } else if (hit.link == null) {
                    val m = text?.let { urlRe.find(it) } ?: n.contentDescription?.toString()?.let { urlRe.find(it) }
                    if (m != null) hit.link = m.value.trimEnd('.', ',', ';', ':', '!', '?')
                }
                for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
            }
            walk(root, 0)
            if (hit.bar != null || hit.link != null) break
        }
        return hit
    }
}
