/// Everything ClipSot knows how to recognise: file types and websites.
/// Pure Dart, no network, so it can be unit tested.
library;

const kImageExt = [
  'png', 'jpg', 'jpeg', 'jfif', 'gif', 'webp', 'bmp', 'heic', 'heif', 'avif', 'tif', 'tiff', 'svg', 'ico', 'dng',
];
const kVideoExt = [
  'mp4', 'm4v', 'mkv', 'webm', 'mov', 'avi', '3gp', '3g2', 'flv', 'wmv', 'mpg', 'mpeg', 'ogv', 'mts', 'ts',
];
const kAudioExt = [
  'mp3', 'm4a', 'aac', 'ogg', 'oga', 'opus', 'wav', 'flac', 'wma', 'amr', 'aiff', 'mid', 'midi',
];
const kHtmlExt = ['html', 'htm', 'xhtml', 'mhtml', 'mht'];
const kComicExt = ['cbz', 'zip'];
const kDocExt = [
  'pdf', 'txt', 'rtf', 'doc', 'docx', 'dot', 'dotx', 'odt', 'xls', 'xlsx', 'ods', 'csv', 'tsv', 'ppt', 'pptx', 'odp',
  'key', 'pages', 'numbers', 'epub', 'mobi', 'azw3', 'fb2', 'md', 'markdown', 'json', 'xml', 'yaml', 'yml', 'log',
  'tex', 'srt', 'vtt',
];

/// Every file extension the Add flow understands.
List<String> get kAllExt =>
    [...kImageExt, ...kVideoExt, ...kAudioExt, ...kHtmlExt, ...kComicExt, ...kDocExt];

String extOf(String name) {
  final clean = name.split('?').first.split('#').first;
  final i = clean.lastIndexOf('.');
  return i < 0 ? '' : clean.substring(i + 1).toLowerCase();
}

/// What a file is, by its extension:
/// image | video | audio | html | comic | document
String fileKind(String name) {
  final e = extOf(name);
  if (kImageExt.contains(e)) return 'image';
  if (kVideoExt.contains(e)) return 'video';
  if (kAudioExt.contains(e)) return 'audio';
  if (kHtmlExt.contains(e)) return 'html';
  if (kComicExt.contains(e)) return 'comic';
  return 'document';
}

/// True when [e] is an extension that is a whole file worth downloading
/// (not a web page).
bool isDirectFileExt(String e) =>
    kImageExt.contains(e) || kVideoExt.contains(e) || kAudioExt.contains(e) || kDocExt.contains(e) && e != 'md';

// ---------------------------------------------------------------------------
// Websites. "host|Name|type" (type: video, audio, manga, article).
// The longest matching host wins, so music.youtube.com beats youtube.com.
// ---------------------------------------------------------------------------

const _sites = '''
youtube.com|YouTube|video
youtu.be|YouTube|video
music.youtube.com|YouTube Music|audio
vimeo.com|Vimeo|video
dailymotion.com|Dailymotion|video
twitch.tv|Twitch|video
tiktok.com|TikTok|video
bilibili.com|Bilibili|video
b23.tv|Bilibili|video
rumble.com|Rumble|video
odysee.com|Odysee|video
ted.com|TED|video
nebula.tv|Nebula|video
crunchyroll.com|Crunchyroll|video
netflix.com|Netflix|video
primevideo.com|Prime Video|video
hotstar.com|Hotstar|video
disneyplus.com|Disney+|video
hulu.com|Hulu|video
max.com|Max|video
peacocktv.com|Peacock|video
paramountplus.com|Paramount+|video
jiocinema.com|JioCinema|video
sonyliv.com|SonyLIV|video
zee5.com|ZEE5|video
mxplayer.in|MX Player|video
voot.com|Voot|video
fb.watch|Facebook Watch|video
streamable.com|Streamable|video
loom.com|Loom|video
wistia.com|Wistia|video
v.redd.it|Reddit Video|video
youku.com|Youku|video
iq.com|iQIYI|video
viki.com|Viki|video
kick.com|Kick|video
vk.com|VK|video
ok.ru|OK|video
bitchute.com|BitChute|video
brighteon.com|Brighteon|video
dropout.tv|Dropout|video
curiositystream.com|CuriosityStream|video
mubi.com|MUBI|video
spotify.com|Spotify|audio
soundcloud.com|SoundCloud|audio
music.apple.com|Apple Music|audio
podcasts.apple.com|Apple Podcasts|audio
bandcamp.com|Bandcamp|audio
deezer.com|Deezer|audio
tidal.com|TIDAL|audio
audible.com|Audible|audio
mixcloud.com|Mixcloud|audio
anchor.fm|Anchor|audio
podcasters.spotify.com|Spotify Podcasts|audio
pocketcasts.com|Pocket Casts|audio
overcast.fm|Overcast|audio
castbox.fm|Castbox|audio
audiomack.com|Audiomack|audio
jiosaavn.com|JioSaavn|audio
gaana.com|Gaana|audio
wynk.in|Wynk|audio
napster.com|Napster|audio
last.fm|Last.fm|audio
libsyn.com|Libsyn|audio
buzzsprout.com|Buzzsprout|audio
mangadex.org|MangaDex|manga
webtoons.com|WEBTOON|manga
tapas.io|Tapas|manga
mangaplus.shueisha.co.jp|MANGA Plus|manga
comick.io|Comick|manga
mangakakalot.com|Mangakakalot|manga
manganato.com|Manganato|manga
mangapark.net|MangaPark|manga
bato.to|Bato|manga
asuracomic.net|Asura Scans|manga
readcomiconline.li|ReadComicOnline|manga
comixology.com|ComiXology|manga
kodansha.us|Kodansha|manga
viz.com|VIZ|manga
mangaplanet.com|Manga Planet|manga
tcbscans.com|TCB Scans|manga
mangareader.to|MangaReader|manga
mangapill.com|MangaPill|manga
mangafire.to|MangaFire|manga
mangabuddy.com|MangaBuddy|manga
lezhinus.com|Lezhin|manga
page.kakao.com|KakaoPage|manga
comic.naver.com|Naver Comics|manga
manhuaplus.com|ManhuaPlus|manga
toonily.com|Toonily|manga
mangago.me|Mangago
webtoon.xyz|Webtoon.xyz|manga
flamecomics.xyz|Flame Comics|manga
reaperscans.com|Reaper Scans|manga
mangahere.cc|MangaHere|manga
mangaupdates.com|MangaUpdates
medium.com|Medium|article
substack.com|Substack|article
reddit.com|Reddit|article
x.com|X|article
twitter.com|X|article
github.com|GitHub|article
wikipedia.org|Wikipedia|article
nytimes.com|The New York Times|article
bbc.com|BBC|article
bbc.co.uk|BBC|article
theguardian.com|The Guardian|article
washingtonpost.com|The Washington Post|article
wsj.com|The Wall Street Journal|article
bloomberg.com|Bloomberg|article
reuters.com|Reuters|article
theverge.com|The Verge|article
wired.com|WIRED|article
arstechnica.com|Ars Technica|article
techcrunch.com|TechCrunch|article
hackernoon.com|HackerNoon|article
dev.to|DEV|article
stackoverflow.com|Stack Overflow|article
quora.com|Quora|article
linkedin.com|LinkedIn|article
news.ycombinator.com|Hacker News|article
pinterest.com|Pinterest|article
tumblr.com|Tumblr|article
notion.so|Notion|article
docs.google.com|Google Docs|article
arxiv.org|arXiv|article
nature.com|Nature|article
sciencedirect.com|ScienceDirect|article
thehindu.com|The Hindu|article
indianexpress.com|The Indian Express|article
timesofindia.indiatimes.com|Times of India|article
''';

class SiteInfo {
  final String name;
  final String type;
  const SiteInfo(this.name, this.type);
}

Map<String, SiteInfo>? _table;

Map<String, SiteInfo> get _siteTable => _table ??= () {
      final m = <String, SiteInfo>{};
      for (final line in _sites.split('\n')) {
        final p = line.trim().split('|');
        if (p.length < 2 || p[0].isEmpty) continue;
        m[p[0]] = SiteInfo(p[1], p.length > 2 ? p[2] : 'article');
      }
      return m;
    }();

/// How many websites ClipSot recognises by name.
int get kSiteCount => _siteTable.length;

/// Total things the Add flow can take: websites + file types + manual methods.
int get kSupportedCount => kSiteCount + kAllExt.length + 10;

/// The site behind [host] (www. and sub-domains are fine), or null.
SiteInfo? siteFor(String host) {
  var h = host.toLowerCase();
  if (h.startsWith('www.')) h = h.substring(4);
  final t = _siteTable;
  var parts = h.split('.');
  while (parts.length >= 2) {
    final hit = t[parts.join('.')];
    if (hit != null) return hit;
    parts = parts.sublist(1);
  }
  return null;
}

/// Best guess of what a link is: video | audio | manga | image | document | article.
/// Only looks at the address (no network).
String guessLinkType(Uri u) {
  final e = extOf(u.path);
  if (kVideoExt.contains(e)) return 'video';
  if (kAudioExt.contains(e)) return 'audio';
  if (kImageExt.contains(e)) return 'image';
  if (e == 'pdf') return 'document';
  final site = siteFor(u.host);
  final path = u.path.toLowerCase();
  final host = u.host.toLowerCase();
  if ((host.endsWith('instagram.com') && RegExp(r'^/(reels?|tv)/').hasMatch(path)) ||
      (host.endsWith('facebook.com') && (path.startsWith('/watch') || path.contains('/videos/') || path.startsWith('/reel')))) {
    return 'video';
  }
  if (host.endsWith('twitter.com') || host.endsWith('x.com')) return 'article';
  if (site != null && site.type != 'article') return site.type;
  return 'article';
}

/// YouTube video id from a watch / short / youtu.be / embed link, or null.
String? youtubeId(Uri u) {
  final h = u.host.toLowerCase();
  String? id;
  if (h == 'youtu.be') {
    id = u.pathSegments.isEmpty ? null : u.pathSegments.first;
  } else if (h.endsWith('youtube.com')) {
    if (u.path == '/watch') {
      id = u.queryParameters['v'];
    } else if (u.pathSegments.length >= 2 && const {'shorts', 'embed', 'live', 'v'}.contains(u.pathSegments.first)) {
      id = u.pathSegments[1];
    }
  }
  return id != null && RegExp(r'^[A-Za-z0-9_-]{6,15}$').hasMatch(id) ? id : null;
}

/// A cover picture that needs no network lookup: YouTube thumbnails, or the
/// image itself for direct image links.
String? instantThumb(Uri u) {
  final y = youtubeId(u);
  if (y != null) return 'https://i.ytimg.com/vi/$y/hqdefault.jpg';
  if (kImageExt.contains(extOf(u.path)) && extOf(u.path) != 'svg') return u.toString();
  return null;
}

/// Splits pasted text into paragraphs (blank-line separated; falls back to lines).
List<String> paragraphsOf(String text) {
  final t = text.replaceAll('\r\n', '\n').trim();
  if (t.isEmpty) return const [];
  var parts = t.split(RegExp(r'\n\s*\n')).map((e) => e.replaceAll(RegExp(r'\s*\n\s*'), ' ').trim()).where((e) => e.isNotEmpty).toList();
  if (parts.length == 1 && t.contains('\n')) {
    parts = t.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  }
  return parts;
}
