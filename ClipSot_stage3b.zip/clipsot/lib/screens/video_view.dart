import 'package:flutter/material.dart';

import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'sheets.dart';

/// Dedicated view for saved videos. Opens the original in its own app/browser;
/// ClipSot never downloads or re-hosts video.
class VideoScreen extends StatefulWidget {
  final int id;
  const VideoScreen({super.key, required this.id});

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  final _note = TextEditingController();
  bool _init = false;

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final it = store.byId(widget.id);
    if (it == null) return Scaffold(backgroundColor: p.bg);
    if (!_init) {
      _note.text = it.note;
      _init = true;
    }

    return Scaffold(
      backgroundColor: p.bg,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.pop(context)),
                  RoundIcon(Icons.more_vert, label: 'More',
                      onTap: () => showItemActions(context, it.id,
                          onDeleted: () => Navigator.of(context).maybePop())),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(color: kSheetBg, borderRadius: BorderRadius.circular(28)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Thumbnail placeholder (real thumbnails arrive with metadata fetch).
                      Container(
                        height: 170,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xFFC9A574), Color(0xFF6E5A3C)],
                          ),
                        ),
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: const BoxDecoration(color: Color(0xFF171717), shape: BoxShape.circle),
                          child: const Icon(Icons.play_arrow, size: 30, color: Color(0xFFF4F3F0)),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'VIDEO${it.mins > 0 ? ' · ${it.mins} MIN' : ''} · ${it.savedLabel.toUpperCase()}',
                        style: ts(12, color: alpha(kSheetInk, .6), ls: .3),
                      ),
                      const SizedBox(height: 10),
                      Text(it.title, style: ts(32, w: FontWeight.w500, ls: -1.1, h: 1.05, color: kSheetInk)),
                      const SizedBox(height: 8),
                      Text(it.src, style: ts(14, color: const Color(0xFF777671))),
                      const SizedBox(height: 18),
                      SheetField(_note, 'Add a note'),
                      const SizedBox(height: 12),
                      SheetButton('Open original video', onTap: () => openExternal(context, it.url)),
                      const SizedBox(height: 10),
                      SheetButton(it.read ? 'Mark unwatched' : 'Mark watched',
                          primary: false, onTap: () => store.toggleRead(it)),
                      const SizedBox(height: 10),
                      SheetButton('Save note', primary: false, onTap: () {
                        store.setNote(it, _note.text.trim());
                        FocusScope.of(context).unfocus();
                        toast(context, 'Note saved');
                      }),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
