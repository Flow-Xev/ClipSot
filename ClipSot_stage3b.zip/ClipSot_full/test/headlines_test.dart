import 'dart:math';

import 'package:clipsot/headlines.dart';
import 'package:flutter_test/flutter_test.dart';

Headline _pick(Random r, {int total = 10, int unread = 3, int forgotten = 0, int inProgress = 0, String? last, DateTime? now}) =>
    pickHeadline(
      rng: r,
      now: now ?? DateTime(2026, 11, 18, 10), // a Wednesday morning
      total: total,
      unread: unread,
      forgotten: forgotten,
      inProgress: inProgress,
      lastId: last,
    );

void main() {
  test('never repeats the previous headline', () {
    final r = Random(1);
    String? last;
    for (var i = 0; i < 300; i++) {
      final h = _pick(r, last: last);
      expect(h.id, isNot(last));
      last = h.id;
    }
  });

  test('gives plenty of variety', () {
    final r = Random(7);
    final seen = <String>{};
    for (var i = 0; i < 400; i++) {
      seen.add(_pick(r, forgotten: 2, inProgress: 1).id);
    }
    expect(seen.length, greaterThan(20));
  });

  test('empty library only gets onboarding lines', () {
    final r = Random(3);
    for (var i = 0; i < 100; i++) {
      final h = _pick(r, total: 0, unread: 0);
      expect(h.id.startsWith('empty'), isTrue, reason: h.id);
    }
  });

  test('data lines only appear when they are true', () {
    final r = Random(5);
    for (var i = 0; i < 300; i++) {
      final h = _pick(r, unread: 0, forgotten: 0, inProgress: 0);
      expect(['unread', 'stack', 'forgot1', 'forgot2', 'progress'], isNot(contains(h.id)));
    }
  });

  test('unread count is spelled correctly', () {
    for (final n in [1, 4]) {
      final r = Random(0);
      for (var i = 0; i < 500; i++) {
        final h = _pick(r, unread: n);
        if (h.id == 'unread') {
          expect(h.lead, n == 1 ? 'One thing' : '$n things');
          expect(h.tail, n == 1 ? 'is waiting for you.' : 'are waiting for you.');
          break;
        }
      }
    }
  });

  test('late-night lines only at night', () {
    final r = Random(9);
    for (var i = 0; i < 300; i++) {
      final h = _pick(r, now: DateTime(2026, 11, 18, 14));
      expect(['late1', 'late2', 'am1', 'am2', 'eve1'], isNot(contains(h.id)));
    }
  });
}
