import 'dart:convert';

import 'package:clipsot/models.dart';
import 'package:clipsot/store.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<Store> _store() async {
  SharedPreferences.setMockInitialValues({
    'flutter.clipsot_v1': jsonEncode({'seeded': true, 'fetchText': false}),
  });
  return Store.load();
}

Item _item(String url) => Item.fromUrl(url, '', ['Reading List'])!
  ..progress = 0;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('addItem rejects duplicates and puts the newest first', () async {
    final s = await _store();
    expect(s.addItem(_item('https://a.com/1')), isTrue);
    expect(s.addItem(_item('https://a.com/1')), isFalse);
    s.addItem(Item.fromUrl('https://b.com/2', '', [])!);
    expect(s.items.length, 2);
    expect(s.items.first.src, 'b.com');
  });

  test('reminders are stored on the item and can be cleared', () async {
    final s = await _store();
    final it = _item('https://a.com/1');
    s.addItem(it);
    final when = DateTime.now().add(const Duration(days: 1));
    s.setRemind(it, when);
    expect(it.hasReminder, isTrue);
    s.setRemind(it, null);
    expect(it.hasReminder, isFalse);
  });

  test('continueList shows started, unfinished articles, newest first', () async {
    final s = await _store();
    final a = _item('https://a.com/1');
    final b = Item.fromUrl('https://b.com/2', '', [])!;
    final c = Item.fromUrl('https://c.com/3', '', [])!;
    for (final i in [a, b, c]) {
      s.addItem(i);
    }
    s.saveProgress(a, .4);
    s.saveProgress(b, .6);
    s.saveProgress(c, .99); // finished
    a.opened = 1;
    b.opened = 2;
    expect(s.continueList(5).map((e) => e.src), ['b.com', 'a.com']);
  });

  test('backup round-trip merges without duplicating', () async {
    final s = await _store();
    final it = _item('https://a.com/1')..note = 'keep me';
    s.addItem(it);
    s.saveNote(Note(id: 9, title: 'n', text: 'body'));
    final json = await s.exportBackup();

    final other = await _store();
    final r = await other.restoreBackup(json);
    expect(r!.items, 1);
    expect(r.notes, 1);
    expect(other.items.single.note, 'keep me');

    final again = await other.restoreBackup(json);
    expect(again!.items, 0);
    expect(again.notes, 0);
  });

  test('restore refuses files that are not ClipSot backups', () async {
    final s = await _store();
    expect(await s.restoreBackup('{"app":"Other"}'), isNull);
    expect(await s.restoreBackup('not json'), isNull);
  });

  test('surprise prefers unread items and honours except', () async {
    final s = await _store();
    final a = _item('https://a.com/1');
    final b = Item.fromUrl('https://b.com/2', '', [])!;
    s.addItem(a);
    s.addItem(b);
    s.toggleRead(a);
    expect(s.surprise()!.id, b.id);
    expect(s.surprise(except: b.id)!.id, a.id);
  });
}
