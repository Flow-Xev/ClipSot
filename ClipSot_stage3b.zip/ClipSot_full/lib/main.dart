import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'panel/panel_app.dart';
import 'screens/shell.dart';
import 'screens/splash.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
  ));
  final store = await Store.load();
  runApp(ClipSotApp(store: store));
}

/// Entry point of the transparent side-panel activity (see PanelActivity.kt).
@pragma('vm:entry-point')
Future<void> panelMain() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
  ));
  final store = await Store.load();
  runApp(PanelApp(store: store));
}

class ClipSotApp extends StatelessWidget {
  final Store store;
  const ClipSotApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return StoreScope(
      store: store,
      child: ListenableBuilder(
        listenable: store,
        builder: (_, __) => MaterialApp(
          title: 'ClipSot',
          debugShowCheckedModeBanner: false,
          themeMode: store.themeMode,
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          home: const _Root(),
        ),
      ),
    );
  }
}

class _Root extends StatefulWidget {
  const _Root();

  @override
  State<_Root> createState() => _RootState();
}

class _RootState extends State<_Root> {
  bool _done = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 600),
      child: _done
          ? const Shell(key: ValueKey('shell'))
          : Splash(key: const ValueKey('splash'), onDone: () => setState(() => _done = true)),
    );
  }
}
