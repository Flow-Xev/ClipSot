import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../haptics.dart';
import '../panel/link_utils.dart';
import '../panel/side_panel.dart' show showItemPanel, ReadAsSwitch;

import '../files.dart';
import '../models.dart';
import '../sources.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'notes.dart' show openNote;

Future<void> _sheet(BuildContext context, WidgetBuilder b) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: kSheetBg,
      barrierColor: const Color(0x8C000000),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: b,
    );

Future<void> showAddSheet(BuildContext context, {String? initial}) =>
    _sheet(context, (_) => AddSheet(initial: initial));

Future<void> showItemActions(BuildContext context, int id, {VoidCallback? onDeleted}) =>
    showItemPanel(context, id, onDeleted: onDeleted);

class _Grip extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(
        child: Container(
          width: 40,
          height: 4,
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: const Color(0xFFAAAAAA),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      );
}

class SheetField extends StatelessWidget {
  final TextEditingController c;
  final String hint;
  final bool autofocus;
  final TextInputType? type;
  final int maxLines;
  const SheetField(this.c, this.hint, {super.key, this.autofocus = false, this.type, this.maxLines = 1});

  @override
  Widget build(BuildContext context) => TextField(
        controller: c,
        autofocus: autofocus,
        keyboardType: maxLines > 1 ? TextInputType.multiline : type,
        minLines: 1,
        maxLines: maxLines,
        style: ts(15, color: kSheetInk),
        cursorColor: kSheetInk,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: ts(15, color: const Color(0xFF8A8984)),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.all(14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      );
}

class SheetButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool primary;
  const SheetButton(this.label, {super.key, required this.onTap, this.primary = true});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Tap(
      onTap: onTap,
      label: label,
      child: Container(
        height: 50,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: primary ? p.ac : const Color(0xFFCFCEC8),
          borderRadius: BorderRadius.circular(26),
        ),
        child: Text(label, style: ts(16, w: FontWeight.w500, color: kSheetInk)),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

/// Everything the Add flow can start.
enum AddKind { sheet, link, photos, camera, video, audio, file, html, comic, text, note }

Future<void> _addTextSheet(BuildContext context, List<String> cols) => _sheet(context, (_) => _TextSheet(cols: cols));

/// Runs one way of adding things. [context] must stay mounted while a picker is open
/// (use a context above the sheet).
Future<void> runAdd(BuildContext context, AddKind kind, {List<String> cols = const []}) async {
  switch (kind) {
    case AddKind.sheet:
    case AddKind.link:
      return showAddSheet(context);
    case AddKind.note:
      openNote(context);
      return;
    case AddKind.text:
      return _addTextSheet(context, cols);
    default:
      break;
  }
  final store = StoreScope.read(context);
  final m = ScaffoldMessenger.of(context);
  final p = P.of(context);
  try {
    final List<PlatformFile> files;
    if (kind == AddKind.camera) {
      final x = await ImagePicker().pickImage(source: ImageSource.camera);
      if (x == null) return;
      final it = await store.addFile(x.path, name: 'Photo ${DateTime.now().millisecondsSinceEpoch}.jpg', cols: cols, move: true);
      toastWith(m, p, it == null ? 'Couldn’t save that photo' : 'Photo saved');
      return;
    }
    final r = switch (kind) {
      AddKind.photos => await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.image),
      AddKind.video => await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.video),
      AddKind.audio => await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.audio),
      AddKind.html => await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.any),
      AddKind.comic => await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.any),
      _ => await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.any),
    };
    if (r == null) return;
    files = r.files;
    toastWith(m, p, files.length > 1 ? 'Saving ${files.length} files…' : 'Saving…');
    var ok = 0, bad = 0;
    for (final f in files) {
      final path = f.path;
      if (path == null) {
        bad++;
        continue;
      }
      // Picker copies live in the app cache, so they can be moved instead of copied twice.
      final it = await store.addFile(path, name: f.name, cols: cols, move: path.contains('/cache/'));
      it == null ? bad++ : ok++;
    }
    final msg = ok == 0
        ? 'Couldn’t read ${bad == 1 ? 'that file' : 'those files'}'
        : '${ok == 1 ? '1 saved' : '$ok saved'}${bad > 0 ? ', $bad couldn’t be read' : ''}';
    toastWith(m, p, msg);
  } catch (_) {
    toastWith(m, p, 'Couldn’t open the picker');
  }
}

class AddSheet extends StatefulWidget {
  final String? initial;
  const AddSheet({super.key, this.initial});

  @override
  State<AddSheet> createState() => _AddSheetState();
}

class _AddSheetState extends State<AddSheet> {
  late final TextEditingController _u = TextEditingController(text: widget.initial ?? '');
  final _n = TextEditingController();
  Set<String> _sel = {};
  bool _init = false;
  bool? _manga; // null = guess from the link
  bool? _copy; // null = default for this kind of link
  bool _busy = false;
  double _prog = 0;
  String _err = '';
  String? _clip; // a link found on the clipboard

  @override
  void initState() {
    super.initState();
    _u.addListener(() => setState(() => _err = ''));
    _peekClipboard();
  }

  Future<void> _peekClipboard() async {
    try {
      final d = await Clipboard.getData('text/plain');
      final l = extractLink(d?.text);
      if (mounted && l != null && _u.text.trim().isEmpty) setState(() => _clip = l);
    } catch (_) {}
  }

  List<String> get _links => extractAllLinks(_u.text);
  Item? get _guess => _links.length > 1 ? null : Item.fromUrl(_u.text, '', [], manga: _manga);

  bool _direct(Item it) => isDirectFileExt(extOf(Uri.tryParse(it.url)?.path ?? '')) && it.type != 'article';
  bool _wantCopy(Item it) => _copy ?? !it.isVideo;

  @override
  void dispose() {
    _u.dispose();
    _n.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final store = StoreScope.read(context);
    final cols = store.cols.where(_sel.contains).toList();
    final m = ScaffoldMessenger.of(context);
    final p = P.of(context);

    if (_links.length > 1) {
      final n = store.importLinks(_links.join(' '), cols: cols);
      Haptics.success();
      Navigator.pop(context);
      toastWith(m, p, n == 0 ? 'Those were already saved' : '$n links saved');
      return;
    }
    final it = Item.fromUrl(_u.text, _n.text, cols, manga: _manga);
    if (it == null) {
      Haptics.warning();
      setState(() => _err = 'That doesn’t look like a valid link.');
      return;
    }
    if (_direct(it) && _wantCopy(it)) {
      setState(() {
        _busy = true;
        _prog = 0;
      });
      final d = await store.addDownload(it.url, cols: cols, onProgress: (v) {
        if (mounted) setState(() => _prog = v);
      });
      if (d != null) {
        if (_n.text.trim().isNotEmpty) d.note = _n.text.trim();
        Haptics.success();
        if (!mounted) return;
        Navigator.pop(context);
        toastWith(m, p, 'Saved a copy to this device');
        return;
      }
      if (!mounted) return;
      setState(() => _busy = false);
      // Too big or not a plain file: keep the link instead.
    }
    final ok = store.addItem(it);
    if (ok) Haptics.success();
    Navigator.pop(context);
    toastWith(m, p, ok ? 'Saved' : 'Already saved');
  }

  void _use(String l) {
    Haptics.select();
    _clip = null;
    _u.text = l;
  }

  Widget _tile(IconData icon, String label, AddKind k) {
    return Tap(
      onTap: () {
        final cols = StoreScope.read(context).cols.where(_sel.contains).toList();
        final root = Navigator.of(context, rootNavigator: true).context;
        Navigator.pop(context);
        runAdd(root, k, cols: cols);
      },
      label: label,
      child: SizedBox(
        width: 72,
        child: Column(children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
            child: Icon(icon, size: 24, color: kSheetInk),
          ),
          const SizedBox(height: 6),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, color: kSheetInk)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    if (!_init) {
      _sel = {if (store.cols.contains(store.defaultCol)) store.defaultCol};
      _init = true;
    }
    final g = _guess;
    final site = g == null ? null : siteFor(g.src);
    final many = _links.length > 1;
    final label = g == null ? '' : switch (g.type) {
      'video' => 'Video',
      'audio' => 'Audio',
      'manga' => 'Manga',
      'document' => 'Document',
      _ => 'Article',
    };
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Grip(),
            Text('Save to ClipSot', style: ts(18, w: FontWeight.w500, color: kSheetInk)),
            const SizedBox(height: 2),
            Text('${(kSiteCount ~/ 10) * 10}+ sites and ${kAllExt.length}+ file types recognised',
                style: ts(12.5, color: const Color(0xFF777671))),
            const SizedBox(height: 12),
            if (_clip != null)
              Tap(
                onTap: () => _use(_clip!),
                label: 'Use the copied link',
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(color: P.of(context).ac, borderRadius: BorderRadius.circular(16)),
                  child: Row(children: [
                    const Icon(Icons.content_paste_go, size: 20, color: kSheetInk),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text('Use copied link\n$_clip',
                          maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(13.5, color: kSheetInk, h: 1.25)),
                    ),
                  ]),
                ),
              ),
            SheetField(_u, 'Paste one link, or many', type: TextInputType.url, maxLines: 4),
            SizedBox(
              height: 34,
              child: Row(children: [
                if (g != null)
                  Flexible(
                    child: Text('${site?.name ?? g.src} · $label',
                        maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, color: const Color(0xFF555450))),
                  )
                else if (many)
                  Text('${_links.length} links found', style: ts(13, color: const Color(0xFF555450))),
                const SizedBox(width: 10),
                Expanded(child: Text(_err, style: ts(13, color: kDanger), maxLines: 1, overflow: TextOverflow.ellipsis)),
              ]),
            ),
            if (g != null && (g.type == 'article' || g.type == 'manga')) ...[
              ReadAsSwitch(manga: g.isManga, onChanged: (v) => setState(() => _manga = v)),
              const SizedBox(height: 12),
            ],
            if (g != null && _direct(g)) ...[
              Row(children: [
                Expanded(
                  child: Text(g.isVideo ? 'Save a copy on this device (big files take space)' : 'Save a copy on this device',
                      style: ts(14, color: kSheetInk)),
                ),
                Switch(
                  value: _wantCopy(g),
                  activeColor: kSheetInk,
                  onChanged: (v) => setState(() => _copy = v),
                ),
              ]),
            ],
            if (store.askNote) ...[
              SheetField(_n, 'Add a note (optional)'),
              const SizedBox(height: 12),
            ],
            Text('Or add from this device', style: ts(13, color: const Color(0xFF777671))),
            const SizedBox(height: 10),
            Wrap(
              spacing: 6,
              runSpacing: 14,
              children: [
                _tile(Icons.photo_library_outlined, 'Photos', AddKind.photos),
                _tile(Icons.photo_camera_outlined, 'Camera', AddKind.camera),
                _tile(Icons.movie_outlined, 'Videos', AddKind.video),
                _tile(Icons.headphones_outlined, 'Audio', AddKind.audio),
                _tile(Icons.insert_drive_file_outlined, 'Files', AddKind.file),
                _tile(Icons.code, 'HTML page', AddKind.html),
                _tile(Icons.auto_stories_outlined, 'Comic file', AddKind.comic),
                _tile(Icons.notes, 'Paste text', AddKind.text),
                _tile(Icons.edit_note, 'Note', AddKind.note),
              ],
            ),
            const SizedBox(height: 18),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in store.cols)
                  Pill(c, sheet: true, on: _sel.contains(c), onTap: () {
                    setState(() => _sel.contains(c) ? _sel.remove(c) : _sel.add(c));
                  }),
              ],
            ),
            const SizedBox(height: 14),
            if (_busy)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 18),
                child: LinearProgressIndicator(
                  value: _prog > 0 ? _prog : null,
                  minHeight: 6,
                  color: kSheetInk,
                  backgroundColor: const Color(0xFFCFCEC8),
                ),
              )
            else
              SheetButton(many ? 'Save ${_links.length} links' : 'Save', onTap: _save),
          ],
        ),
      ),
    );
  }
}

/// Paste or type an article: it is stored as readable text, nothing is fetched.
class _TextSheet extends StatefulWidget {
  final List<String> cols;
  const _TextSheet({required this.cols});

  @override
  State<_TextSheet> createState() => _TextSheetState();
}

class _TextSheetState extends State<_TextSheet> {
  final _t = TextEditingController();
  final _b = TextEditingController();
  String _err = '';

  @override
  void dispose() {
    _t.dispose();
    _b.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData('text/plain');
    if (d?.text != null && mounted) setState(() => _b.text = d!.text!);
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Grip(),
            Text('Save an article from text', style: ts(18, w: FontWeight.w500, color: kSheetInk)),
            const SizedBox(height: 4),
            Text('Paste anything you want in the reader: an article, an email, a chapter.',
                style: ts(13, color: const Color(0xFF777671))),
            const SizedBox(height: 12),
            SheetField(_t, 'Title (optional)'),
            const SizedBox(height: 10),
            SheetField(_b, 'Paste or type the text', maxLines: 8, autofocus: true),
            SizedBox(
              height: 40,
              child: Row(children: [
                Tap(
                  onTap: _paste,
                  label: 'Paste from clipboard',
                  child: Row(children: [
                    const Icon(Icons.content_paste, size: 17, color: kSheetInk),
                    const SizedBox(width: 6),
                    Text('Paste', style: ts(13.5, color: kSheetInk)),
                  ]),
                ),
                const SizedBox(width: 14),
                Expanded(child: Text(_err, style: ts(13, color: kDanger))),
              ]),
            ),
            SheetButton('Save', onTap: () {
              final it = articleFromText(_t.text, _b.text, cols: widget.cols);
              if (it == null) {
                Haptics.warning();
                setState(() => _err = 'Add some text first.');
                return;
              }
              store.addReady(it);
              Haptics.success();
              final m = ScaffoldMessenger.of(context);
              final p = P.of(context);
              Navigator.pop(context);
              toastWith(m, p, 'Saved');
            }),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

/// Simple single-choice picker sheet.
Future<void> showChoice(
  BuildContext context, {
  required String title,
  required List<String> options,
  required String current,
  required ValueChanged<String> onPick,
}) =>
    _sheet(
      context,
      (_) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Grip(),
              Text(title, style: ts(18, w: FontWeight.w500, color: kSheetInk)),
              const SizedBox(height: 8),
              for (final o in options)
                Tap(
                  onTap: () {
                    onPick(o);
                    Navigator.pop(context);
                  },
                  label: o,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
                    child: Row(children: [
                      Expanded(child: Text(o, style: ts(16, color: kSheetInk))),
                      if (o == current) const Icon(Icons.check, size: 20, color: kSheetInk),
                    ]),
                  ),
                ),
            ],
          ),
        ),
      ),
    );

Future<void> showImportSheet(BuildContext context) => _sheet(context, (_) => const _ImportSheet());

class _ImportSheet extends StatefulWidget {
  const _ImportSheet();

  @override
  State<_ImportSheet> createState() => _ImportSheetState();
}

class _ImportSheetState extends State<_ImportSheet> {
  final _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Grip(),
            Text('Import links', style: ts(18, w: FontWeight.w500, color: kSheetInk)),
            const SizedBox(height: 4),
            Text('Paste links separated by spaces or new lines.',
                style: ts(13, color: const Color(0xFF777671))),
            const SizedBox(height: 12),
            TextField(
              controller: _c,
              minLines: 3,
              maxLines: 6,
              autofocus: true,
              style: ts(15, color: kSheetInk),
              cursorColor: kSheetInk,
              decoration: InputDecoration(
                hintText: 'https://\u2026',
                hintStyle: ts(15, color: const Color(0xFF8A8984)),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 14),
            SheetButton('Import', onTap: () {
              final n = store.importLinks(_c.text);
              final m = ScaffoldMessenger.of(context);
              final p = P.of(context);
              Navigator.pop(context);
              toastWith(m, p, n == 0 ? 'No new links found' : '$n imported');
            }),
          ],
        ),
      ),
    );
  }
}
