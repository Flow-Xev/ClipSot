# ClipSot (Flutter)

Save now. Find anytime. A private, offline-first personal library.

## v0.5: look and feel

- **Splash:** the C draws itself, the saved dot pops into its opening, then the wordmark follows.
- **Home:** a new headline every visit (time of day and library aware; tap it for another), a featured card that rotates
  between *pick up where you left off*, *from your archive* and *fresh*, quick stat tiles, a mixed card layout whose rhythm and
  colours change each visit, and a swipeable Rediscover row.
- The logo mark now appears on Home, Settings and the Splash.

## Status: Stage 3 complete (v0.4)

Stage 3b (this build) finishes everything that was marked "Not finished":

- **Article text + titles** are fetched when you save a link (Settings › Fetch article text, on by default), so the reader works.
  Use *Refresh article text* in the link panel to retry.
- **Images and PDFs** can be saved from the Save sheet, or shared from any app (Share › ClipSot). The Images and Documents chips are populated.
  Images open in a zoomable viewer; PDFs/documents open in your phone's viewer.
- **Continue reading**: reading position is remembered and a row appears on Home.
- **Backup and restore as a file** (Settings › Back up library / Restore from backup). Backups include saved files up to 8 MB each.
- Notifications and reminders are delivered (Stage 3a). Unit tests are in `test/`.

Still plain text only: Notes. Rich formatting is not built.

Stage 3a added:

- **Link side panel.** A panel that slides in from the right edge, over whatever app you are in.
  - In any app: long-press a link, tap *Share*, choose **ClipSot**.
  - Or select link text and choose **Save to ClipSot**.
  - It lets you pick collections, add a note, set a reminder, and copy, share or open the link.
  - Long-press any saved item inside ClipSot to open the same panel with its options.
- **Quick tiles.** *Save link* (reads the copied link) and *Surprise me* (picks something unread).
  Add them from Settings › Quick access, or from the Quick Settings editor. Long-press the app icon for the same two shortcuts.
- **Edge handle.** An optional slim tab on the screen edge that opens the panel. This is what the
  *Display over other apps* permission is used for.
- **Permissions screen** (Settings › Permissions): Notifications and Display over other apps, with status.
- **Real notifications** that look like the app (dark card, accent colour, `clipsot.` wordmark,
  Read now / Tomorrow / Done actions). Used for item reminders and optional rediscovery nudges.

## Run it

```bash
cd clipsot
./setup.sh          # Windows: powershell -ExecutionPolicy Bypass -File setup.ps1
flutter run
```

`setup.sh` generates the Android project once (`flutter create`), copies `android_overlay/` into it
(manifest, Kotlin, layouts, tiles) and sets minSdk to 26. Requires Flutter 3.22 or newer.
The application id is `com.clipsot.clipsot`; do not change `--org` or `--project-name`, the
Kotlin files use that package.

## Notes

- Sample articles are seeded only in **debug** builds. Release builds start empty.
- Pages that can't be read (paywalls, scripts-only sites) show an "Open original site" fallback in the reader.
- The font is Inter Tight via `google_fonts` (downloaded on first run, then cached).
  Bundle the font files as assets if you need guaranteed first-run offline typography.

## Brand

Logo files are in `brand/` (SVG + PNG): app icon, mark, wordmark, horizontal lockup, light and dark.
The launcher icon is an adaptive icon (with Android 13 themed-icon support) in
`android_overlay/.../res/mipmap-anydpi-v26/`, applied automatically by `setup.sh`.
Colours: background `#101010`, accent `#C9A574` (light theme `#A98250`), text `#F4F3F0`. Font: Inter Tight Medium.
