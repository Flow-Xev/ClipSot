import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'notes.dart';
import 'sheets.dart';

Future<void> showCollectionSheet(BuildContext context, {String? existing}) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: kSheetBg,
      barrierColor: const Color(0x8C000000),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => CollectionSheet(existing: existing),
    );

class CollectionsScreen extends StatefulWidget {
  const CollectionsScreen({super.key});

  @override
  State<CollectionsScreen> createState() => _CollectionsScreenState();
}

class _CollectionsScreenState extends State<CollectionsScreen> {
  final _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final q = _q.text.trim().toLowerCase();
    final names = ['All Items', ...store.cols].where((c) => c.toLowerCase().contains(q)).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 170),
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Collections', style: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx)),
              RoundIcon(Icons.add, label: 'New collection', onTap: () => showCollectionSheet(context)),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 18),
          child: SearchField(_q, 'Search collections…', onChanged: (_) => setState(() {})),
        ),
        if (q.isEmpty)
          _Tile(
            icon: Icons.edit_note,
            title: 'Notes',
            sub: '${store.notes.length} notes',
            accent: false,
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const NotesScreen())),
          ),
        for (var n = 0; n < names.length; n++)
          Padding(
            key: ValueKey(names[n]),
            padding: const EdgeInsets.only(bottom: 10),
            child: Rise(
              i: n,
              child: _Tile(
                icon: names[n] == 'All Items' ? Icons.apps : kIcons[store.iconOf(names[n]) % kIcons.length],
                title: names[n],
                sub: '${names[n] == 'All Items' ? store.items.length : store.countIn(names[n])} items',
                accent: false,
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => CollectionDetail(name: names[n])),
                ),
                onLong: kLockedCols.contains(names[n]) ? null : () => showCollectionSheet(context, existing: names[n]),
              ),
            ),
          ),
        if (names.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(child: Text('No collections match “${_q.text.trim()}”.', style: ts(14, color: p.tx2))),
          ),
        const SizedBox(height: 4),
        _Tile(
          icon: Icons.auto_awesome_outlined,
          title: 'Create a collection',
          sub: 'Organize your saves',
          accent: true,
          onTap: () => showCollectionSheet(context),
        ),
      ],
    );
  }
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String title, sub;
  final bool accent;
  final VoidCallback onTap;
  final VoidCallback? onLong;
  const _Tile({
    required this.icon,
    required this.title,
    required this.sub,
    required this.accent,
    required this.onTap,
    this.onLong,
  });

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    const ink = Color(0xFF171717);
    return Tap(
      onTap: onTap,
      label: title,
      child: GestureDetector(
        onLongPress: onLong,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: accent ? p.ac : p.s1, borderRadius: BorderRadius.circular(22)),
          child: Row(children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: accent ? Colors.transparent : p.card,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, size: 22, color: ink),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: ts(16, w: FontWeight.w500, color: accent ? ink : p.tx)),
                Text(sub, style: ts(13, color: accent ? alpha(ink, .7) : p.tx2)),
              ]),
            ),
            Icon(Icons.chevron_right, color: accent ? ink : p.tx),
          ]),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class CollectionDetail extends StatefulWidget {
  final String name;
  const CollectionDetail({super.key, required this.name});

  @override
  State<CollectionDetail> createState() => _CollectionDetailState();
}

class _CollectionDetailState extends State<CollectionDetail> {
  final _q = TextEditingController();
  late String _name = widget.name;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    // If the collection was deleted or renamed elsewhere, fall back gracefully.
    if (_name != 'All Items' && !store.cols.contains(_name)) {
      return Scaffold(backgroundColor: p.bg, body: const SizedBox());
    }
    final toks = tokens(_q.text);
    final list = store.itemsIn(_name).where((i) {
      if (toks.isEmpty) return true;
      final hay = '${i.title} ${i.src} ${i.url} ${i.note}'.toLowerCase();
      return toks.every(hay.contains);
    }).toList();
    final custom = !kLockedCols.contains(_name);

    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
            child: Row(children: [
              RoundIcon(Icons.arrow_back_ios_new, label: 'Back', onTap: () => Navigator.pop(context)),
              const SizedBox(width: 4),
              Expanded(child: Text(_name, style: ts(28, w: FontWeight.w500, ls: -.8, color: p.tx))),
              if (custom)
                RoundIcon(Icons.more_vert, label: 'Edit collection', onTap: () async {
                  final before = _name;
                  final idx = store.cols.indexOf(before);
                  final count = store.cols.length;
                  await showCollectionSheet(context, existing: before);
                  if (!mounted) return;
                  if (store.cols.contains(before)) return; // unchanged
                  if (store.cols.length == count && idx >= 0) {
                    setState(() => _name = store.cols[idx]); // renamed in place
                  } else {
                    Navigator.of(context).maybePop(); // deleted
                  }
                }),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
            child: SearchField(_q, 'Search in $_name…', onChanged: (_) => setState(() {})),
          ),
          Expanded(
            child: list.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.inbox_outlined, size: 44, color: p.tx2),
                        const SizedBox(height: 16),
                        Text(toks.isEmpty ? 'Empty collection' : 'No matches',
                            style: ts(22, w: FontWeight.w500, color: p.tx)),
                        const SizedBox(height: 8),
                        Text(
                          toks.isEmpty
                              ? 'Use “Add to collection” on any saved item.'
                              : 'Try a different word.',
                          textAlign: TextAlign.center,
                          style: ts(14, color: p.tx2),
                        ),
                      ]),
                    ),
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                    children: [for (final i in list) ItemRow(i, key: ValueKey(i.id), toks: toks)],
                  ),
          ),
        ]),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class CollectionSheet extends StatefulWidget {
  final String? existing;
  const CollectionSheet({super.key, this.existing});

  @override
  State<CollectionSheet> createState() => _CollectionSheetState();
}

class _CollectionSheetState extends State<CollectionSheet> {
  late final TextEditingController _n = TextEditingController(text: widget.existing ?? '');
  int _icon = 0;
  bool _init = false;
  String _err = '';

  @override
  void dispose() {
    _n.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = StoreScope.of(context);
    if (!_init) {
      _icon = widget.existing == null ? 0 : store.iconOf(widget.existing!);
      _init = true;
    }
    final editing = widget.existing != null;
    final p = P.of(context);

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(color: const Color(0xFFAAAAAA), borderRadius: BorderRadius.circular(2)),
              ),
            ),
            Text(editing ? 'Edit collection' : 'New collection',
                style: ts(18, w: FontWeight.w500, color: kSheetInk)),
            const SizedBox(height: 12),
            SheetField(_n, 'Name', autofocus: !editing),
            SizedBox(
              height: 26,
              child: Align(alignment: Alignment.centerLeft, child: Text(_err, style: ts(13, color: kDanger))),
            ),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (var i = 0; i < kIcons.length; i++)
                Tap(
                  onTap: () => setState(() => _icon = i),
                  label: 'Icon ${i + 1}',
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: i == _icon ? p.ac : kSheetChip,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(kIcons[i], size: 22, color: kSheetInk),
                  ),
                ),
            ]),
            const SizedBox(height: 16),
            SheetButton(editing ? 'Save' : 'Create', onTap: () {
              final err = editing
                  ? store.editCol(widget.existing!, _n.text, _icon)
                  : store.addCol(_n.text, _icon);
              if (err != null) {
                setState(() => _err = err);
                return;
              }
              final m = ScaffoldMessenger.of(context);
              Navigator.pop(context);
              toastWith(m, p, editing ? 'Collection updated' : 'Collection created');
            }),
            if (editing) ...[
              const SizedBox(height: 10),
              Tap(
                onTap: () async {
                  final m = ScaffoldMessenger.of(context);
                  final nav = Navigator.of(context);
                  final ok = await confirm(
                    context,
                    'Delete “${widget.existing}”?',
                    'Items stay in your library; they just leave this collection.',
                    'Delete',
                  );
                  if (!ok) return;
                  store.deleteCol(widget.existing!);
                  nav.pop();
                  toastWith(m, p, 'Collection deleted');
                },
                label: 'Delete collection',
                child: Container(
                  height: 50,
                  alignment: Alignment.center,
                  child: Text('Delete collection', style: ts(16, color: kDanger)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
