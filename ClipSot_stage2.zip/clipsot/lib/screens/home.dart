import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'notes.dart';
import 'reader.dart';
import 'sheets.dart';
import 'video_view.dart';

/// Opens an item in the right viewer and marks articles as read.
void openItem(BuildContext context, Item it) {
  final store = StoreScope.of(context);
  store.markOpened(it);
  Navigator.of(context).push(MaterialPageRoute<void>(
    builder: (_) => it.isVideo ? VideoScreen(id: it.id) : ReaderScreen(id: it.id),
  ));
}

class HomeScreen extends StatelessWidget {
  final VoidCallback onSearch;
  final VoidCallback onSettings;
  const HomeScreen({super.key, required this.onSearch, required this.onSettings});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final list = store.filtered;
    final forgot = store.forgottenList(2);
    final fresh = store.items.where((i) => !i.read && i.daysAgo <= 7).take(1).toList();
    final notesMode = store.filter == 'Notes';

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 160),
      children: [
        // Header
        Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('clipsot.', style: ts(34, w: FontWeight.w500, ls: -1.2, color: p.tx)),
              Row(children: [
                RoundIcon(Icons.search, onTap: onSearch, label: 'Search'),
                const SizedBox(width: 4),
                Tap(
                  onTap: onSettings,
                  label: 'Settings',
                  child: Container(
                    width: 38,
                    height: 38,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: p.ac, shape: BoxShape.circle),
                    child: Text('C', style: ts(15, w: FontWeight.w600, color: const Color(0xFF171717))),
                  ),
                ),
              ]),
            ],
          ),
        ),
        // Editorial heading
        Padding(
          padding: const EdgeInsets.only(top: 22, bottom: 20),
          child: Text.rich(
            TextSpan(children: [
              TextSpan(text: 'Your mind,\n', style: ts(36, ls: -1.4, h: 1.05, color: p.tx)),
              TextSpan(text: 'without the clutter.', style: ts(36, ls: -1.4, h: 1.05, color: p.tx2)),
            ]),
          ),
        ),
        // Filters
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.only(bottom: 16),
          child: Row(children: [
            for (final f in kFilters)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Pill(f, on: store.filter == f, onTap: () => store.setFilter(f)),
              ),
          ]),
        ),
        if (notesMode) ...[
          if (store.notes.isEmpty)
            _Empty(
              title: 'No notes yet',
              body: 'Capture a thought, or attach a note to anything you save.',
              action: 'Write a note',
              onAction: () => openNote(context),
            )
          else ...[
            for (final n in (List.of(store.notes)..sort((a, b) => b.updated.compareTo(a.updated))))
              NoteTile(note: n, key: ValueKey('hn${n.id}')),
          ],
        ] else if (store.items.isEmpty)
          _Empty(
            title: 'No saves yet',
            body: 'Start saving articles, videos and more to find them later.',
            action: 'Save something',
            onAction: () => showAddSheet(context),
          )
        else if (list.isEmpty)
          _Empty(title: 'Nothing here', body: 'No ${store.filter.toLowerCase()} items yet.')
        else
          _Masonry(items: list),
        if (store.filter == 'All' && store.items.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.only(top: 22, bottom: 12),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Rediscover', style: ts(15, w: FontWeight.w500, color: p.tx)),
              Tap(
                onTap: () {
                  final r = store.randomItem();
                  if (r != null) openItem(context, r);
                },
                label: 'Surprise me',
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Text('Surprise me', style: ts(13, color: p.ac)),
                ),
              ),
            ]),
          ),
          for (final f in forgot)
            _RediscoverRow(item: f, sub: 'Saved ${f.daysAgo} days ago, still unread'),
          for (final f in fresh)
            _RediscoverRow(item: f, sub: 'Recently saved, not opened yet'),
        ],
      ],
    );
  }
}

class _Empty extends StatelessWidget {
  final String title, body;
  final String? action;
  final VoidCallback? onAction;
  const _Empty({required this.title, required this.body, this.action, this.onAction});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 20),
      child: Column(children: [
        Container(
          width: 110,
          height: 110,
          decoration: BoxDecoration(color: p.s1, shape: BoxShape.circle),
          child: Icon(Icons.bookmark_border, size: 44, color: p.tx),
        ),
        const SizedBox(height: 24),
        Text(title, style: ts(22, w: FontWeight.w500, color: p.tx)),
        const SizedBox(height: 8),
        Text(body, textAlign: TextAlign.center, style: ts(14, color: p.tx2)),
        if (action != null) ...[
          const SizedBox(height: 24),
          Tap(
            onTap: onAction,
            label: action,
            child: Container(
              height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 28),
              alignment: Alignment.center,
              decoration: BoxDecoration(color: p.ac, borderRadius: BorderRadius.circular(26)),
              child: Text(action!, style: ts(16, w: FontWeight.w500, color: const Color(0xFF171717))),
            ),
          ),
        ],
      ]),
    );
  }
}

/// Two-column staggered grid (no extra package needed).
class _Masonry extends StatelessWidget {
  final List<Item> items;
  const _Masonry({required this.items});

  @override
  Widget build(BuildContext context) {
    final left = <Widget>[], right = <Widget>[];
    for (var i = 0; i < items.length; i++) {
      final w = Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Rise(key: ValueKey('c${items[i].id}'), i: i, child: ItemCard(item: items[i], variant: i % 4)),
      );
      (i.isEven ? left : right).add(w);
    }
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(child: Column(children: left)),
        const SizedBox(width: 10),
        Expanded(child: Column(children: right)),
      ],
    );
  }
}

/// variant: 0 light card, 1 image card, 2 accent, 3 dark.
class ItemCard extends StatelessWidget {
  final Item item;
  final int variant;
  const ItemCard({super.key, required this.item, required this.variant});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final it = item;

    if (variant == 1) {
      return Tap(
        onTap: () => openItem(context, it),
        label: it.title,
        child: Container(
          constraints: const BoxConstraints(minHeight: 150),
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
          alignment: Alignment.bottomLeft,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF6B6B69), Color(0xFF2A2A2A)],
              stops: [0, 0.7],
            ),
          ),
          child: Text(it.title,
              style: ts(15, w: FontWeight.w500, color: Colors.white, h: 1.2)),
        ),
      );
    }

    final bg = variant == 0 ? p.card : (variant == 2 ? p.ac : p.s1);
    final fg = variant == 3 ? p.tx : const Color(0xFF171717);
    final meta = it.isVideo
        ? (it.mins > 0 ? '${it.mins} min' : 'Video')
        : (it.mins > 0 ? '${it.mins} min read' : it.src);

    return Tap(
      onTap: () => openItem(context, it),
      label: it.title,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(22)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(it.savedLabel, style: ts(11.5, color: alpha(fg, .6))),
            const SizedBox(height: 10),
            Text(it.title, style: ts(19, w: FontWeight.w500, ls: -.4, h: 1.15, color: fg)),
            const SizedBox(height: 22),
            Row(children: [
              if (it.isVideo) ...[
                Container(
                  width: 26,
                  height: 26,
                  decoration: const BoxDecoration(color: Color(0xFF171717), shape: BoxShape.circle),
                  child: const Icon(Icons.play_arrow, size: 16, color: Color(0xFFF4F3F0)),
                ),
                const SizedBox(width: 6),
              ],
              Flexible(
                child: Text(meta,
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: ts(12, color: alpha(fg, .6))),
              ),
              if (!it.read) ...[
                const SizedBox(width: 6),
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(color: p.ac, shape: BoxShape.circle),
                ),
              ],
            ]),
          ],
        ),
      ),
    );
  }
}

class _RediscoverRow extends StatelessWidget {
  final Item item;
  final String sub;
  const _RediscoverRow({required this.item, required this.sub});

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Tap(
        onTap: () => openItem(context, item),
        label: 'Rediscover ${item.title}',
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: p.s1, borderRadius: BorderRadius.circular(22)),
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(item.title, style: ts(16, w: FontWeight.w500, color: p.tx)),
                const SizedBox(height: 2),
                Text(sub, style: ts(13, color: p.tx2)),
              ]),
            ),
            Icon(Icons.chevron_right, color: p.tx),
          ]),
        ),
      ),
    );
  }
}
