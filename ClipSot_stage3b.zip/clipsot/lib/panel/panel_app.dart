import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../native.dart';
import '../store.dart';
import '../theme.dart';
import 'side_panel.dart';

/// Root of the transparent panel activity that Android shows on top of other
/// apps (share target, selected-text action, quick tiles, edge handle).
class PanelApp extends StatelessWidget {
  final Store store;
  const PanelApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    ThemeData t(Brightness b) => buildTheme(b).copyWith(scaffoldBackgroundColor: Colors.transparent);
    return StoreScope(
      store: store,
      child: ListenableBuilder(
        listenable: store,
        builder: (_, __) => MaterialApp(
          title: 'ClipSot',
          debugShowCheckedModeBanner: false,
          themeMode: store.themeMode,
          theme: t(Brightness.light),
          darkTheme: t(Brightness.dark),
          home: const _PanelRoot(),
        ),
      ),
    );
  }
}

class _PanelRoot extends StatefulWidget {
  const _PanelRoot();

  @override
  State<_PanelRoot> createState() => _PanelRootState();
}

class _PanelRootState extends State<_PanelRoot> {
  Map<String, dynamic>? _p;
  int _serial = 0;

  @override
  void initState() {
    super.initState();
    Native.listen(_onPayload);
    Native.launch().then(_onPayload);
  }

  Future<void> _onPayload(Map<String, dynamic> p) async {
    // Another share arrived while the panel is open: reload and re-render.
    await StoreScope.read(context).reload();
    if (p['mode'] == 'clipboard') {
      // Android lets an app read the clipboard once its window has focus.
      await Future<void>.delayed(const Duration(milliseconds: 180));
      final d = await Clipboard.getData('text/plain');
      p = {...p, 'text': d?.text};
    }
    if (!mounted) return;
    setState(() {
      _p = p;
      _serial++;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    if (p == null) return const SizedBox.expand();
    return SidePanelFrame(
      key: ValueKey(_serial),
      onClosed: Native.finish,
      builder: (ctl) {
        if (p['mode'] == 'surprise') return _Surprise(ctl: ctl);
        if (p['mode'] == 'file' && p['file'] is String) {
          return FilePanel(path: p['file'] as String, name: (p['fileName'] ?? 'file') as String, ctl: ctl);
        }
        return SavePanel(
          text: p['text'] as String?,
          subject: p['subject'] as String?,
          ctl: ctl,
          fromOutside: true,
        );
      },
    );
  }
}

class _Surprise extends StatefulWidget {
  final PanelCtl ctl;
  const _Surprise({required this.ctl});

  @override
  State<_Surprise> createState() => _SurpriseState();
}

class _SurpriseState extends State<_Surprise> {
  int? _id;

  @override
  void initState() {
    super.initState();
    _id = StoreScope.read(context).surprise()?.id;
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final id = _id;
    if (id == null) {
      return EmptyPanel(
        ctl: widget.ctl,
        title: 'Nothing saved yet',
        body: 'Save a few links first, then Surprise me will pick one for you.',
      );
    }
    return ItemPanel(
      key: ValueKey(id),
      id: id,
      ctl: widget.ctl,
      onOpen: (it) => Native.openMain(itemId: it.id),
      onShuffle: () => setState(() => _id = s.surprise(except: id)?.id ?? id),
    );
  }
}
