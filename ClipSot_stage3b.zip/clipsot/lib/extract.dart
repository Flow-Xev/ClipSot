import 'dart:convert';

import 'package:http/http.dart' as http;

/// Title + readable text pulled from a web page.
class Extracted {
  final String? title;
  final List<String>? body;
  final int mins;
  const Extracted({this.title, this.body, this.mins = 0});
}

/// Downloads [url] and extracts readable text. Returns null when the page can't be read.
/// Only the page itself is requested; nothing else is contacted.
Future<Extracted?> fetchReadable(String url) async {
  try {
    final u = Uri.parse(url);
    if (!u.hasScheme || !(u.scheme == 'http' || u.scheme == 'https')) return null;
    final res = await http.get(u, headers: {
      'User-Agent': 'Mozilla/5.0 (Android) ClipSot/0.4',
      'Accept': 'text/html,application/xhtml+xml',
    }).timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return null;
    final type = res.headers['content-type'] ?? '';
    if (type.isNotEmpty && !type.contains('html')) return null;
    final html = utf8.decode(res.bodyBytes, allowMalformed: true);
    final video = RegExp(r'youtube|youtu\.be|vimeo').hasMatch(u.host);
    return parseReadable(html, titleOnly: video);
  } catch (_) {
    return null;
  }
}

String _decode(String s) {
  const named = {
    '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'", '&apos;': "'",
    '&nbsp;': ' ', '&rsquo;': '\u2019', '&lsquo;': '\u2018', '&ldquo;': '\u201C',
    '&rdquo;': '\u201D', '&ndash;': '\u2013', '&mdash;': '\u2014', '&hellip;': '\u2026',
  };
  var out = s;
  named.forEach((k, v) => out = out.replaceAll(k, v));
  out = out.replaceAllMapped(RegExp(r'&#(\d+);'), (m) {
    final c = int.tryParse(m.group(1)!);
    return c == null || c > 0x10FFFF ? '' : String.fromCharCode(c);
  });
  out = out.replaceAllMapped(RegExp(r'&#x([0-9a-fA-F]+);'), (m) {
    final c = int.tryParse(m.group(1)!, radix: 16);
    return c == null || c > 0x10FFFF ? '' : String.fromCharCode(c);
  });
  return out;
}

String _text(String html) =>
    _decode(html.replaceAll(RegExp(r'<[^>]+>'), ' ')).replaceAll(RegExp(r'\s+'), ' ').trim();

String? _meta(String html, String prop) {
  final a = RegExp('<meta[^>]+(?:property|name)=["\']$prop["\'][^>]*content=["\']([^"\']*)["\']', caseSensitive: false)
      .firstMatch(html);
  final b = RegExp('<meta[^>]+content=["\']([^"\']*)["\'][^>]*(?:property|name)=["\']$prop["\']', caseSensitive: false)
      .firstMatch(html);
  final v = a?.group(1) ?? b?.group(1);
  return v == null || v.trim().isEmpty ? null : _decode(v).trim();
}

/// Pure HTML -> readable text. Public so it can be unit tested.
Extracted parseReadable(String html, {bool titleOnly = false}) {
  var title = _meta(html, 'og:title') ?? _meta(html, 'twitter:title');
  title ??= () {
    final m = RegExp(r'<title[^>]*>(.*?)</title>', caseSensitive: false, dotAll: true).firstMatch(html);
    final t = m == null ? '' : _text(m.group(1)!);
    return t.isEmpty ? null : t;
  }();
  if (title != null && title.length > 160) title = '${title.substring(0, 157)}...';
  if (titleOnly) return Extracted(title: title);

  var h = html;
  for (final tag in ['script', 'style', 'noscript', 'svg', 'nav', 'header', 'footer', 'aside', 'form', 'iframe']) {
    h = h.replaceAll(RegExp('<$tag[\\s>].*?</$tag>', caseSensitive: false, dotAll: true), ' ');
  }
  h = h.replaceAll(RegExp(r'<!--.*?-->', dotAll: true), ' ');
  final scope = RegExp(r'<article[\s>].*?</article>', caseSensitive: false, dotAll: true).firstMatch(h)?.group(0) ??
      RegExp(r'<main[\s>].*?</main>', caseSensitive: false, dotAll: true).firstMatch(h)?.group(0) ??
      h;

  final paras = <String>[];
  for (final m in RegExp(r'<(p|blockquote)[^>]*>(.*?)</\1>', caseSensitive: false, dotAll: true).allMatches(scope)) {
    final t = _text(m.group(2)!);
    if (t.length < 40) continue;
    paras.add(m.group(1)!.toLowerCase() == 'blockquote' ? 'Q:$t' : t);
    if (paras.length >= 150) break;
  }
  final words = paras.fold<int>(0, (a, p) => a + p.split(' ').length);
  if (words < 80) return Extracted(title: title);
  return Extracted(title: title, body: paras, mins: (words / 220).round().clamp(1, 999));
}
