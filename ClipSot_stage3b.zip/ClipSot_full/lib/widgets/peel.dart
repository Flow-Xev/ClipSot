import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../haptics.dart';
import '../theme.dart';

/// Lets any screen ask "peel away whatever is showing for this item".
/// Rows register themselves while they are on screen.
class PeelRegistry {
  PeelRegistry._();
  static final Map<int, List<PeelItemState>> _m = {};

  static void _add(int id, PeelItemState s) => (_m[id] ??= []).add(s);

  static void _remove(int id, PeelItemState s) {
    final l = _m[id];
    if (l == null) return;
    l.remove(s);
    if (l.isEmpty) _m.remove(id);
  }

  /// The newest row for [id] that is actually visible right now (not on a
  /// hidden tab and not covered by another screen).
  static PeelItemState? of(int id) {
    final l = _m[id];
    if (l == null) return null;
    for (final s in l.reversed) {
      if (s.canPeel) return s;
    }
    return null;
  }
}

/// Wraps a row/card so it can be peeled away like a sheet of paper.
/// Without a call to [PeelItemState.peel] it is completely transparent.
class PeelItem extends StatefulWidget {
  /// Use the item id (or the negative note id) so it can be found again.
  final int id;
  final Widget child;
  const PeelItem({super.key, required this.id, required this.child});

  @override
  State<PeelItem> createState() => PeelItemState();
}

class PeelItemState extends State<PeelItem> {
  final _boundary = GlobalKey();
  bool _hidden = false;
  bool _collapsed = false;

  @override
  void initState() {
    super.initState();
    PeelRegistry._add(widget.id, this);
  }

  @override
  void didUpdateWidget(PeelItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.id != widget.id) {
      PeelRegistry._remove(oldWidget.id, this);
      PeelRegistry._add(widget.id, this);
    }
  }

  @override
  void dispose() {
    PeelRegistry._remove(widget.id, this);
    super.dispose();
  }

  /// True when this row is on the screen the person is looking at.
  bool get canPeel {
    if (!mounted || _hidden || _collapsed) return false;
    if (!TickerMode.valuesOf(context).enabled) return false;
    final route = ModalRoute.of(context);
    if (route != null && !route.isCurrent) return false;
    final ro = _boundary.currentContext?.findRenderObject();
    return ro is RenderRepaintBoundary && ro.attached && ro.hasSize;
  }

  /// Shrinks the row away without the paper effect (used for "Restore").
  Future<void> collapse() async {
    if (!mounted) return;
    setState(() => _collapsed = true);
    await Future<void>.delayed(const Duration(milliseconds: 300));
  }

  /// Plays the peel: the paper curls off from its corner, balls up and drops
  /// into a little bin. Resolves when the animation is over. Returns false when
  /// it could not play (reduced motion, off screen), so the caller just deletes.
  Future<bool> peel() async {
    if (!canPeel) return false;
    if (MediaQuery.disableAnimationsOf(context)) return false;
    final ro = _boundary.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final overlay = Overlay.maybeOf(context, rootOverlay: true);
    if (overlay == null) return false;

    final size = ro.size;
    final origin = ro.localToGlobal(Offset.zero);
    final dpr = MediaQuery.devicePixelRatioOf(context).clamp(1.0, 2.5).toDouble();
    final screen = MediaQuery.sizeOf(context);
    final safeBottom = MediaQuery.paddingOf(context).bottom;
    final pal = P.of(context);

    ui.Image img;
    try {
      img = await ro.toImage(pixelRatio: dpr);
    } catch (_) {
      return false;
    }
    if (!mounted) {
      img.dispose();
      return false;
    }

    setState(() => _hidden = true);
    final done = Completer<void>();
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => _PeelOverlay(
        image: img,
        rect: origin & size,
        screen: screen,
        safeBottom: safeBottom,
        pal: pal,
        onCollapse: () {
          if (mounted) setState(() => _collapsed = true);
        },
        onDone: () {
          entry.remove();
          img.dispose();
          if (!done.isCompleted) done.complete();
        },
      ),
    );
    overlay.insert(entry);
    await done.future;
    return true;
  }

  @override
  Widget build(BuildContext context) => AnimatedSize(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeInOutCubic,
        alignment: Alignment.topCenter,
        child: _collapsed
            ? const SizedBox(width: double.infinity, height: 0)
            : Visibility(
                visible: !_hidden,
                maintainSize: true,
                maintainState: true,
                maintainAnimation: true,
                child: RepaintBoundary(key: _boundary, child: widget.child),
              ),
      );
}

// ---------------------------------------------------------------------------

/// Timeline of the whole effect (0..1 over [kPeelMs]).
const kPeelMs = 1400;
const _tPeelEnd = .42; // paper is fully off its corner
const _tLand = .80; // paper reaches the bin
const _tLidShut = .92;

double _seg(double t, double a, double b) => ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

class _PeelOverlay extends StatefulWidget {
  final ui.Image image;
  final Rect rect;
  final Size screen;
  final double safeBottom;
  final P pal;
  final VoidCallback onCollapse;
  final VoidCallback onDone;
  const _PeelOverlay({
    required this.image,
    required this.rect,
    required this.screen,
    required this.safeBottom,
    required this.pal,
    required this.onCollapse,
    required this.onDone,
  });

  @override
  State<_PeelOverlay> createState() => _PeelOverlayState();
}

class _PeelOverlayState extends State<_PeelOverlay> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: kPeelMs));
  bool _collapsed = false, _landed = false, _shut = false;

  @override
  void initState() {
    super.initState();
    Haptics.peel();
    _c.addListener(_tick);
    _c.forward().whenComplete(widget.onDone);
  }

  void _tick() {
    final t = _c.value;
    if (!_collapsed && t >= _tPeelEnd) {
      _collapsed = true;
      widget.onCollapse();
    }
    if (!_landed && t >= _tLand) {
      _landed = true;
      Haptics.thud();
    }
    if (!_shut && t >= _tLidShut) {
      _shut = true;
      Haptics.lid();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: SizedBox.expand(
          child: CustomPaint(
            painter: _PeelPainter(
              c: _c,
              image: widget.image,
              rect: widget.rect,
              safeBottom: widget.safeBottom,
              pal: widget.pal,
            ),
          ),
        ),
      );
}

class _PeelPainter extends CustomPainter {
  final AnimationController c;
  final ui.Image image;
  final Rect rect;
  final double safeBottom;
  final P pal;

  _PeelPainter({
    required this.c,
    required this.image,
    required this.rect,
    required this.safeBottom,
    required this.pal,
  }) : super(repaint: c);

  static const _paper = Color(0xFFEFEBE2);

  @override
  void paint(Canvas canvas, Size size) {
    final t = c.value;
    final w = rect.width, h = rect.height;
    final diag = math.sqrt(w * w + h * h);

    // The bin, bottom centre of the screen.
    final binBase = Offset(size.width / 2, size.height - safeBottom - 26);
    const binH = 70.0;
    final binIn = Curves.easeOutBack.transform(_seg(t, .10, .34));
    final binOut = Curves.easeIn.transform(_seg(t, .93, 1.0));
    final binDy = (1 - binIn) * 150 + binOut * 150;
    final lidOpen = Curves.easeOutCubic.transform(_seg(t, .30, .52)) *
        (1 - Curves.easeInCubic.transform(_seg(t, .84, _tLidShut)));
    final mouth = Offset(binBase.dx, binBase.dy + binDy - binH);

    // --- the paper ----------------------------------------------------------
    // Peel runs from the top-right corner toward the bottom-left corner.
    final d = Offset(-w, h) / diag;
    final corner = Offset(w, 0);
    final srcRect = Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble());
    final dstRect = Rect.fromLTWH(0, 0, w, h);

    if (t < _tPeelEnd) {
      final p = Curves.easeInOutCubic.transform(t / _tPeelEnd);
      final s = diag * p;
      canvas.save();
      canvas.translate(rect.left, rect.top);
      _peelPass(canvas, srcRect, dstRect, d, corner, s, diag, p);
      canvas.restore();
    } else {
      final q = _seg(t, _tPeelEnd, _tLand);
      final e = Curves.easeInOutCubic.transform(q);
      // After the full peel the paper lies mirrored across the far corner.
      final center = Offset(w / 2, h / 2);
      final proj = (center - corner).dx * d.dx + (center - corner).dy * d.dy;
      final c0 = center - d * (2 * (proj - diag));
      final c0s = rect.topLeft + c0;

      final target = Offset(mouth.dx, mouth.dy + 6 + 22 * _seg(q, .82, 1));
      final pos = Offset.lerp(c0s, target, e)! + Offset(0, -math.sin(math.pi * e) * 70);
      final ball = 50.0 * (1 - .15 * e);
      final sx = ui.lerpDouble(1, ball / w, Curves.easeIn.transform(e))!;
      final sy = ui.lerpDouble(1, ball / h, Curves.easeIn.transform(e))!;
      final crumple = Curves.easeIn.transform(_seg(q, .12, .85));
      final angle = -e * 1.4;

      canvas.save();
      canvas.translate(pos.dx, pos.dy);
      canvas.rotate(angle);
      canvas.scale(sx, sy);
      canvas.translate(-c0.dx, -c0.dy);
      canvas.transform(_reflection(d, corner, diag));

      final local = dstRect;
      final clip = RRect.fromRectXY(local, w / 2 * crumple, h / 2 * crumple);
      // soft shadow under the flying paper
      canvas.drawRRect(
        clip.shift(Offset(0, 8 / math.max(sy, .05))),
        Paint()
          ..color = const Color(0x40000000)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );
      canvas.save();
      canvas.clipRRect(clip);
      canvas.drawImageRect(
        image,
        srcRect,
        dstRect,
        Paint()
          ..filterQuality = FilterQuality.medium
          ..colorFilter = ColorFilter.mode(_paper.withAlpha(215), BlendMode.srcATop),
      );
      if (crumple > 0) {
        // a balled-up look: shaded edges
        canvas.drawRRect(
          clip,
          Paint()
            ..shader = ui.Gradient.radial(
              local.center,
              math.max(w, h) / 2,
              [const Color(0x00000000), Color.fromRGBO(0, 0, 0, .38 * crumple)],
              const [.45, 1],
            ),
        );
      }
      canvas.restore();
      canvas.restore();
    }

    // --- the bin (drawn after the paper so the paper drops *into* it) -------
    if (t > .08 && binOut < 1) {
      final a = (1 - binOut);
      TrashBinPainter.paintBin(
        canvas,
        base: Offset(binBase.dx, binBase.dy + binDy),
        height: binH,
        lid: lidOpen,
        body: pal.ac,
        opacity: a,
      );
    }
  }

  void _peelPass(Canvas canvas, Rect src, Rect dst, Offset d, Offset corner, double s, double diag, double p) {
    final n = Offset(-d.dy, d.dx);
    final fold = corner + d * s;
    final big = diag * 3;
    Path half(double side) => Path()
      ..moveTo(fold.dx + n.dx * big, fold.dy + n.dy * big)
      ..lineTo(fold.dx - n.dx * big, fold.dy - n.dy * big)
      ..lineTo(fold.dx - n.dx * big + d.dx * big * side, fold.dy - n.dy * big + d.dy * big * side)
      ..lineTo(fold.dx + n.dx * big + d.dx * big * side, fold.dy + n.dy * big + d.dy * big * side)
      ..close();

    final front = half(1); // still attached
    final gone = half(-1); // lifted
    final angle = math.atan2(d.dy, d.dx);

    // attached part + shadow cast by the lifted paper
    canvas.save();
    canvas.clipPath(front);
    canvas.drawImageRect(image, src, dst, Paint()..filterQuality = FilterQuality.medium);
    canvas.save();
    canvas.translate(fold.dx, fold.dy);
    canvas.rotate(angle);
    canvas.drawRect(
      Rect.fromLTRB(0, -big, 38, big),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset.zero,
          const Offset(38, 0),
          [Color.fromRGBO(0, 0, 0, .42 * (1 - p * .4)), const Color(0x00000000)],
        ),
    );
    canvas.restore();
    canvas.restore();

    if (s < 1) return;
    // the lifted flap: the removed part, mirrored over the fold, showing the
    // paper's back (a faint ghost of the print)
    canvas.save();
    canvas.clipPath(front);
    canvas.transform(_reflection(d, corner, s));
    canvas.clipPath(gone);
    canvas.clipRect(dst);
    canvas.drawImageRect(
      image,
      src,
      dst,
      Paint()
        ..filterQuality = FilterQuality.medium
        ..colorFilter = ColorFilter.mode(_paper.withAlpha(215), BlendMode.srcATop),
    );
    // curl highlight near the fold
    canvas.translate(fold.dx, fold.dy);
    canvas.rotate(angle);
    canvas.drawRect(
      Rect.fromLTRB(-46, -big, 0, big),
      Paint()
        ..shader = ui.Gradient.linear(
          const Offset(-46, 0),
          Offset.zero,
          [const Color(0x00FFFFFF), const Color(0x66FFFFFF)],
        ),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(_PeelPainter old) => old.image != image || old.rect != rect;
}

/// Reflection across the line perpendicular to [d] that passes through
/// [corner] + d * [s], as a column-major 4x4 matrix.
Float64List _reflection(Offset d, Offset corner, double s) {
  final a = 1 - 2 * d.dx * d.dx;
  final b = -2 * d.dx * d.dy;
  final dd = 1 - 2 * d.dy * d.dy;
  final k = 2 * ((corner.dx * d.dx + corner.dy * d.dy) + s);
  final tx = k * d.dx, ty = k * d.dy;
  return Float64List.fromList([
    a, b, 0, 0, //
    b, dd, 0, 0, //
    0, 0, 1, 0, //
    tx, ty, 0, 1,
  ]);
}

// ---------------------------------------------------------------------------

/// The little bin. Used in the peel animation and on the Trash screen.
class TrashBinPainter extends CustomPainter {
  final double lid; // 0 closed .. 1 open
  final Color body;
  final double fill; // 0 empty .. 1 full (paper sticking out)
  const TrashBinPainter({required this.lid, required this.body, this.fill = 0});

  @override
  void paint(Canvas canvas, Size size) {
    paintBin(
      canvas,
      base: Offset(size.width / 2, size.height - 4),
      height: size.height - 22,
      lid: lid,
      body: body,
      fill: fill,
    );
  }

  /// [base] is the bottom-centre of the bin.
  static void paintBin(
    Canvas canvas, {
    required Offset base,
    required double height,
    required double lid,
    required Color body,
    double opacity = 1,
    double fill = 0,
  }) {
    final k = height / 70;
    final topW = 62 * k, botW = 50 * k;
    final top = base.dy - height;
    Color o(Color c, [double a = 1]) => c.withAlpha((255 * a * opacity).round().clamp(0, 255));

    // ground shadow
    canvas.drawOval(
      Rect.fromCenter(center: Offset(base.dx, base.dy + 2 * k), width: botW * 1.5, height: 8 * k),
      Paint()
        ..color = o(Colors.black, .22)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 5 * k),
    );

    if (fill > 0) {
      // crumpled paper peeking out of the top
      final paper = Paint()..color = o(const Color(0xFFEFEBE2));
      canvas.drawCircle(Offset(base.dx - 8 * k, top + 2 * k), 9 * k * fill, paper);
      canvas.drawCircle(Offset(base.dx + 7 * k, top + 1 * k), 7 * k * fill, paper);
    }

    final path = Path()
      ..moveTo(base.dx - topW / 2, top)
      ..lineTo(base.dx + topW / 2, top)
      ..lineTo(base.dx + botW / 2, base.dy)
      ..lineTo(base.dx - botW / 2, base.dy)
      ..close();
    canvas.drawPath(path, Paint()..color = o(body));
    // ridges
    final ridge = Paint()
      ..color = o(Colors.black, .22)
      ..strokeWidth = 2.2 * k
      ..strokeCap = StrokeCap.round;
    for (final f in [-.28, 0.0, .28]) {
      canvas.drawLine(
        Offset(base.dx + topW * f, top + 12 * k),
        Offset(base.dx + botW * f, base.dy - 8 * k),
        ridge,
      );
    }

    // lid: hinged on its left end, swings up and back
    canvas.save();
    final hinge = Offset(base.dx - topW / 2 - 3 * k, top);
    canvas.translate(hinge.dx, hinge.dy);
    canvas.rotate(-lid * 1.25);
    final lidW = topW + 6 * k;
    final lidPaint = Paint()..color = o(Color.lerp(body, Colors.black, .12)!);
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(0, -8 * k, lidW, 8 * k), Radius.circular(4 * k)),
      lidPaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(lidW / 2 - 11 * k, -13 * k, 22 * k, 6 * k),
        Radius.circular(3 * k),
      ),
      lidPaint,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(TrashBinPainter old) => old.lid != lid || old.body != body || old.fill != fill;
}

/// The bin as a widget; [open] lifts the lid.
class TrashBinIcon extends StatelessWidget {
  final double size;
  final double lid;
  final double fill;
  const TrashBinIcon({super.key, this.size = 96, this.lid = 0, this.fill = 0});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(painter: TrashBinPainter(lid: lid, body: P.of(context).ac, fill: fill)),
      );
}
