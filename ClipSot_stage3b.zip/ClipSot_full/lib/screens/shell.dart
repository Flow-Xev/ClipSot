import 'package:flutter/material.dart';

import '../ads.dart';
import '../haptics.dart';
import '../native.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'collections.dart';
import 'home.dart';
import 'search.dart';
import 'settings.dart';
import 'sheets.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> with WidgetsBindingObserver {
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Native.listen(_onPayload);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // Consent prompt first, ads only after it; the purchase service starts alongside.
      Ads.I.start();
      Billing.I.start(StoreScope.read(context));
      _onPayload(await Native.launch());
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// The link panel runs in its own engine, so pick up its changes on return.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) StoreScope.read(context).reload();
  }

  /// A notification, tile or panel asked to open a saved item.
  Future<void> _onPayload(Map<String, dynamic> p) async {
    final id = p['itemId'];
    if (id is! int || id == 0 || !mounted) return;
    final store = StoreScope.read(context);
    await store.reload();
    final it = store.byId(id);
    if (it != null && mounted) {
      setState(() => _tab = 0);
      openItem(context, it);
    }
  }

  int _homeVisits = 0;

  void _go(int t) {
    if (t != _tab) Haptics.select();
    setState(() {
      if (t == 0 && _tab != 0) _homeVisits++;
      _tab = t;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final pages = <Widget>[
      HomeScreen(visit: _homeVisits, onSearch: () => _go(2), onSettings: () => _go(3)),
      const CollectionsScreen(),
      const SearchScreen(),
      const SettingsScreen(),
    ];

    return PopScope(
      canPop: _tab == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _go(0);
      },
      child: Scaffold(
        backgroundColor: p.bg,
        body: SafeArea(
          child: Stack(
            children: [
              Column(children: [
                Expanded(
                  child: IndexedStack(index: _tab, children: [
                    // Hidden tabs stay alive but stop animating and can't be peeled.
                    for (var i = 0; i < pages.length; i++) TickerMode(enabled: i == _tab, child: pages[i]),
                  ]),
                ),
                _NavPill(index: _tab, onTap: _go),
              ]),
              if (_tab == 0)
                Positioned(
                  right: 20,
                  bottom: 100,
                  child: Tap(
                    onTap: () => showAddSheet(context),
                    label: 'Save a link',
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: p.ac,
                        shape: BoxShape.circle,
                        boxShadow: const [
                          BoxShadow(color: Color(0x59000000), blurRadius: 20, offset: Offset(0, 6)),
                        ],
                      ),
                      child: const Icon(Icons.add, size: 28, color: Color(0xFF171717)),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavPill extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const _NavPill({required this.index, required this.onTap});

  static const _items = [
    (Icons.home_outlined, Icons.home_filled, 'Home'),
    (Icons.collections_bookmark_outlined, Icons.collections_bookmark, 'Collections'),
    (Icons.search, Icons.search, 'Search'),
    (Icons.person_outline, Icons.person, 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    const ink = Color(0xFF171717);
    return Container(
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 12),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: p.s1,
        borderRadius: BorderRadius.circular(40),
        boxShadow: const [BoxShadow(color: Color(0x26000000), blurRadius: 18, offset: Offset(0, 6))],
      ),
      child: Row(
        children: [
          for (var i = 0; i < _items.length; i++)
            Expanded(
              flex: i == index ? 3 : 2,
              child: Tap(
                haptic: false,
                onTap: () => onTap(i),
                label: _items[i].$3,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 240),
                  curve: Curves.easeOutCubic,
                  height: 48,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: i == index ? p.ac : Colors.transparent,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(i == index ? _items[i].$2 : _items[i].$1, size: 22, color: i == index ? ink : p.tx2),
                    if (i == index) ...[
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(_items[i].$3,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: ts(12.5, w: FontWeight.w600, color: ink)),
                      ),
                    ],
                  ]),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
