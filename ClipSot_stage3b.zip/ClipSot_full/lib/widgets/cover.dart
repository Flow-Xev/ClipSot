import 'dart:io';

import 'package:flutter/widgets.dart';

import '../manga.dart' show mangaHeaders;
import '../models.dart';

/// The cover picture for an item, or null when it has none:
/// a saved image, the first page of a manga, or the thumbnail found for a link.
/// Always downscaled so a long list stays light on memory.
ImageProvider? coverProvider(Item it, {int width = 600}) {
  ImageProvider? base;
  if (it.isImage && it.isFile) {
    base = FileImage(File(it.path!));
  } else if (it.isManga && (it.pages?.isNotEmpty ?? false)) {
    final f = it.pages!.first;
    base = f.startsWith('/') ? FileImage(File(f)) : NetworkImage(f, headers: mangaHeaders(it.url));
  } else if (it.thumb != null && it.thumb!.isNotEmpty) {
    base = NetworkImage(it.thumb!, headers: it.isManga ? mangaHeaders(it.url) : null);
  }
  return base == null ? null : ResizeImage(base, width: width);
}
