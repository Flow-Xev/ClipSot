package com.clipsot.clipsot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

/** Notifications styled like the app: dark card, warm accent, "clipsot." wordmark. */
object Notifs {
    const val CH_REMIND = "clipsot_reminders"
    const val CH_HANDLE = "clipsot_handle"
    val ACCENT: Int = Color.parseColor("#C9A574")

    fun channels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_REMIND, "Reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Reminders about links you saved"
                enableLights(true)
                lightColor = ACCENT
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_HANDLE, "Quick-save handle", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Shown while the edge handle is on"
                setShowBadge(false)
            }
        )
    }

    fun canPost(ctx: Context): Boolean =
        ctx.getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    fun idFor(itemId: Long): Int = (itemId xor (itemId ushr 32)).toInt()

    private fun activityPi(ctx: Context, code: Int, itemId: Long): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("item_id", itemId)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun actionPi(ctx: Context, code: Int, action: String, itemId: Long, title: String, src: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(action)
            .putExtra("id", itemId).putExtra("title", title).putExtra("src", src)
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** [meta] = source line, [detail] = e.g. "Saved 12 days ago, still unread". */
    fun show(ctx: Context, itemId: Long, title: String, meta: String, detail: String) {
        channels(ctx)
        val nid = idFor(itemId)
        val src = meta

        fun fill(v: RemoteViews) {
            v.setTextViewText(R.id.n_title, title)
            v.setTextViewText(R.id.n_meta, if (detail.isEmpty()) meta else "$meta · $detail")
        }
        val small = RemoteViews(ctx.packageName, R.layout.notif_small).also { fill(it) }
        val big = RemoteViews(ctx.packageName, R.layout.notif_big).also {
            fill(it)
            it.setOnClickPendingIntent(R.id.btn_read, activityPi(ctx, nid * 4 + 1, itemId))
            it.setOnClickPendingIntent(R.id.btn_snooze, actionPi(ctx, nid * 4 + 2, Reminders.ACT_SNOOZE, itemId, title, src))
            it.setOnClickPendingIntent(R.id.btn_done, actionPi(ctx, nid * 4 + 3, Reminders.ACT_DONE, itemId, title, src))
        }

        val n = Notification.Builder(ctx, CH_REMIND)
            .setSmallIcon(R.drawable.ic_stat_clipsot)
            .setColor(ACCENT)
            .setContentTitle(title)
            .setContentText(meta)
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(small)
            .setCustomBigContentView(big)
            .setContentIntent(activityPi(ctx, nid * 4, itemId))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(nid, n)
    }
}
