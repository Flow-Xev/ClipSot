import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'notes.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _q = TextEditingController();
  String _type = 'All'; // All | Articles | Videos | Images | Documents | Unread
  String _sort = 'Newest';

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  void _set(String s) {
    _q.value = TextEditingValue(text: s, selection: TextSelection.collapsed(offset: s.length));
    StoreScope.of(context).addRecent(s);
    setState(() {});
  }

  /// Every typed word must appear somewhere in the item (so partial titles work).
  bool _match(Item i, List<String> toks) {
    final hay = [
      i.title,
      i.url,
      i.src,
      i.note,
      i.cols.join(' '),
      (i.body ?? const []).join(' '),
    ].join(' ').toLowerCase();
    return toks.every(hay.contains);
  }

  @override
  Widget build(BuildContext context) {
    final p = P.of(context);
    final store = StoreScope.of(context);
    final toks = tokens(_q.text);

    List<Item> results = [];
    List<Note> noteHits = [];
    if (toks.isNotEmpty) {
      results = store.items.where((i) {
        if (!_match(i, toks)) return false;
        if (_type == 'All') return true;
        if (_type == 'Unread') return !i.read;
        return i.type == kFilterType[_type];
      }).toList();
      switch (_sort) {
        case 'Oldest':
          results.sort((a, b) => a.saved.compareTo(b.saved));
        case 'A–Z':
          results.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
        default:
          results.sort((a, b) => b.saved.compareTo(a.saved));
      }
      if (_type == 'All') {
        noteHits = store.notes.where((n) {
          final hay = '${n.title} ${n.text} ${n.tags.join(' ')}'.toLowerCase();
          return toks.every(hay.contains);
        }).toList();
      }
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 140),
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 8),
          child: Text('Search', style: ts(30, w: FontWeight.w500, ls: -.8, color: p.tx)),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 14),
          child: SearchField(
            _q,
            'Search anything…',
            onChanged: (_) => setState(() {}),
            onSubmitted: (v) => store.addRecent(v),
          ),
        ),
        if (toks.isEmpty) ...[
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Recent searches', style: ts(15, w: FontWeight.w500, color: p.tx)),
            if (store.recents.isNotEmpty)
              Tap(
                onTap: store.clearRecents,
                label: 'Clear recent searches',
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Text('Clear', style: ts(13, color: p.tx2)),
                ),
              ),
          ]),
          const SizedBox(height: 10),
          store.recents.isEmpty
              ? Text('Nothing searched yet.', style: ts(14, color: p.tx2))
              : Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final r in store.recents) Pill(r, on: false, onTap: () => _set(r)),
                ]),
          const SizedBox(height: 28),
          Text('Suggestions', style: ts(15, w: FontWeight.w500, color: p.tx)),
          const SizedBox(height: 4),
          for (final c in store.cols.take(5))
            Tap(
              onTap: () => _set(c),
              label: 'Search $c',
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.s1))),
                child: Row(children: [
                  Icon(Icons.search, size: 22, color: p.tx),
                  const SizedBox(width: 14),
                  Expanded(child: Text(c, style: ts(16, color: p.tx))),
                  Icon(Icons.chevron_right, color: p.tx2),
                ]),
              ),
            ),
        ] else ...[
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              for (final f in const ['All', 'Unread', 'Articles', 'Videos', 'Images', 'Documents'])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Pill(f, on: _type == f, onTap: () => setState(() => _type = f)),
                ),
            ]),
          ),
          const SizedBox(height: 14),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('${results.length + noteHits.length} result${results.length + noteHits.length == 1 ? '' : 's'}',
                style: ts(13, color: p.tx2)),
            Row(children: [
              for (final s in const ['Newest', 'Oldest', 'A–Z'])
                Tap(
                  onTap: () => setState(() => _sort = s),
                  label: 'Sort $s',
                  child: Padding(
                    padding: const EdgeInsets.only(left: 14),
                    child: Text(s,
                        style: ts(13,
                            w: _sort == s ? FontWeight.w600 : FontWeight.w400,
                            color: _sort == s ? p.tx : p.tx2)),
                  ),
                ),
            ]),
          ]),
          const SizedBox(height: 6),
          if (results.isEmpty && noteHits.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 56),
              child: Column(children: [
                Icon(Icons.search_off, size: 44, color: p.tx2),
                const SizedBox(height: 16),
                Text('No matches', style: ts(22, w: FontWeight.w500, color: p.tx)),
                const SizedBox(height: 8),
                Text('Try fewer letters or a different word.', style: ts(14, color: p.tx2)),
              ]),
            )
          else ...[
            for (final i in results) ItemRow(i, key: ValueKey('r${i.id}'), toks: toks),
            for (final n in noteHits)
              NoteTile(note: n, toks: toks, key: ValueKey('n${n.id}')),
          ],
        ],
      ],
    );
  }
}
