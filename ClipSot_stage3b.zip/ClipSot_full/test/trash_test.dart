import 'dart:convert';

import 'package:clipsot/models.dart';
import 'package:clipsot/store.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<Store> _store() async {
  SharedPreferences.setMockInitialValues({
    'flutter.clipsot_v1': jsonEncode({'seeded': true, 'fetchText': false}),
  });
  return Store.load();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Trash for links', () {
    test('deleting moves the item to the Trash instead of erasing it', () async {
      final s = await _store();
      final it = Item.fromUrl('https://a.com/1', '', [])!;
      s.addItem(it);
      final gone = s.trashItem(it.id);
      expect(gone, isNotNull);
      expect(s.items.any((i) => i.id == it.id), isFalse);
      expect(s.trash.single.id, it.id);
      expect(s.trash.single.trashed, greaterThan(0));
      expect(s.trashCount, 1);
    });

    test('Undo puts it back, and clears the Trash stamp', () async {
      final s = await _store();
      final it = Item.fromUrl('https://a.com/1', '', [])!;
      s.addItem(it);
      s.trashItem(it.id);
      expect(s.restoreItem(it.id), isTrue);
      expect(s.items.any((i) => i.id == it.id), isTrue);
      expect(s.trash, isEmpty);
      expect(it.trashed, 0);
    });

    test('restore is refused when the same link was saved again', () async {
      final s = await _store();
      final it = Item.fromUrl('https://a.com/1', '', [])!;
      s.addItem(it);
      s.trashItem(it.id);
      s.addItem(Item.fromUrl('https://a.com/1', '', [])!);
      expect(s.restoreItem(it.id), isFalse);
      expect(s.trash.length, 1);
    });

    test('delete for good and empty Trash remove things completely', () async {
      final s = await _store();
      final a = Item.fromUrl('https://a.com/1', '', [])!;
      final b = Item.fromUrl('https://b.com/2', '', [])!;
      s.addItem(a);
      s.addItem(b);
      s.trashItem(a.id);
      s.trashItem(b.id);
      s.deleteForever(a.id);
      expect(s.trash.map((i) => i.id), [b.id]);
      s.emptyTrash();
      expect(s.trashCount, 0);
    });

    test('items older than the Trash window are purged, newer ones stay', () async {
      final s = await _store();
      final old = Item.fromUrl('https://a.com/1', '', [])!;
      final fresh = Item.fromUrl('https://b.com/2', '', [])!;
      s.addItem(old);
      s.addItem(fresh);
      s.trashItem(old.id);
      s.trashItem(fresh.id);
      old.trashed = DateTime.now().subtract(const Duration(days: kTrashDays + 1)).millisecondsSinceEpoch;
      expect(s.purgeExpired(), 1);
      expect(s.trash.map((i) => i.id), [fresh.id]);
    });

    test('Delete all data also empties the Trash', () async {
      final s = await _store();
      final it = Item.fromUrl('https://a.com/1', '', [])!;
      s.addItem(it);
      s.trashItem(it.id);
      s.deleteAll();
      expect(s.trashCount, 0);
    });
  });

  group('Trash for notes', () {
    test('trash and restore a note', () async {
      final s = await _store();
      final n = Note(id: 42)
        ..title = 'Idea'
        ..text = 'Something worth keeping';
      s.saveNote(n);
      expect(s.trashNote(42), isNotNull);
      expect(s.notes.any((x) => x.id == 42), isFalse);
      expect(s.trashNotes.single.id, 42);
      expect(s.restoreNote(42), isTrue);
      expect(s.notes.any((x) => x.id == 42), isTrue);
      expect(s.trashNotes, isEmpty);
    });

    test('delete a note for good', () async {
      final s = await _store();
      s.saveNote(Note(id: 7)..text = 'x');
      s.trashNote(7);
      s.deleteNoteForever(7);
      expect(s.trashNotes, isEmpty);
    });
  });
}
