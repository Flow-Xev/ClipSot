import 'package:flutter/material.dart';

import 'haptics.dart';
import 'store.dart';
import 'theme.dart';
import 'widgets/common.dart' show toastWith;
import 'widgets/peel.dart';

/// Pill toast with an Undo button.
void toastUndo(ScaffoldMessengerState m, P p, String msg, VoidCallback onUndo) {
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Text(msg, style: ts(14, color: p.bg)),
    backgroundColor: p.tx,
    behavior: SnackBarBehavior.floating,
    elevation: 0,
    margin: const EdgeInsets.fromLTRB(28, 0, 28, 100),
    shape: const StadiumBorder(),
    duration: const Duration(seconds: 5),
    action: SnackBarAction(
      label: 'Undo',
      textColor: p.ac,
      onPressed: () {
        Haptics.success();
        onUndo();
      },
    ),
  ));
}

/// Moves a saved item to the Trash with the paper-peel animation (when the row
/// is on screen), then offers Undo. [onDone] runs once it is in the Trash.
///
/// Everything that needs a BuildContext is passed in already, so this is safe
/// to call right after a panel or dialog has closed.
Future<void> trashItemAnimated(
  Store store,
  ScaffoldMessengerState m,
  P p,
  int id, {
  VoidCallback? onDone,
}) async {
  final row = PeelRegistry.of(id);
  var peeled = false;
  if (row != null) peeled = await row.peel();
  final it = store.trashItem(id);
  if (it == null) return;
  if (!peeled) Haptics.thud();
  onDone?.call();
  toastUndo(m, p, 'Moved to Trash', () {
    if (!store.restoreItem(it.id)) {
      toastWith(m, p, 'That link was saved again, so it stayed in Trash');
    }
  });
}

/// Same for a note.
Future<void> trashNoteAnimated(
  Store store,
  ScaffoldMessengerState m,
  P p,
  int id, {
  VoidCallback? onDone,
}) async {
  final row = PeelRegistry.of(-id);
  var peeled = false;
  if (row != null) peeled = await row.peel();
  final n = store.trashNote(id);
  if (n == null) return;
  if (!peeled) Haptics.thud();
  onDone?.call();
  toastUndo(m, p, 'Note moved to Trash', () => store.restoreNote(n.id));
}
