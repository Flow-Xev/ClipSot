import 'package:clipsot/files.dart';
import 'package:clipsot/models.dart';
import 'package:clipsot/panel/link_utils.dart';
import 'package:clipsot/sources.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('knows at least 100 websites and 70 file types', () {
    expect(kSiteCount, greaterThanOrEqualTo(100));
    expect(kAllExt.length, greaterThanOrEqualTo(70));
  });

  test('file kinds', () {
    expect(fileKind('a.JPG'), 'image');
    expect(fileKind('a.mkv'), 'video');
    expect(fileKind('a.flac'), 'audio');
    expect(fileKind('page.html'), 'html');
    expect(fileKind('ch1.cbz'), 'comic');
    expect(fileKind('a.docx'), 'document');
    expect(fileKind('noext'), 'document');
  });

  test('link types', () {
    String t(String u) => guessLinkType(Uri.parse(u));
    expect(t('https://www.youtube.com/watch?v=abcdefghijk'), 'video');
    expect(t('https://music.youtube.com/watch?v=abcdefghijk'), 'audio');
    expect(t('https://open.spotify.com/track/1'), 'audio');
    expect(t('https://www.tiktok.com/@a/video/1'), 'video');
    expect(t('https://mangadex.org/chapter/abc'), 'manga');
    expect(t('https://x.org/clip.mp4'), 'video');
    expect(t('https://x.org/song.mp3?x=1'), 'audio');
    expect(t('https://x.org/a-post'), 'article');
    expect(t('https://twitter.com/a/status/1'), 'article');
  });

  test('YouTube covers need no network', () {
    expect(youtubeId(Uri.parse('https://youtu.be/abcdefghijk')), 'abcdefghijk');
    expect(youtubeId(Uri.parse('https://www.youtube.com/shorts/abcdefghijk')), 'abcdefghijk');
    expect(Item.fromUrl('https://youtu.be/abcdefghijk', '', [])!.thumb, 'https://i.ytimg.com/vi/abcdefghijk/hqdefault.jpg');
  });

  test('pasted text becomes paragraphs and an article', () {
    expect(paragraphsOf('One\nline\n\nSecond one'), ['One line', 'Second one']);
    final a = articleFromText('', 'Hello there.\n\nSecond paragraph.')!;
    expect(a.title, 'Hello there.');
    expect(a.body!.length, 2);
    expect(articleFromText('t', '   '), isNull);
  });

  test('HTML file becomes an article', () {
    final a = articleFromHtml('<title>T</title><body><p>Short words only here.</p></body>',
        fallbackTitle: 'f', src: 'HTML file', id: 1)!;
    expect(a.title, 'T');
    expect(a.body, isNotEmpty);
  });

  test('extractAllLinks finds every link once', () {
    expect(extractAllLinks('a https://x.com/1 b\nhttps://y.com/2, https://x.com/1'), ['https://x.com/1', 'https://y.com/2']);
    expect(extractAllLinks(''), isEmpty);
  });
}
