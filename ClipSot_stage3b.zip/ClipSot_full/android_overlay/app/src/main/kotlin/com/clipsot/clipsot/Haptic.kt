package com.clipsot.clipsot

import android.content.Context
import android.os.Build
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.annotation.TargetApi

/**
 * Crisp haptics for ClipSot.
 *
 * Android 11+ : real haptic primitives (TICK, CLICK, THUD...) where the motor supports them.
 * Android 8+  : short amplitude-shaped waveforms.
 *
 * Needs only the normal VIBRATE permission. The system "Touch feedback" switch is respected,
 * and on Android 13+ the vibration is tagged as touch feedback so system settings apply.
 */
object Haptic {

    /** gap before the pulse (ms), pulse length (ms), strength 0..1 */
    private data class Pulse(val gap: Long, val ms: Long, val a: Float)

    private fun pulses(kind: String): List<Pulse> = when (kind) {
        "tick" -> listOf(Pulse(0, 6, .35f))
        "lowtick" -> listOf(Pulse(0, 9, .3f))
        "click" -> listOf(Pulse(0, 12, .6f))
        "heavy" -> listOf(Pulse(0, 18, .85f))
        "thud" -> listOf(Pulse(0, 28, 1f))
        "success" -> listOf(Pulse(0, 11, .5f), Pulse(55, 16, .95f))
        "warning" -> listOf(Pulse(0, 22, .9f), Pulse(75, 22, .9f))
        "peel" -> (0 until 9).map { i ->
            Pulse(if (i == 0) 0 else (90 - i * 7).toLong(), 7 + i.toLong(), .22f + i * .085f)
        }
        else -> listOf(Pulse(0, 8, .4f))
    }

    @Suppress("DEPRECATION")
    private fun vibrator(ctx: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    /** Returns false only when this phone has no vibration motor. */
    fun play(ctx: Context, kind: String, amp: Double): Boolean {
        val v = vibrator(ctx) ?: return false
        if (!v.hasVibrator()) return false
        // Honour the system "Touch feedback" switch.
        val touchOn = try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) != 0
        } catch (e: Exception) {
            true
        }
        if (!touchOn) return true

        val a = amp.toFloat().coerceIn(0.05f, 1f)
        val effect = (if (Build.VERSION.SDK_INT >= 30) composition(v, kind, a) else null)
            ?: legacy(v, kind, a)
            ?: return false
        send(v, effect)
        return true
    }

    private fun send(v: Vibrator, effect: VibrationEffect) {
        if (Build.VERSION.SDK_INT >= 33) {
            v.vibrate(effect, VibrationAttributes.createForUsage(VibrationAttributes.USAGE_TOUCH))
        } else {
            v.vibrate(effect)
        }
    }

    @TargetApi(30)
    private fun composition(v: Vibrator, kind: String, a: Float): VibrationEffect? {
        val tick = VibrationEffect.Composition.PRIMITIVE_TICK
        val click = VibrationEffect.Composition.PRIMITIVE_CLICK
        val thud = VibrationEffect.Composition.PRIMITIVE_THUD
        val lowTick = if (Build.VERSION.SDK_INT >= 31) VibrationEffect.Composition.PRIMITIVE_LOW_TICK else tick

        fun ok(vararg p: Int) = v.areAllPrimitivesSupported(*p)
        val c = VibrationEffect.startComposition()
        try {
            when (kind) {
                "tick" -> { if (!ok(tick)) return null; c.addPrimitive(tick, a) }
                "lowtick" -> { if (!ok(lowTick)) return null; c.addPrimitive(lowTick, a) }
                "click" -> { if (!ok(click)) return null; c.addPrimitive(click, a) }
                "heavy" -> { if (!ok(click)) return null; c.addPrimitive(click, a) }
                "thud" -> { if (!ok(thud)) return null; c.addPrimitive(thud, a) }
                "success" -> {
                    if (!ok(tick, click)) return null
                    c.addPrimitive(tick, a * .6f)
                    c.addPrimitive(click, a, 55)
                }
                "warning" -> {
                    if (!ok(thud)) return null
                    c.addPrimitive(thud, a * .9f)
                    c.addPrimitive(thud, a * .9f, 80)
                }
                "peel" -> {
                    if (!ok(tick)) return null
                    for (i in 0 until 9) {
                        val s = ((.18f + i * .085f) * a).coerceIn(.05f, 1f)
                        c.addPrimitive(tick, s, if (i == 0) 0 else 90 - i * 7)
                    }
                }
                else -> { if (!ok(tick)) return null; c.addPrimitive(tick, a) }
            }
            return c.compose()
        } catch (e: Exception) {
            return null
        }
    }

    private fun legacy(v: Vibrator, kind: String, a: Float): VibrationEffect? {
        val list = pulses(kind)
        return try {
            if (list.size == 1) {
                val p = list[0]
                VibrationEffect.createOneShot(p.ms, amplitude(p.a * a, v))
            } else {
                val t = ArrayList<Long>()
                val amps = ArrayList<Int>()
                for (p in list) {
                    t.add(p.gap); amps.add(0)
                    t.add(p.ms); amps.add(amplitude(p.a * a, v))
                }
                VibrationEffect.createWaveform(t.toLongArray(), amps.toIntArray(), -1)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun amplitude(f: Float, v: Vibrator): Int {
        if (Build.VERSION.SDK_INT >= 26 && !v.hasAmplitudeControl()) return VibrationEffect.DEFAULT_AMPLITUDE
        return (f * 255).toInt().coerceIn(1, 255)
    }
}
